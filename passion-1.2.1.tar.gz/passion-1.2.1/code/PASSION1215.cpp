#include <iostream>
#include <fstream>
#include <string>
#include <string.h>
#include <vector>
#include <stdio.h>
#include <cstdlib>
#include <list>
#include <iomanip>
#include <cmath>
#include <math.h>
#include <time.h>
#include <bits/basic_string.h>
#include <omp.h>
#include <stdint.h>
#include <dirent.h>
#include <errno.h>
#include <sstream>

using namespace std;

const unsigned SpacerBeforeAfter = 10000000;

//short Before, After;

//unsigned int CountIndels = 0;
const int alphs = 4;
const char alphabet[alphs] = {'A','C','G','T'};
//unsigned long long int TheMax = 0;
//const short MAX_MISMATCHES = 4;
//float ExtraDistanceRate = 0.1;

double Const_Log_T = 0.0;
double Const_S = 0.0;
double LOG14 = log10(0.25);
double Const_I = 0.0;
const unsigned int BoxSize = 10000;
const double Min_Filter_Ratio = 0.5;
//unsigned int SPACERSIZE = 1;
//unsigned int OriginalNumRead = 0; 
//const string NonACGT = "$";
//short MIN_Len_Match = 4;
//unsigned int NumberOfSIsInstances = 0;
unsigned int NumberOfDeletionsInstances = 0;
//unsigned int NumberOfDIInstances = 0;
short ReportLength = 80;
vector <string> VectorTag;
char Match[256];
char Match2N[256];
char Convert2RC[256];
char Convert2RC4N[256];
char Cap2LowArray[256];
bool FirstChr = true;
const double InsertSizeExtra = 2;
unsigned int CONS_Chr_Size;
const string X_str = "X";
const char N_char = 'N';
const char X_char = 'X';


string ExonIslandMask;
string CloseEndIslandMask;

const char Plus = '+';
const char Minus = '-';
const char FirstCharReadName = '@';


int Middle_Size;
int DI_distance;
//int JointFlag;
//int JointFlagClose;
//int JointFlagFar;

//short MAX_SNP_ERROR = 2;

short ADDITIONAL_MISMATCH;
short TOTAL_SNP_ERROR_CHECKED;
short TOTAL_SNP_ERROR_CHECKED_Minus;
short MAX_ALLOWED_MISMATCHES;
// #############################################
//const int mini_intron_size =20;
short Min_Perfect_Match_Around_BP = 3;       //#
//const short MIN_IndelSize_DI = 50;           //#  
//const short MIN_IndelSize_Inversion = 50;    //# 
//const float Seq_Error_Rate = 0.05;       //# 
//const unsigned int BalanceCutoff = 50000000;       //#
//const unsigned int NumRead2ReportCutOff = 1; //#
//const short MaxRangeIndex = 8;
const int NumberOfReadsPerBuffer = 1000;//#
//const int WINDOW_SIZE = 5000000;//#
// #############################################

// #############################################
int mini_intron_size;
short MAX_SNP_ERROR;       //#
//const short MIN_IndelSize_DI = 50;           //#  
//const short MIN_IndelSize_Inversion = 50;    //# 
float Seq_Error_Rate;       //# 
//const unsigned int BalanceCutoff = 50000000;       //#
//const unsigned int NumRead2ReportCutOff = 1; //#
short MaxRangeIndex;
//const int NumberOfReadsPerBuffer = 1000;//#
int WINDOW_SIZE;//#
// #############################################
//const float Double_Seq_Error_Rate_Per_Side = Seq_Error_Rate_Per_Side * 2;
//unsigned int Distance = 300;
 short MinClose = 8;//short(log((double)Distance)/log(4.0) + 0.8) + 3 + MAX_SNP_ERROR;//atoi(argv[1]);
 short MinFar_I = MinClose + 1;//atoi(argv[2]);
//cout << "For short insertion: " << MinClose << "\t" << MinFar_I << endl;
//short MinFar_D = 8;//atoi(argv[3]);
//const short MaxDI = 30; 
const short FirstBase = 1;

//struct Fragment {
//   unsigned int Start; 
//   unsigned int End;  
//};



struct UniquePoint {
	short LengthStr;
	unsigned int AbsLoc; 
	char Direction; // forward reverse
	char Strand; // sense antisense
	short Mismatches;
};

const char SENSE = '+';
const char ANTISENSE = '-';
const char FORWARD = '+';
const char BACKWARD = '-';



struct SPLIT_READ {
	string FragName;
	string Name;
	string UnmatchedSeq;
	char MatchedD;
	int MatchedRelPos;
	short MS;
	short InsertSize;	
	string Tag;
	vector <UniquePoint> UP_Close; // partial alignment of the unmapped reads close to the mapped read
	vector <UniquePoint> UP_Far;
	//vector <UniquePoint> UP_Far_Backup[MaxRangeIndex]; //20110611
	vector <UniquePoint> UP_Far_Backup[12];
	short ReadLength;
	short ReadLengthMinus;
	short BP;
	int Left;
	int Right;
	unsigned int BPLeft;
	unsigned int BPRight;
	unsigned int BPLeft_Range;
	unsigned int BPRight_Range;
	int IndelSize;
	bool OK;
	double score;
	//string InsertedStr;
	//string DI_str;	
	//short DI_size;
	bool Used;
	bool JointFlag;
	//bool JointFlagFar;
	//bool JointFlagClose;
	
};




struct Indel4output {
   unsigned int BPLeft;
   unsigned int BPRight;
   int IndelSize;
   unsigned int Start;
   unsigned int End;
   unsigned int BPLeft_Range;
   unsigned int BPRight_Range;
   //short DI_size;
   bool WhetherReport;
   //string IndelStr;
   short Support;
};

struct ExonIsland {
	string ChrName;
	unsigned int Start;
	unsigned int End;
	float Expression;

};
void ReadInOneChr(ifstream & inf_GenomeSeqs, string & TheInput, bool BuildData);
bool ReadInRead(ifstream & inf_Seq, const string & CurrentFragName, const string & CurrentFrag, vector <SPLIT_READ> & Reads,  unsigned  int  *DSizeArray, vector <ExonIsland> & All_EI_events);

void GetCloseEnd(const string & CurrentChr, SPLIT_READ & Temp_One_Read, const int & RangePrevious, const int & Range,  const string & ExonIslandMask);
void GetCloseEnd_FirstMismatch(const string & CurrentChr, SPLIT_READ & Temp_One_Read, const int & RangePrevious, const int & Range,  const string & ExonIslandMask);

void GetFarEnd_SingleStrand(const string & CurrentChr, SPLIT_READ & Temp_One_Read, const int & RangePrevious,const int & Range,  const string & ExonIslandMask);
void GetFarEnd_SingleStrand_FirstMismatch(const string & CurrentChr, SPLIT_READ & Temp_One_Read, const int & RangePrevious,const int & Range,  const string & ExonIslandMask);


//void DIGetCloseEnd(const string & CurrentChr, SPLIT_READ & Temp_One_Read, const int & RangePrevious, const int & Range);
//void DIGetFarEnd_SingleStrand(const string & CurrentChr, SPLIT_READ & Temp_One_Read, const int & RangePrevious,const int & Range);

void GetMiddle(const string & CurrentChr, SPLIT_READ & Temp_One_Read, const int & RangePrevious, const int & Range, const int  & Middle_Length, const int & RangeIndex);
void GetMiddle_Mask(const string & CurrentChr, SPLIT_READ & Temp_One_Read, const int & RangePrevious, const int & Range, const int  & Middle_Length, const int & RangeIndex, const string & ExonIslandMask);

//void GetFarEnd(const string & CurrentChr, SPLIT_READ & Temp_One_Read, const int & Range,  const string & ExonIslandMask);


struct Region {
	unsigned start;
	unsigned end;
};

void OutputDeletions(const vector <SPLIT_READ> & Deletions, 
                     const string & TheInput, 
                     const unsigned int & C_S, 
                     const unsigned int & C_E,
		               const unsigned int & RealStart,
		               const unsigned int & RealEnd,
                     ofstream & DeletionOutf);
 


short CompareTwoReads(const SPLIT_READ & First, const SPLIT_READ & Second);
vector <string> ReverseComplement(const vector <string> & input);
string Reverse(const string & InputPattern);
string ReverseComplement(const string & InputPattern);
string Cap2Low(const string & input);
void CheckLeft_Close(const string & TheInput, 
               const string & CurrentReadSeq, 
               const vector <unsigned int> Left_PD[], 
               const short & BP_Left_Start, 
               const short & BP_Left_End, 
               const short & CurrentLength,
               vector <UniquePoint> & LeftUP);
               
void CheckRight_Close(const string & TheInput, 
                const string & CurrentReadSeq, 
                const vector <unsigned int> Right_PD[], 
                const short & BP_Right_Start, 
                const short & BP_Right_End, 
                const short & CurrentPos, 
                vector <UniquePoint> & RightUP);

void CheckLeft_Far(const string & TheInput, 
							const string & CurrentReadSeq, 
							const vector <unsigned int> Left_PD[], 
							const short & BP_Left_Start, 
							const short & BP_Left_End, 
							const short & CurrentLength,
							vector <UniquePoint> & LeftUP);

void CheckRight_Far(const string & TheInput, 
					  const string & CurrentReadSeq, 
					  const vector <unsigned int> Right_PD[], 
					  const short & BP_Right_Start, 
					  const short & BP_Right_End, 
					  const short & CurrentPos, 
					  vector <UniquePoint> & RightUP);

void CheckBoth(const string & TheInput, 
               const string & CurrentReadSeq,
               const vector <unsigned int> PD_Plus[],
					const vector <unsigned int> PD_Minus[],
               const short & BP_Start,
               const short & BP_End,
               const short & CurrentLength,
               vector <UniquePoint> & UP);
bool CheckMismatches(const string & TheInput, 
                     const string & CurrentReadSeq, 
                     //const unsigned int & Start,
							const UniquePoint & UP);
                     
//void ProcessLIs(vector <SPLIT_READ> & LIs, ofstream & LIoutputfile);
//void SortOutputSI(const uint64_t & NumBoxes, const string & CurrentChr, vector <SPLIT_READ> SIs[], ofstream & SIsOutf);
void SortOutputD(const uint64_t & NumBoxes, const string & CurrentChr, vector <SPLIT_READ> &AllReads, vector <unsigned> Deletions[], ofstream & DeletionOutf);
//void SortOutputInv(const uint64_t & NumBoxes, const string & CurrentChr, vector <SPLIT_READ> Inv[], ofstream & InvOutf);
//void SortOutputDI(const uint64_t & NumBoxes, const string & CurrentChr, vector <SPLIT_READ> DI[], ofstream & DIOutf);
bool NotInVector(const string & OneTag, const vector <string> & VectorTag);
/*void GetIndelTypeAndRealStart(const string & TheInput, const unsigned int & BPLeft, 
                              const unsigned int & IndelSize, const string & IndelStr, 
                              string & IndelType, unsigned int & RealStart, const bool & WhetherD);*/
void GetRealStart4Deletion(const string & TheInput, unsigned int & RealStart, unsigned int & RealEnd,const string & UnMatched, short & BP);
void AdjustFarEnd(const string & TheInput, SPLIT_READ & Temp_One_Read);
void AdjustCloseEnd(const string & TheInput, SPLIT_READ & Temp_One_Read);
short FragementMismatchDistance(const string & TheInput, unsigned int & RealStart, unsigned int & RealEnd,const string & UnMatched, short & BP);
void CleanUniquePoints (vector <UniquePoint> & Input_UP);
//int ABS (int a);
short WhetherRemoveDuplicates;

string TempLine_DB_OK;


bool readTransgressesBinBoundaries(SPLIT_READ &read, int upperBinBorder, int max_intron_size)
{
   return (read.BPRight > upperBinBorder- max_intron_size) ;
}

void saveReadForNextCycle(SPLIT_READ &read, vector<SPLIT_READ> &futureReads)
{
   futureReads.push_back(read);
   read.Used = true; // as it cannot be used for this round of analyses anymore
}



int GetTmpFromDir (string dir, vector<string> &files, string pattern)
{
    DIR *dp;
    struct dirent *dirp;
    if((dp = opendir(dir.c_str())) == NULL) {
	cout << "Error(" << errno << ") opening " << dir << endl;
	return errno;
    }

    while ((dirp = readdir(dp)) != NULL) {

    if (string(dirp->d_name).find(pattern)!=string::npos )
	files.push_back(string(dirp->d_name));
    }
    closedir(dp);
    return 0;
}

string convertInt(int number)
{
   stringstream ss;//create a stringstream
   ss << number;//add number to the stream
   return ss.str();//return a string with the contents of the stream
}


int main (int argc, char *argv[]) {
  if (argc != 12) {
    cout << "\nWelcome to PAS\n\n"
         << "11 parameters are required here:\n"
         << "1. Input: the reference genome sequences in fasta format;\n"
         << "2. Input: the unmapped reads in a modified fastq format;\n"
         << "3. Input: Exon Islands: Chr start end;\n" 
         << "4. Output folder: the output folder for deletions: Junctions.txt (D)\n"
         << "5. Which chr/fragment;\n"
	 << "6. Number of threads;\n"
	 << "7. Max SNP;\n"
	 << "8. Estimated sequencing error rate;\n"
	 << "9. Max rangeIndex;\n"
	 << "10.Minimum intron size;\n"
	 << "11.Windown size;\n"
         << endl;
    return 1;
  }
  
// #############################################
mini_intron_size = atoi(argv[10]);
MAX_SNP_ERROR = atoi(argv[7]);       //#
//const short MIN_IndelSize_DI = 50;           //#  
//const short MIN_IndelSize_Inversion = 50;    //# 
Seq_Error_Rate = atof(argv[8]);       //# 
//const unsigned int BalanceCutoff = 50000000;       //#
//const unsigned int NumRead2ReportCutOff = 1; //#
MaxRangeIndex = atoi(argv[9]) +1;
//const int NumberOfReadsPerBuffer = 1000;//#
WINDOW_SIZE = atoi(argv[11]);//#
// #############################################
ADDITIONAL_MISMATCH = 2;
TOTAL_SNP_ERROR_CHECKED = MAX_SNP_ERROR + ADDITIONAL_MISMATCH + 1;
TOTAL_SNP_ERROR_CHECKED_Minus = MAX_SNP_ERROR + ADDITIONAL_MISMATCH;
MAX_ALLOWED_MISMATCHES = TOTAL_SNP_ERROR_CHECKED_Minus + 5;


    //WhetherRemoveDuplicates = atoi(argv[6]);
	int Count_D_Plus = 0;
	int Count_D_Minus = 0;
	//int Count_SI_Plus = 0;
	//int Count_SI_Minus = 0;
	//int Count_DI_Plus = 0;
	//int Count_DI_Minus = 0;
	//int Count_Inv_Plus = 0;
	//int Count_Inv_Minus = 0;
	//int Entering_D_Plus = 0;
	//int Entering_D_Minus = 0;
	//int Plus_Sum_Left = 0;
	//int Plus_Sum_Right = 0;
	//int Minus_Sum_Left = 0;
	//int Minus_Sum_Right = 0;
    
    Match[(short)'A'] = 'A';
    Match[(short)'C'] = 'C';
    Match[(short)'G'] = 'G';
    Match[(short)'T'] = 'T';
    Match[(short)'N'] = 'X';
    Match[(short)'$'] = '$';
    Match2N[(short)'A'] = 'N';
    Match2N[(short)'C'] = 'N';
    Match2N[(short)'G'] = 'N';
    Match2N[(short)'T'] = 'N';
    Match2N[(short)'N'] = 'X';
    Match2N[(short)'$'] = '$';
    Convert2RC[(short)'A'] = 'T';
    Convert2RC[(short)'C'] = 'G';
    Convert2RC[(short)'G'] = 'C';
    Convert2RC[(short)'T'] = 'A';
    Convert2RC[(short)'N'] = 'X';
    Convert2RC[(short)'$'] = '$';
    Convert2RC4N[(short)'A'] = 'T';
    Convert2RC4N[(short)'C'] = 'G';
    Convert2RC4N[(short)'G'] = 'C';
    Convert2RC4N[(short)'T'] = 'A';
    Convert2RC4N[(short)'N'] = 'N';
    Cap2LowArray[(short)'A'] = 'a';
    Cap2LowArray[(short)'C'] = 'c';
    Cap2LowArray[(short)'G'] = 'g';
    Cap2LowArray[(short)'T'] = 't';
    Cap2LowArray[(short)'N'] = 'n';
    Cap2LowArray[(short)'$'] = 'n';


time_t Time_Load_S, Time_Load_E, Time_Mine_E, Time_Sort_E, Time_PAS_S, Time_PAS_E;//, Time_End;

unsigned int AllLoadings = 0;
unsigned int AllMinings = 0;
unsigned int AllSortReport = 0;

//SPLIT_READ Temp_Read_Close;
//SPLIT_READ Temp_Read_Far;

  // #################################################################
    

    ifstream  inf_Seq(argv[1]);   // input file name
	const string WhichChr = argv[5];
    //unsigned int Distance = atoi(argv[3]);
    //const unsigned int D_SIZE_Input = 50000;//atoi(argv[4]);
    //char SIOutputFilename[10000];      // output file name
    //strcpy(SIOutputFilename, argv[3]);
    //ofstream SIoutputfile(SIOutputFilename);
	string inputFilename = argv[2];
	//inputFilename += "_" + WhichChr;
	bool WithFolder = false;
	int StartOfFileName = 0;
	for (int i = inputFilename.size(); i >= 0; i--) {
		if (inputFilename[i] == '/') {
			StartOfFileName = i;
			WithFolder = true;
			break;
		}
	}

	if (WithFolder) {
		inputFilename = inputFilename.substr(StartOfFileName + 1, inputFilename.size() - 1 - StartOfFileName);
	}
	//cout << inputFilename << endl;

	string OutputFolder = argv[4];
	OutputFolder += "/";


	string DeletionOutputFilename = OutputFolder + "deletions."+WhichChr+".txt";


    //char DeletionInsertinOutputFilename[10000];      // output file name
    //strcpy(DeletionInsertinOutputFilename, argv[5]);
    //ofstream DeletionInsertionOutf(DeletionInsertinOutputFilename);
    

	omp_set_num_threads(atoi(argv[6]));
    string Spacer = "";
    for (int i = 0; i < SpacerBeforeAfter; i++)
       Spacer += "N";
    //cout << Distance << endl;
	 //Distance = 300;
    //MinClose = short(log((double)Distance)/log(4.0) + 0.8) + 3 + MAX_SNP_ERROR;//atoi(argv[1]);
    //MinFar_I = MinClose + 1;//atoi(argv[2]);
    //cout << "For short insertion: " << MinClose << "\t" << MinFar_I << endl;
    //MinFar_D = 6;//atoi(argv[3]);
        
    //cout << Distance << endl;
    
    unsigned int DSizeArray[13];
	DSizeArray[0] = 0;
//	DSizeArray[1] = 25;
	DSizeArray[1] = 100;
	DSizeArray[2] = 400;
	DSizeArray[3] = 1600;
	DSizeArray[4] = 6400;
	DSizeArray[5] = 25600;
	DSizeArray[6] = 102400;
	DSizeArray[7] = 409600;
	DSizeArray[8] = 1638400;
	DSizeArray[9] = 6553600;
	DSizeArray[10] = 26214400;
	DSizeArray[11] = 104857600;
	DSizeArray[12] = 419430400;
    //unsigned int DSizeExtra = 100;   
    //unsigned int D_SIZE = 100;
    int max_intron_size=DSizeArray[MaxRangeIndex-1];
	string TempLie_BD;
	
    string CurrentChr;
    char TempStartChrChar;
    //short FragID;
    
	//char FirstSharpChar;
	
    unsigned int EndOfFragment;// = CurrentChr.size() - Spacer;
    unsigned int StartOfFragment;// = CurrentChr.size() - Spacer;
    
	//short BP_Left_Start;
	//short BP_Left_End;
	//short BP_Right_Start;
	//short BP_Right_End;
    //unsigned int LeftStart, LeftEnd, RightStart, RightEnd;
    //bool ShortInsertionOK;
    //bool DeletionOK;
    //unsigned int DISTANCE;
    //short ReadLengthMinus;
    //short ReadLength;
    
    //char LeftChar, RightChar;
    unsigned int Num_Left;
    //short CurrentChrIndex = 0;
    //unsigned int Count_SI = 0;
    unsigned int Count_D = 0;
    //unsigned int Count_DI = 0;
	//unsigned int Count_Inv = 0;
		
    
    string CurrentFragName, EatStr;
    inf_Seq >> TempStartChrChar;
    if (TempStartChrChar != '>') {
       cout << "Please use fasta format for the reference sequence. " << endl;
       return 1;
    }
	string TempLine_BD;
	
    while (inf_Seq >> CurrentFragName) {
       if(!FirstChr) {
           cout << "Chromosome of interest already processed, exiting. " << endl;
           break;
       }
       getline(inf_Seq, EatStr);
       CurrentChr.clear();
       cout << "Processing chromosome " << CurrentFragName << " ..." << endl;
       ReadInOneChr(inf_Seq, CurrentChr, CurrentFragName.compare(WhichChr) == 0);
       if(CurrentChr.size() == 0) {
         cout << "Skipping " << CurrentFragName << endl;
         continue;
       }
       CONS_Chr_Size = CurrentChr.size();
       cout << "Current chromosome size: " << CONS_Chr_Size << " bases" << endl;
       unsigned int BinNum=CurrentChr.size()/WINDOW_SIZE +1 ; //get roof
       
       CurrentChr = Spacer + CurrentChr + Spacer;
       uint64_t NumBoxes =(uint64_t) (CurrentChr.size() / BoxSize) + 1;
	//cout << NumBoxes << "\t" << BoxSize << endl;
      // cout << "NumBoxes: " << NumBoxes << endl;
       //vector <SPLIT_READ> SIs[NumBoxes];
       //vector <SPLIT_READ> LIs[NumBoxes];
       vector <unsigned> Deletions[NumBoxes]; // #########################
       //vector <SPLIT_READ> DI[NumBoxes];
		 //vector <SPLIT_READ> Inv[NumBoxes];
       EndOfFragment = CurrentChr.size() - SpacerBeforeAfter;
       StartOfFragment = SpacerBeforeAfter;
       //cout << StartOfFragment << "\t" << EndOfFragment << endl;
       vector <SPLIT_READ>  Reads, FutureReads;
       ifstream  inf_ReadsSeq;


		 
		 ifstream  inf_EI(argv[3]);   // input file name
		 vector <ExonIsland> All_EI_events;
		 ExonIsland Temp_EI_event;
		 if (WhichChr == CurrentFragName) {
		  	 while (inf_EI >> Temp_EI_event.ChrName >> Temp_EI_event.Start >> Temp_EI_event.End >>Temp_EI_event.Expression) {
		  		 if (Temp_EI_event.Start > Temp_EI_event.End) {
		  			cout << "Exon island format error: chr start end (start <= end). Example: chr17	80878426	80904863\n";
		  			return 1;
		  		 }
		  		 if (WhichChr == Temp_EI_event.ChrName){

		  			 All_EI_events.push_back(Temp_EI_event);
		  		 }

		  	 }
		 }

		cout << WhichChr << " Exon island events:" << All_EI_events.size() << endl;
		ExonIslandMask = "";
		CloseEndIslandMask = "";
		  	  	 if (All_EI_events.size()) {
		  	  		 for (int i = 0; i < CurrentChr.size(); i++) {
		  	  			 ExonIslandMask += X_str;
						 CloseEndIslandMask += X_str;

		  	  		 }
		  	  		 for (int i = 0; i < All_EI_events.size(); i++) {
		  	  			 if (All_EI_events[i].ChrName == CurrentFragName) {
		  	  				 //cout << All_EI_events[i].Start + SpacerBeforeAfter<<"\t"<<All_EI_events[i].End + SpacerBeforeAfter<<endl;
		  	  				 for (int j = All_EI_events[i].Start + SpacerBeforeAfter; j <= All_EI_events[i].End + SpacerBeforeAfter; j++) {
		  	  					 ExonIslandMask[j] = CurrentChr[j];
		  	  				 }

		  	  			 }
		  	  		 }
		  	  		 int Count_EI_Char = 0;
		  	  		 for (int EI_charIndex = 0;EI_charIndex < ExonIslandMask.size(); EI_charIndex++)
		  	  			 if (ExonIslandMask[EI_charIndex] == CurrentChr[EI_charIndex]) Count_EI_Char++;
		  	  		 cout << "Exon Island bases: " << Count_EI_Char<< endl;

		 }

		         /* <-Remove old deletion file  */
		  	  	 ifstream testFile( DeletionOutputFilename.c_str() );
		  	  	 if (testFile) { // file exists
		  	  		 testFile.close();
		  	  		 remove(DeletionOutputFilename.c_str());
		  	  	 }
		         /* <-Remove interfering old deletion file */
		  	  	ofstream DeletionOutf(DeletionOutputFilename.c_str());
				//Yanju
						
				cout<<CurrentChr.size()<<"\t"<<WINDOW_SIZE<<"\t"<<BinNum<<endl;
				string PassionInputFile=argv[2];
				string PassionInputFileTmp="";
		  	  	/* Starting the loop to read the subfiles one by one (EWL070111) -> */
		  	  	for (unsigned int BinIndex = 0;BinIndex <  BinNum;BinIndex++) { // EW060111: ideally, these should be pre-sorted. But first to test whether it works
		  	  	   // close the output-files, and reopen them as input files.
				   
				    PassionInputFileTmp =OutputFolder+ PassionInputFile + ".bin" +convertInt(BinIndex)+".tmp";
				    cout << "\nReading reads from file: "<< PassionInputFileTmp <<endl;
				    cout << "Looking at chromosome " << WhichChr << " bases " << BinIndex*WINDOW_SIZE << " to " << (BinIndex+1)*WINDOW_SIZE << ".\n";
				    const int upperBinBorder = WINDOW_SIZE * (BinIndex+1);
				    inf_ReadsSeq.open(PassionInputFileTmp.c_str());
				    if ( inf_ReadsSeq.fail() ) {
					cout << "No splitted reads at " << BinIndex*WINDOW_SIZE << " to " << (BinIndex+1)*WINDOW_SIZE << ".\n";
					
				    } 
				    else { 
				      //get file size
				       ifstream myfile (PassionInputFileTmp.c_str());
					long begin = myfile .tellg();
					myfile .seekg (0, ios::end);
					long end = myfile .tellg();
					myfile.close();
					Time_Load_S=time(NULL);
					Time_Load_E=time(NULL);
					if (end-begin >0)
					{
					  //if size=0 then skip pattern growth
				      //cout << "File Size:"<<end-begin<<"Byte"<<endl;
				      /* <- Starting the loop to read the subfiles one by one (EWL070111)*/
				       //


	//inf_ReadsSeq(PassionInputFile.c_str());	  		//ofstream DeletionOutf(DeletionOutputFilename.c_str());
       bool ReturnFromReadingReads = true;
       if (WhichChr == CurrentFragName) {
          ReturnFromReadingReads = true;
          ReturnFromReadingReads = ReadInRead(inf_ReadsSeq, CurrentFragName, CurrentChr, Reads,   DSizeArray, All_EI_events);
          if (ReturnFromReadingReads == false) {
             cout << "malformed record detected!" << endl;
	     return 1;
          }
          else
	  {
	    //get clos_eend island
	    int loc_start,loc_end;

	    for (int ReadIndex = 0; ReadIndex < Reads.size(); ReadIndex++) {
	      if (!Reads[ReadIndex].UP_Close.empty())
	      {
	      if (Reads[ReadIndex].MatchedD=='+') {
		 loc_start=Reads[ReadIndex].UP_Close[0].AbsLoc-Reads[ReadIndex].UP_Close[0].LengthStr;
		 loc_start=loc_start-10;
	      }
	      else {
		 loc_start=Reads[ReadIndex].UP_Close[0].AbsLoc+Reads[ReadIndex].UP_Close[0].LengthStr;
		 loc_start=loc_start-Reads[ReadIndex].ReadLength;
	      }
	      loc_end=loc_start+10+Reads[ReadIndex].ReadLength;

	    for (int j=loc_start;j<loc_end;j++)
	    {
	      CloseEndIslandMask[j] = CurrentChr[j];
	    }
	      }
	    }
	  }
       }
       Time_Load_E = time(NULL);
       //CurrentChr.clear();
       
       if (Reads.size() != 0)
          cout << "There are " << Reads.size() << " reads for this chromosome." <<endl;
       else {
          //cout << "There are " << LeftReads.size() << " reads for this chromosome." << endl;  
	  remove(PassionInputFileTmp.c_str()); //2011-12-15
          continue;
       }
       Num_Left = Reads.size();
       Const_Log_T = log10((double)Num_Left);
		int CountFarEnd, CountFarEndPlus, CountFarEndMinus;       
		cout << "Searching breakpoints ... round 1\t";	
		CountFarEnd = 0;
		CountFarEndMinus = 0;
		CountFarEndPlus = 0;
		 for (short RangeIndex = 1; RangeIndex < MaxRangeIndex; RangeIndex++) {
			 
			#pragma omp parallel default(shared)
			{
          	  #pragma omp for
				 for (int ReadIndex = 0; ReadIndex < Reads.size(); ReadIndex++) {
					 if (!Reads[ReadIndex].UP_Far.empty()) {
						 //CountFarEnd++;
						 continue;
					 }
					 MAX_SNP_ERROR = (short)(Reads[ReadIndex].UnmatchedSeq.size() * Seq_Error_Rate + 1.0);
				 
					 TOTAL_SNP_ERROR_CHECKED = MAX_SNP_ERROR + ADDITIONAL_MISMATCH + 1;
					 TOTAL_SNP_ERROR_CHECKED_Minus = MAX_SNP_ERROR + ADDITIONAL_MISMATCH;
					 MinClose = short(log((double)(2 * Reads[ReadIndex].InsertSize + DSizeArray[RangeIndex]))/log(4.0) + 0.8) + 3;//atoi(argv[1]);
					 MinFar_I = MinClose + 1;//atoi(argv[2]);
					 //cout << "For short insertion: " << MinClose << "\t" << MinFar_I << endl;
					 //MinFar_D = 8;//atoi(argv[3]);
					 //if (RangeIndex <= 5)
				    GetFarEnd_SingleStrand(CurrentChr, Reads[ReadIndex], DSizeArray[RangeIndex-1], DSizeArray[RangeIndex], CloseEndIslandMask);
				    Reads[ReadIndex].JointFlag = 0;
				    //Reads[ReadIndex].JointFlagClose = 0;
				    //Reads[ReadIndex].JointFlagFar = 0;
				    if (!Reads[ReadIndex].UP_Far.empty()) {
				    	for (int CloseIndex = Reads[ReadIndex].UP_Close.size()-1; CloseIndex >=0; CloseIndex--) {
					      if (Reads[ReadIndex].JointFlag==1) break;	
					      for (int FarIndex = 0; FarIndex < Reads[ReadIndex].UP_Far.size(); FarIndex++) {
							if (Reads[ReadIndex].JointFlag==1) break;
				    			if (Reads[ReadIndex].UP_Far[FarIndex].LengthStr + Reads[ReadIndex].UP_Close[CloseIndex].LengthStr == Reads[ReadIndex].ReadLength)
								 {Reads[ReadIndex].JointFlag=1;}
				    		}
				    	}
				    	if (Reads[ReadIndex].JointFlag ==1) {
							#pragma omp critical
				    		{
				    			CountFarEnd++;
				    			if (Reads[ReadIndex].MatchedD == '+') CountFarEndPlus++;
				    			else CountFarEndMinus++;
				    		}
				    	}
					else Reads[ReadIndex].UP_Far.clear();
				    }
				 }
			} // #pragma omp parallel default(shared)
			 	  //cout << RangeIndex << "\tNumber of reads with far end mapped: " << CountFarEnd << "\t"
				  //<< "\tTotal number of reads:" << Reads.size() << "\n" 
				  //<< CountFarEnd * 100.0 / Reads.size() << " %\n"
				  //<< "Far+: " << CountFarEndPlus << "\tFar-: " << CountFarEndMinus << endl;
		 }
		 cout <<"FarEnd: "<<CountFarEnd<< "\t+" << CountFarEndPlus << "\t-" << CountFarEndMinus << endl;
		 cout << "Searching breakpoints ... round 2\t";
		 


		CountFarEnd = 0;
		CountFarEndMinus = 0;
		CountFarEndPlus = 0;
		
		for (short RangeIndex = 1; RangeIndex < MaxRangeIndex; RangeIndex++) {
		#pragma omp parallel default(shared)
		{
		#pragma omp for
			for (int ReadIndex = 0; ReadIndex < Reads.size(); ReadIndex++) {

				if (!Reads[ReadIndex].UP_Far.empty()) {
						 //CountFarEnd++;
					continue;
				}
				MAX_SNP_ERROR = (short)(Reads[ReadIndex].UnmatchedSeq.size() * Seq_Error_Rate + 1.0);
				 
				TOTAL_SNP_ERROR_CHECKED = MAX_SNP_ERROR + ADDITIONAL_MISMATCH + 1;
				TOTAL_SNP_ERROR_CHECKED_Minus = MAX_SNP_ERROR + ADDITIONAL_MISMATCH;
				MinClose = short(log((double)(2 * Reads[ReadIndex].InsertSize + DSizeArray[RangeIndex]))/log(4.0) + 0.8) + 3;//atoi(argv[1]);
				MinFar_I = MinClose + 1;//atoi(argv[2]);
					 //cout << "For short insertion: " << MinClose << "\t" << MinFar_I << endl;
					 //MinFar_D = 8;//atoi(argv[3]);
					 //if (RangeIndex <= 5)
				GetFarEnd_SingleStrand_FirstMismatch(CurrentChr, Reads[ReadIndex], DSizeArray[RangeIndex-1], DSizeArray[RangeIndex], ExonIslandMask);
				    //Reads[ReadIndex].JointFlag = 0;
				    //Reads[ReadIndex].JointFlagClose = 0;
				    //Reads[ReadIndex].JointFlagFar = 0;
				    if (!Reads[ReadIndex].UP_Far.empty()) {
				    	for (int CloseIndex = Reads[ReadIndex].UP_Close.size()-1; CloseIndex >=0; CloseIndex--) {
				    		if (Reads[ReadIndex].JointFlag==1) break;
						for (int FarIndex = 0; FarIndex < Reads[ReadIndex].UP_Far.size(); FarIndex++) {
				    			if (Reads[ReadIndex].JointFlag==1) break;
							if (Reads[ReadIndex].UP_Far[FarIndex].LengthStr + Reads[ReadIndex].UP_Close[CloseIndex].LengthStr == Reads[ReadIndex].ReadLength)
								 {Reads[ReadIndex].JointFlag=1;}
				    		}
				    	}
				    	#pragma omp critical
					{
						if (Reads[ReadIndex].JointFlag ==1) {
					
				    			CountFarEnd++;
				    			if (Reads[ReadIndex].MatchedD == '+') CountFarEndPlus++;
				    			else CountFarEndMinus++;
				    		}
				    	
						else  {
							Reads[ReadIndex].UP_Far_Backup[RangeIndex] = Reads[ReadIndex].UP_Far;
							Reads[ReadIndex].UP_Far.clear();
						}
					}
				    }
				 }
			} // #pragma omp parallel default(shared)
			 	  //cout << RangeIndex << "\tNumber of reads with far end mapped: " << CountFarEnd << "\t"
			      //<< "\tTotal number of reads:" << Reads.size() << "\n" 
			      //<< CountFarEnd * 100.0 / Reads.size() << " %\n"
			      //<< "Far+: " << CountFarEndPlus << "\tFar-: " << CountFarEndMinus << endl;
		 }
		 cout <<"FarEnd: "<<CountFarEnd<< "\t+" << CountFarEndPlus << "\t-" << CountFarEndMinus << endl;
		 
		 cout << "Searching DI breakpoints. round 3\t";

		CountFarEnd = 0;
		CountFarEndMinus = 0;
		CountFarEndPlus = 0;
  		SPLIT_READ Temp_Read;
		for (int ReadIndex = Reads.size()-1; ReadIndex >=0; ReadIndex--) {			
			//#pragma omp parallel default(shared)
			//{
          	  //#pragma omp for
			//cout<<ReadIndex<<"\t"<<Reads[ReadIndex].Name<<endl;
		  	if (Reads[ReadIndex].JointFlag == 1) {
				continue;
			}
			Temp_Read= Reads[ReadIndex];
			Temp_Read.Name= Reads[ReadIndex].Name + "_Close";
			for (short RangeIndex = 1; RangeIndex < MaxRangeIndex; RangeIndex++) {
				if (Reads[ReadIndex].JointFlag == 1) {
					break;
				}

				if (!Reads[ReadIndex].UP_Far_Backup[RangeIndex].empty()){
					 
					 Middle_Size=Reads[ReadIndex].ReadLength- Reads[ReadIndex].UP_Far_Backup[RangeIndex][Reads[ReadIndex].UP_Far_Backup[RangeIndex].size()-1].LengthStr - Reads[ReadIndex].UP_Close[Reads[ReadIndex].UP_Close.size()-1].LengthStr;

					if (Reads[ReadIndex].MatchedD == '+'){
					      DI_distance=Reads[ReadIndex].UP_Far_Backup[RangeIndex][Reads[ReadIndex].UP_Far_Backup[RangeIndex].size()-1].AbsLoc-Reads[ReadIndex].UP_Close[Reads[ReadIndex].UP_Close.size()-1].AbsLoc-2*mini_intron_size-Middle_Size;}
					else if (Reads[ReadIndex].MatchedD == '-'){
					      DI_distance=Reads[ReadIndex].UP_Close[Reads[ReadIndex].UP_Close.size()-1].AbsLoc-Reads[ReadIndex].UP_Far_Backup[RangeIndex][Reads[ReadIndex].UP_Far_Backup[RangeIndex].size()-1].AbsLoc-2*mini_intron_size-Middle_Size;}//cout<<Middle_Size<<endl;
					//cout<<DI_distance<<endl;
					MinClose = short(log((double)(2 * Reads[ReadIndex].InsertSize + DSizeArray[RangeIndex]))/log(4.0) + 0.8) + 3;//atoi(argv[1]);
					
					if (Middle_Size >=MinClose) {
					  //cout<<Middle_Size<<"\t"<<MinClose<<endl;
					      for ( short DI_RangeIndex=1; DI_RangeIndex<= RangeIndex; DI_RangeIndex++) {
						    if (DI_distance>=DSizeArray[DI_RangeIndex])
						    {
							  GetMiddle_Mask(CurrentChr,Reads[ReadIndex],DSizeArray[DI_RangeIndex-1], DSizeArray[DI_RangeIndex], Middle_Size, RangeIndex, ExonIslandMask);
						    }
						    else if (DI_distance>DSizeArray[DI_RangeIndex-1] && DI_distance<DSizeArray[DI_RangeIndex])
						    {
							  GetMiddle_Mask(CurrentChr, Reads[ReadIndex],DSizeArray[DI_RangeIndex-1], DI_distance-mini_intron_size, Middle_Size, RangeIndex, ExonIslandMask);			
						    }
					
						    if (Reads[ReadIndex].JointFlag ==1) {
					  
							  Temp_Read.JointFlag =1;
							  Temp_Read.UnmatchedSeq=Reads[ReadIndex].UnmatchedSeq.substr(Reads[ReadIndex].UP_Far[Reads[ReadIndex].UP_Far.size()-1].LengthStr);
							  Temp_Read.UP_Far.clear();	
							  Temp_Read.UP_Far=Reads[ReadIndex].UP_Far_Backup[0];//have to change AbsLoc
					      
							  for (short FarEndIndex=0; FarEndIndex<Temp_Read.UP_Far.size();FarEndIndex++) {
							  //cout <<FarEndIndex<<endl;
							      if (Reads[ReadIndex].MatchedD == '+'){
								    Temp_Read.UP_Far[FarEndIndex].AbsLoc=Temp_Read.UP_Far[FarEndIndex].AbsLoc-Temp_Read.UP_Far[FarEndIndex].LengthStr+1;
							      }
							      else {
								    Temp_Read.UP_Far[FarEndIndex].AbsLoc=Temp_Read.UP_Far[FarEndIndex].AbsLoc+Temp_Read.UP_Far[FarEndIndex].LengthStr-1;
							      }

							      Temp_Read.UP_Far[FarEndIndex].Direction =  Reads[ReadIndex].UP_Far[0].Direction;
							  }
							  Temp_Read.ReadLength = Temp_Read.UnmatchedSeq.size();
							  Temp_Read.ReadLengthMinus = Temp_Read.ReadLength - 1;

							  Reads[ReadIndex].Name=Reads[ReadIndex].Name + "_Far";
							  Reads[ReadIndex].MatchedRelPos=Reads[ReadIndex].UP_Close[Reads[ReadIndex].UP_Close.size()-1].AbsLoc-SpacerBeforeAfter;
							  Reads[ReadIndex].UnmatchedSeq=Reads[ReadIndex].UnmatchedSeq.substr(0,Reads[ReadIndex].ReadLength-Reads[ReadIndex].UP_Close[Reads[ReadIndex].UP_Close.size()-1].LengthStr);
							  Reads[ReadIndex].UP_Close.clear();
							  Reads[ReadIndex].UP_Close=Reads[ReadIndex].UP_Far_Backup[0];  
							  Reads[ReadIndex].ReadLength = Reads[ReadIndex].UnmatchedSeq.size();
							  Reads[ReadIndex].ReadLengthMinus = Reads[ReadIndex].ReadLength - 1;
					      
					      /*cout<< "@\t" <<Temp_Read.UP_Far[Temp_Read.UP_Far.size()-1].AbsLoc 
					       << "\t" <<Temp_Read.UP_Close[Temp_Read.UP_Close.size()-1].AbsLoc
					       << "\t" <<Temp_Read.UP_Far[Temp_Read.UP_Far.size()-1].LengthStr
					      << "\t" <<Temp_Read.UP_Close[Temp_Read.UP_Close.size()-1].LengthStr<<endl;
					      	cout<< "@\t" <<Reads[ReadIndex].UP_Far[Reads[ReadIndex].UP_Far.size()-1].AbsLoc 
					       << "\t" <<Reads[ReadIndex].UP_Close[Reads[ReadIndex].UP_Close.size()-1].AbsLoc
					       << "\t" <<Reads[ReadIndex].UP_Far[Reads[ReadIndex].UP_Far.size()-1].LengthStr
					       << "\t" <<Reads[ReadIndex].UP_Close[Reads[ReadIndex].UP_Close.size()-1].LengthStr<<endl;
					      */
							/*if (Reads[ReadIndex].MatchedD == '+'){
						 
							    AdjustFarEnd(CurrentChr, Temp_Read);
							}

							else {
						   //
							   AdjustCloseEnd(CurrentChr, Reads[ReadIndex]);
							}*/
					      /*
					      cout<< "@\t" <<Temp_Read.UP_Far[Temp_Read.UP_Far.size()-1].AbsLoc 
					       << "\t" <<Temp_Read.UP_Close[Temp_Read.UP_Close.size()-1].AbsLoc
					       << "\t" <<Temp_Read.UP_Far[Temp_Read.UP_Far.size()-1].LengthStr
					      << "\t" <<Temp_Read.UP_Close[Temp_Read.UP_Close.size()-1].LengthStr<<endl;
					      cout<< "@\t" <<Reads[ReadIndex].UP_Far[Reads[ReadIndex].UP_Far.size()-1].AbsLoc 
					       << "\t" <<Reads[ReadIndex].UP_Close[Reads[ReadIndex].UP_Close.size()-1].AbsLoc
					       << "\t" <<Reads[ReadIndex].UP_Far[Reads[ReadIndex].UP_Far.size()-1].LengthStr
					       << "\t" <<Reads[ReadIndex].UP_Close[Reads[ReadIndex].UP_Close.size()-1].LengthStr<<endl;
					      */
					      //Ajust_FarEnd
						      Reads.push_back(Temp_Read);
						      CountFarEnd+=2;
						      if (Reads[ReadIndex].MatchedD == '+') CountFarEndPlus+=2;
						      else CountFarEndMinus+=2;
						      break;
						}
					    }
					}

				   
				// }
			}
			}
			//cout<<"round 3"<<endl;// #pragma omp parallel default(shared)
			 //cout << RangeIndex << "\tNumber of reads with far end mapped: " << CountFarEnd << "\t"
			      //<< "\tTotal number of reads:" << Reads.size() << "\n"
			      //<< CountFarEnd * 100.0 / Reads.size() << " %\n"
			      //<< "Far+: " << CountFarEndPlus << "\tFar-: " << CountFarEndMinus << endl;
			      	for (short RangeIndex = 1; RangeIndex < MaxRangeIndex; RangeIndex++) {
				if (Reads[ReadIndex].JointFlag == 1) {
					break;
				}

				if (!Reads[ReadIndex].UP_Far_Backup[RangeIndex].empty()){
					 
					 Middle_Size=Reads[ReadIndex].ReadLength- Reads[ReadIndex].UP_Far_Backup[RangeIndex][Reads[ReadIndex].UP_Far_Backup[RangeIndex].size()-1].LengthStr - Reads[ReadIndex].UP_Close[Reads[ReadIndex].UP_Close.size()-1].LengthStr;

					if (Reads[ReadIndex].MatchedD == '+'){
					      DI_distance=Reads[ReadIndex].UP_Far_Backup[RangeIndex][Reads[ReadIndex].UP_Far_Backup[RangeIndex].size()-1].AbsLoc-Reads[ReadIndex].UP_Close[Reads[ReadIndex].UP_Close.size()-1].AbsLoc-2*mini_intron_size-Middle_Size;}
					else if (Reads[ReadIndex].MatchedD == '-'){
					      DI_distance=Reads[ReadIndex].UP_Close[Reads[ReadIndex].UP_Close.size()-1].AbsLoc-Reads[ReadIndex].UP_Far_Backup[RangeIndex][Reads[ReadIndex].UP_Far_Backup[RangeIndex].size()-1].AbsLoc-2*mini_intron_size-Middle_Size;}//cout<<Middle_Size<<endl;
					//cout<<DI_distance<<endl;
					MinClose = short(log((double)(2 * Reads[ReadIndex].InsertSize + DSizeArray[RangeIndex]))/log(4.0) + 0.8) + 3;//atoi(argv[1]);
					
					if (Middle_Size >=MinClose) {
					  //cout<<Middle_Size<<"\t"<<MinClose<<endl;
					      for ( short DI_RangeIndex=1; DI_RangeIndex<= RangeIndex; DI_RangeIndex++) {
						    if (DI_distance>=DSizeArray[DI_RangeIndex])
						    {
							  GetMiddle(CurrentChr,Reads[ReadIndex],DSizeArray[DI_RangeIndex-1], DSizeArray[DI_RangeIndex], Middle_Size, RangeIndex);
						    }
						    else if (DI_distance>DSizeArray[DI_RangeIndex-1] && DI_distance<DSizeArray[DI_RangeIndex])
						    {
							  GetMiddle(CurrentChr, Reads[ReadIndex],DSizeArray[DI_RangeIndex-1], DI_distance-mini_intron_size, Middle_Size, RangeIndex);			
						    }
					
						    if (Reads[ReadIndex].JointFlag ==1) {
					  
							  Temp_Read.JointFlag =1;
							  Temp_Read.UnmatchedSeq=Reads[ReadIndex].UnmatchedSeq.substr(Reads[ReadIndex].UP_Far[Reads[ReadIndex].UP_Far.size()-1].LengthStr);
							  Temp_Read.UP_Far.clear();	
							  Temp_Read.UP_Far=Reads[ReadIndex].UP_Far_Backup[0];//have to change AbsLoc
					      
							  for (short FarEndIndex=0; FarEndIndex<Temp_Read.UP_Far.size();FarEndIndex++) {
							  //cout <<FarEndIndex<<endl;
							      if (Reads[ReadIndex].MatchedD == '+'){
								    Temp_Read.UP_Far[FarEndIndex].AbsLoc=Temp_Read.UP_Far[FarEndIndex].AbsLoc-Temp_Read.UP_Far[FarEndIndex].LengthStr+1;
							      }
							      else {
								    Temp_Read.UP_Far[FarEndIndex].AbsLoc=Temp_Read.UP_Far[FarEndIndex].AbsLoc+Temp_Read.UP_Far[FarEndIndex].LengthStr-1;
							      }

							      Temp_Read.UP_Far[FarEndIndex].Direction =  Reads[ReadIndex].UP_Far[0].Direction;
							  }
							  Temp_Read.ReadLength = Temp_Read.UnmatchedSeq.size();
							  Temp_Read.ReadLengthMinus = Temp_Read.ReadLength - 1;

							  Reads[ReadIndex].Name=Reads[ReadIndex].Name + "_Far";
							  Reads[ReadIndex].MatchedRelPos=Reads[ReadIndex].UP_Close[Reads[ReadIndex].UP_Close.size()-1].AbsLoc-SpacerBeforeAfter;
							  Reads[ReadIndex].UnmatchedSeq=Reads[ReadIndex].UnmatchedSeq.substr(0,Reads[ReadIndex].ReadLength-Reads[ReadIndex].UP_Close[Reads[ReadIndex].UP_Close.size()-1].LengthStr);
							  Reads[ReadIndex].UP_Close.clear();
							  Reads[ReadIndex].UP_Close=Reads[ReadIndex].UP_Far_Backup[0];  
							  Reads[ReadIndex].ReadLength = Reads[ReadIndex].UnmatchedSeq.size();
							  Reads[ReadIndex].ReadLengthMinus = Reads[ReadIndex].ReadLength - 1;
					      
					      /*cout<< "@\t" <<Temp_Read.UP_Far[Temp_Read.UP_Far.size()-1].AbsLoc 
					       << "\t" <<Temp_Read.UP_Close[Temp_Read.UP_Close.size()-1].AbsLoc
					       << "\t" <<Temp_Read.UP_Far[Temp_Read.UP_Far.size()-1].LengthStr
					      << "\t" <<Temp_Read.UP_Close[Temp_Read.UP_Close.size()-1].LengthStr<<endl;
					      	cout<< "@\t" <<Reads[ReadIndex].UP_Far[Reads[ReadIndex].UP_Far.size()-1].AbsLoc 
					       << "\t" <<Reads[ReadIndex].UP_Close[Reads[ReadIndex].UP_Close.size()-1].AbsLoc
					       << "\t" <<Reads[ReadIndex].UP_Far[Reads[ReadIndex].UP_Far.size()-1].LengthStr
					       << "\t" <<Reads[ReadIndex].UP_Close[Reads[ReadIndex].UP_Close.size()-1].LengthStr<<endl;
					      */
							//if (Reads[ReadIndex].MatchedD == '+'){
						 
							//    AdjustFarEnd(CurrentChr, Temp_Read);
							//}

							//else {
						   //
							 //   AdjustCloseEnd(CurrentChr, Reads[ReadIndex]);
							//}
					      /*
					      cout<< "@\t" <<Temp_Read.UP_Far[Temp_Read.UP_Far.size()-1].AbsLoc 
					       << "\t" <<Temp_Read.UP_Close[Temp_Read.UP_Close.size()-1].AbsLoc
					       << "\t" <<Temp_Read.UP_Far[Temp_Read.UP_Far.size()-1].LengthStr
					      << "\t" <<Temp_Read.UP_Close[Temp_Read.UP_Close.size()-1].LengthStr<<endl;
					      cout<< "@\t" <<Reads[ReadIndex].UP_Far[Reads[ReadIndex].UP_Far.size()-1].AbsLoc 
					       << "\t" <<Reads[ReadIndex].UP_Close[Reads[ReadIndex].UP_Close.size()-1].AbsLoc
					       << "\t" <<Reads[ReadIndex].UP_Far[Reads[ReadIndex].UP_Far.size()-1].LengthStr
					       << "\t" <<Reads[ReadIndex].UP_Close[Reads[ReadIndex].UP_Close.size()-1].LengthStr<<endl;
					      */
					      //Ajust_FarEnd
						      Reads.push_back(Temp_Read);
						      CountFarEnd+=2;
						      if (Reads[ReadIndex].MatchedD == '+') CountFarEndPlus+=2;
						      else CountFarEndMinus+=2;
						      break;
						}
					    }
					}

				   
				// }
			}
			}
		 }
		 cout <<"FarEnd: "<<CountFarEnd<< "\t+" << CountFarEndPlus << "\t-" << CountFarEndMinus << endl;
		
		 /*
		  cout<<"hello"<<endl;
		 for (int ReadIndex = 0; ReadIndex < Reads.size(); ReadIndex++) {
			
			cout <<ReadIndex <<"\t??";	
			if (!Reads[ReadIndex].UP_Far.empty())	{				 //cout << "1" << endl;
			cout <<Reads[ReadIndex].Name<<"\t"<< Reads[ReadIndex].UP_Far[Reads[ReadIndex].UP_Far.size()-1].LengthStr 
			<< "\t" << Reads[ReadIndex].UP_Close[Reads[ReadIndex].UP_Close.size()-1].LengthStr
			<< "\t" << Reads[ReadIndex].UP_Far[Reads[ReadIndex].UP_Far.size()-1].LengthStr + Reads[ReadIndex].UP_Close[Reads[ReadIndex].UP_Close.size()-1].LengthStr << "\t" << Reads[ReadIndex].ReadLength << "\t";
			
			cout<< "\t" <<Reads[ReadIndex].UP_Close[Reads[ReadIndex].UP_Close.size()-1].AbsLoc 
			<< "\t" <<Reads[ReadIndex].UP_Close[Reads[ReadIndex].UP_Close.size()-1].Strand
			<< "\t" <<Reads[ReadIndex].UP_Close[Reads[ReadIndex].UP_Close.size()-1].Mismatches
			<< "\t" <<Reads[ReadIndex].UP_Close[Reads[ReadIndex].UP_Close.size()-1].Direction;
			
			cout<< "\t" <<Reads[ReadIndex].UP_Far[Reads[ReadIndex].UP_Far.size()-1].AbsLoc 
			<< "\t" <<Reads[ReadIndex].UP_Far[Reads[ReadIndex].UP_Far.size()-1].Strand
			<< "\t" <<Reads[ReadIndex].UP_Far[Reads[ReadIndex].UP_Far.size()-1].Mismatches
			<< "\t" <<Reads[ReadIndex].UP_Far[Reads[ReadIndex].UP_Far.size()-1].Direction<<endl;
			}
		 }
		
		 */

		 /*
		 for (int ReadIndex = 0; ReadIndex < Reads.size(); ReadIndex++) {
			 if (Reads[ReadIndex].UP_Close.size() && Reads[ReadIndex].UP_Far.size()) {
				 //cout << Reads[ReadIndex].Name << "\t" << Reads[ReadIndex].MatchedD << endl;
				 //cout << "close" << endl;
				 for (int CloseIndex = 0; CloseIndex < Reads[ReadIndex].UP_Close.size(); CloseIndex++) {
					 cout << Reads[ReadIndex].UP_Close[CloseIndex].LengthStr 
					 << "\t" << Reads[ReadIndex].UP_Close[CloseIndex].AbsLoc << endl; 
				 }
				 cout << "far" << endl;
				 for (int FarIndex = 0; FarIndex < Reads[ReadIndex].UP_Far.size(); FarIndex++) {
					 cout << Reads[ReadIndex].UP_Far[FarIndex].LengthStr 
					 << "\t" << Reads[ReadIndex].UP_Far[FarIndex].AbsLoc << endl; 
				 }
				 cout << endl; 
			 }
		 }
		 */
					}
		 Time_Mine_E = time(NULL);
		 short MAX_MISMATCHES_Per_Read = 0;;
		 cout << "Searching deletions ... " << endl;
		 Count_D = 0;
		 Count_D_Plus = 0;
		 Count_D_Minus = 0;
		 for (unsigned ReadIndex = 0; ReadIndex < Reads.size(); ReadIndex++) {
			 MAX_MISMATCHES_Per_Read = (short)(Seq_Error_Rate * Reads[ReadIndex].ReadLength + 1);
			 if (Reads[ReadIndex].UP_Far.size()) {
				 if (Reads[ReadIndex].MatchedD == '+') {
				   //cout << Reads[ReadIndex].Name<<"+" << endl;
					 /*
					 cout << "+" << endl;
					 cout << Reads[ReadIndex].UP_Close.size() << "\t" 
					      << Reads[ReadIndex].UP_Close[0].Strand << "\t"
					      << Reads[ReadIndex].UP_Close[0].Direction << "\t"
					      << Reads[ReadIndex].UP_Close[0].AbsLoc << endl;
					 cout << Reads[ReadIndex].UP_Far.size() << "\t" 
					 << Reads[ReadIndex].UP_Far[0].Strand << "\t"
					 << Reads[ReadIndex].UP_Far[0].Direction << "\t"
					 << Reads[ReadIndex].UP_Far[0].AbsLoc << endl;*/
					 
					   	
					for (int FarIndex =Reads[ReadIndex].UP_Far.size()-1; FarIndex >=0; FarIndex--) {
					//cout <<FarIndex<<"\t";	
					if (Reads[ReadIndex].Used) break;
					for (int CloseIndex = 0; CloseIndex < Reads[ReadIndex].UP_Close.size(); CloseIndex++) {
					//cout <<CloseIndex<<endl;	
					   if (Reads[ReadIndex].Used) break;
							 if (Reads[ReadIndex].UP_Far[FarIndex].Mismatches + Reads[ReadIndex].UP_Close[CloseIndex].Mismatches > MAX_MISMATCHES_Per_Read)
								 continue;
							 if (Reads[ReadIndex].UP_Far[FarIndex].Direction == '-') {
								 //cout << "1" << endl;
								 //cout << "+\t" << Reads[ReadIndex].UP_Far[FarIndex].LengthStr 
								 //     << "\t" << Reads[ReadIndex].UP_Close[CloseIndex].LengthStr
								 //     << "\t" << Reads[ReadIndex].UP_Far[FarIndex].LengthStr + Reads[ReadIndex].UP_Close[CloseIndex].LengthStr << "\t" << Reads[ReadIndex].ReadLength << "\t";
								 //cout << Reads[ReadIndex].UP_Far[FarIndex].AbsLoc << "\t>\t" << Reads[ReadIndex].UP_Close[CloseIndex].AbsLoc + 1 << endl;
								 if (Reads[ReadIndex].UP_Far[FarIndex].LengthStr + Reads[ReadIndex].UP_Close[CloseIndex].LengthStr == Reads[ReadIndex].ReadLength && Reads[ReadIndex].UP_Far[FarIndex].AbsLoc > Reads[ReadIndex].UP_Close[CloseIndex].AbsLoc + 1
									  && Reads[ReadIndex].UP_Far[FarIndex].Mismatches + Reads[ReadIndex].UP_Close[CloseIndex].Mismatches <= Seq_Error_Rate * Reads[ReadIndex].ReadLength) {
									 Reads[ReadIndex].Left = Reads[ReadIndex].UP_Close[CloseIndex].AbsLoc - Reads[ReadIndex].UP_Close[CloseIndex].LengthStr + 1;
									 Reads[ReadIndex].Right = Reads[ReadIndex].UP_Far[FarIndex].AbsLoc + Reads[ReadIndex].UP_Far[FarIndex].LengthStr - 1;
									 Reads[ReadIndex].BP = Reads[ReadIndex].UP_Close[CloseIndex].LengthStr - 1;
									 
									 Reads[ReadIndex].IndelSize =  (Reads[ReadIndex].Right - Reads[ReadIndex].Left) - Reads[ReadIndex].ReadLengthMinus;
									 //Reads[ReadIndex].DI_str = "";
									 //Reads[ReadIndex].InsertedStr = "";
									 Reads[ReadIndex].BPLeft = Reads[ReadIndex].UP_Close[CloseIndex].AbsLoc - SpacerBeforeAfter;// - Fragments[LeftReads[Left_Index].MatchedSeqID].Start;
									 Reads[ReadIndex].BPRight = Reads[ReadIndex].UP_Far[FarIndex].AbsLoc - SpacerBeforeAfter;// - Fragments[LeftReads[Left_Index].MatchedSeqID].Start;
									 Reads[ReadIndex].score = Const_I + Const_S + LOG14 * Reads[ReadIndex].ReadLength + Const_Log_T;
									 //LeftReads[Left_Index].OK = true;
									 Reads[ReadIndex].BPLeft_Range=Reads[ReadIndex].BPLeft;
									 Reads[ReadIndex].BPRight_Range=Reads[ReadIndex].BPRight;
									 GetRealStart4Deletion(CurrentChr, Reads[ReadIndex].BPLeft_Range, Reads[ReadIndex].BPRight_Range, ReverseComplement(Reads[ReadIndex].UnmatchedSeq),Reads[ReadIndex].BP);
									 //Reads[ReadIndex].BP = Reads[ReadIndex].UP_Close[CloseIndex].LengthStr - 1 -(Reads[ReadIndex].BPLeft-Reads[ReadIndex].BPLeft_Range);
									 
									 Reads[ReadIndex].BPRight=Reads[ReadIndex].BPRight-(Reads[ReadIndex].BPLeft-Reads[ReadIndex].BPLeft_Range);
									 Reads[ReadIndex].BPLeft=Reads[ReadIndex].BPLeft_Range;
									 {  
										 if (Reads[ReadIndex].BP>MAX_SNP_ERROR && Reads[ReadIndex].BPRight_Range-Reads[ReadIndex].BPRight<Reads[ReadIndex].ReadLengthMinus-Reads[ReadIndex].BP && FragementMismatchDistance(CurrentChr, Reads[ReadIndex].BPLeft, Reads[ReadIndex].BPRight, ReverseComplement(Reads[ReadIndex].UnmatchedSeq),Reads[ReadIndex].BP))  
										 { 
											 if (readTransgressesBinBoundaries(Reads[ReadIndex],upperBinBorder,max_intron_size)) { saveReadForNextCycle(Reads[ReadIndex], FutureReads ); }
											 else {
											 Deletions[(int)Reads[ReadIndex].BPLeft / BoxSize].push_back(ReadIndex);
											 Reads[ReadIndex].Used = true;
											 Count_D++;
											 Count_D_Plus++;
											 //cout<<"Count D"<<Count_D<<endl;
											 }
										 }
									 }
								 }
							 }
						 }
					 }
					
				 }
				 else if (Reads[ReadIndex].MatchedD == '-') {
					 
					/* cout << Reads[ReadIndex].Name<<"-" << endl;
					 cout << Reads[ReadIndex].UP_Close.size() << "\t" 
					 << Reads[ReadIndex].UP_Close[0].Strand << "\t"
					 << Reads[ReadIndex].UP_Close[0].Direction << "\t"
					 << Reads[ReadIndex].UP_Close[0].AbsLoc << endl;
					 cout << Reads[ReadIndex].UP_Far.size() << "\t" 
					 << Reads[ReadIndex].UP_Far[0].Strand << "\t"
					 << Reads[ReadIndex].UP_Far[0].Direction << "\t"
					 << Reads[ReadIndex].UP_Far[0].AbsLoc << endl;*/
					 for (int CloseIndex=Reads[ReadIndex].UP_Close.size()-1; CloseIndex >=0 ; CloseIndex--) {
						 	if (Reads[ReadIndex].Used) break;
						 	for (int FarIndex = 0; FarIndex < Reads[ReadIndex].UP_Far.size(); FarIndex++) {
							if (Reads[ReadIndex].Used) break; 
							if (Reads[ReadIndex].UP_Far[FarIndex].Mismatches + Reads[ReadIndex].UP_Close[CloseIndex].Mismatches > MAX_MISMATCHES_Per_Read)
								 continue;
							 if (Reads[ReadIndex].UP_Far[FarIndex].Direction == '+') {
								 //cout << "2" << endl;
								 // ######################
								 //cout << "-\t" << Reads[ReadIndex].UP_Close[CloseIndex].LengthStr + Reads[ReadIndex].UP_Far[FarIndex].LengthStr << "\t" << Reads[ReadIndex].ReadLength << "\t";
								 //cout << Reads[ReadIndex].UP_Close[CloseIndex].AbsLoc << "\t>\t" << Reads[ReadIndex].UP_Far[FarIndex].AbsLoc + 1 << endl;
								 if (Reads[ReadIndex].UP_Close[CloseIndex].LengthStr + Reads[ReadIndex].UP_Far[FarIndex].LengthStr == Reads[ReadIndex].ReadLength
									  && Reads[ReadIndex].UP_Close[CloseIndex].AbsLoc > Reads[ReadIndex].UP_Far[FarIndex].AbsLoc + 1
									  && Reads[ReadIndex].UP_Far[FarIndex].Mismatches + Reads[ReadIndex].UP_Close[CloseIndex].Mismatches <= Seq_Error_Rate * Reads[ReadIndex].ReadLength) {
									 //cout <<"3"<<endl;
									 Reads[ReadIndex].Left = Reads[ReadIndex].UP_Far[FarIndex].AbsLoc - Reads[ReadIndex].UP_Far[FarIndex].LengthStr + 1;
									 Reads[ReadIndex].Right = Reads[ReadIndex].UP_Close[CloseIndex].AbsLoc + Reads[ReadIndex].UP_Close[CloseIndex].LengthStr - 1;
									 Reads[ReadIndex].BP = Reads[ReadIndex].UP_Far[FarIndex].LengthStr - 1;
									 
									 Reads[ReadIndex].IndelSize = (Reads[ReadIndex].Right - Reads[ReadIndex].Left) - Reads[ReadIndex].ReadLengthMinus;
									 //Reads[ReadIndex].DI_str = "";
									 //Reads[ReadIndex].InsertedStr = "";
									 Reads[ReadIndex].BPLeft = Reads[ReadIndex].UP_Far[FarIndex].AbsLoc - SpacerBeforeAfter;// - Fragments[LeftReads[Left_Index].MatchedSeqID].Start;
									 Reads[ReadIndex].BPRight = Reads[ReadIndex].UP_Close[CloseIndex].AbsLoc - SpacerBeforeAfter;// - Fragments[LeftReads[Left_Index].MatchedSeqID].Start;
									 Reads[ReadIndex].score = Const_I + Const_S + LOG14 * Reads[ReadIndex].ReadLength + Const_Log_T;
									 //LeftReads[Left_Index].OK = true;
									 Reads[ReadIndex].BPLeft_Range=Reads[ReadIndex].BPLeft;
									 Reads[ReadIndex].BPRight_Range=Reads[ReadIndex].BPRight;
									 //cout <<"4"<<endl;
									 GetRealStart4Deletion(CurrentChr, Reads[ReadIndex].BPLeft_Range, Reads[ReadIndex].BPRight_Range,Reads[ReadIndex].UnmatchedSeq,Reads[ReadIndex].BP);
									 //cout <<"9"<<endl;
									 //Reads[ReadIndex].BP = Reads[ReadIndex].UP_Far[FarIndex].LengthStr - 1 -(Reads[ReadIndex].BPLeft-Reads[ReadIndex].BPLeft_Range);
									
									 Reads[ReadIndex].BPRight=Reads[ReadIndex].BPRight-(Reads[ReadIndex].BPLeft-Reads[ReadIndex].BPLeft_Range);
									 Reads[ReadIndex].BPLeft=Reads[ReadIndex].BPLeft_Range;
									  //cout <<"7"<<endl;
									 {
										 if (Reads[ReadIndex].BP>MAX_SNP_ERROR && Reads[ReadIndex].BPRight_Range-Reads[ReadIndex].BPRight<Reads[ReadIndex].ReadLengthMinus-Reads[ReadIndex].BP && FragementMismatchDistance(CurrentChr, Reads[ReadIndex].BPLeft, Reads[ReadIndex].BPRight,Reads[ReadIndex].UnmatchedSeq,Reads[ReadIndex].BP)) { 
											 if (readTransgressesBinBoundaries(Reads[ReadIndex],upperBinBorder,max_intron_size)) { saveReadForNextCycle(Reads[ReadIndex], FutureReads ); }
											 else {
											 Deletions[(int)Reads[ReadIndex].BPLeft / BoxSize].push_back(ReadIndex);
											 Reads[ReadIndex].Used = true;
											 
											 Count_D++;
											 Count_D_Minus++;
											 //cout << "- " << Count_D << endl; 
											 }
										 }
									 }
									 //cout <<"5"<<endl;
								 }
							 }
						 }
					 }
				 }
			 }
		 }

		 cout << "Total: " << Count_D << "\t+" << Count_D_Plus << "\t-" << Count_D_Minus << endl;
		 SortOutputD(NumBoxes, CurrentChr,Reads, Deletions, DeletionOutf);

       for (unsigned int i = 0; i < NumBoxes; i++) Deletions[i].clear(); 









		 Time_Sort_E = time(NULL);   

		 //cout << "SI: " << Count_SI_Plus << " " << Count_SI_Minus << "\n"
		 //<< "D: " << Count_D_Plus << " " << Count_D_Minus << endl;
		 //cout << Entering_D_Plus << " " << Entering_D_Minus << endl;
		 //cout << Plus_Sum_Left << " " << Plus_Sum_Right << "\n" << Minus_Sum_Right << " " << Minus_Sum_Left << endl;

      AllLoadings += (unsigned int)difftime(Time_Load_E, Time_Load_S);
      AllMinings += (unsigned int)difftime(Time_Mine_E, Time_Load_E);
      AllSortReport += (unsigned int)difftime(Time_Sort_E, Time_Mine_E);

					/*cout << "before swap:" << endl;
					cout << "reads " << endl;
					cout << "     size:     " << Reads.size() << endl;
					cout << "     capacity: " << Reads.capacity() << endl;
					cout << "     max_size: " << Reads.max_size() << endl;
					cout << "FutureReads " << endl;
					cout << "     size:     " << FutureReads.size() << endl;
					cout << "     capacity: " << FutureReads.capacity() << endl;
					cout << "     max_size: " << FutureReads.max_size() << endl;*/


  /* Ending the loop and cleaning up after completion (EWL070111) -> */
     inf_ReadsSeq.close();
     Reads.clear();
  //cout << FutureReads.size() << "Before reads saved for the next cycle.\t" << Reads.size() << endl;
     Reads.swap(FutureReads);
     cout << Reads.size() << " reads saved for the next cycle." << endl;
     Time_Load_S=0;
					/*cout << "after swap:" << endl;
					cout << "reads " << endl;
					cout << "     size:     " << Reads.size() << endl;
					cout << "     capacity: " << Reads.capacity() << endl;
					cout << "     max_size: " << Reads.max_size() << endl;
					cout << "FutureReads " << endl;
					cout << "     size:     " << FutureReads.size() << endl;
					cout << "     capacity: " << FutureReads.capacity() << endl;
					cout << "     max_size: " << FutureReads.max_size() << endl;*/
     //cout  <<Reads.size() << endl;
	
     remove(PassionInputFileTmp.c_str());

 }
				}
     // CLEAN UP MAP AND TEMPORARY FILES HERE


  /* <-Ending the loop and cleaning up after completion (EWL070111) */

    }
    cout << "Loading genome sequences and reads: " << AllLoadings << " seconds." << endl;
    cout << "Mining Deletions: " << AllMinings << " seconds." << endl;
    cout << "Sorting and output results: " << AllSortReport << " seconds." << endl;
  return 0;

}//main


void ReadInOneChr(ifstream & inf_Seq, string & TheInput, bool BuildData) {
  char TempChar;
  string TempLine;
  while (inf_Seq >> TempChar) {
     if (TempChar != '\n' && TempChar != '\r') {
        if (TempChar == '>') {
           return;
        }
        else if(BuildData) {
              if ( 'a' <= TempChar && TempChar <= 'z' )
                 TempChar = TempChar + ( 'A' - 'a' );
                 switch (TempChar) {
                    case 'A': TheInput += 'A'; break;  // 00000000
                    case 'C': TheInput += 'C'; break; // 00010000
	            case 'G': TheInput += 'G'; break; // 00100000
	            case 'T': TheInput += 'T'; break; // 00110000
    	            default:  TheInput += 'N';        // 01000000
              }
        } // else TempChar
     }
  }
  return;
}


bool ReadInRead(ifstream & inf_ReadSeq, const string & FragName, const string & CurrentChr, vector <SPLIT_READ> & Reads, unsigned  int  *DSizeArray, vector <ExonIsland> & All_EI_events) {
	cout << "Scanning and processing reads anchored in " << FragName << endl; 
	SPLIT_READ Temp_One_Read;
	unsigned int NumReadScanned = 0;
	unsigned int NumReadInChr = 0;
	unsigned int InChrPlus = 0;
	unsigned int InChrMinus = 0;
	unsigned int GetPlus = 0;
	unsigned int GetMinus = 0;
	ReportLength = 0;
	vector <SPLIT_READ> BufferReads;
	//cout << LeftReads.size() << endl;
	string TempQC, TempLine, TempStr, TempFragName;
	//int TempInt;
	VectorTag.clear();
	while (inf_ReadSeq >> Temp_One_Read.Name) {
		if (Temp_One_Read.Name[0] != FirstCharReadName) {
			cout << "Something wrong with the read name: " << Temp_One_Read.Name << endl;
			Reads.clear();
			return false;
		}
		NumReadScanned++;
		if (NumReadScanned % 1000000 == 0)
			cout << NumReadScanned << endl;
		getline(inf_ReadSeq, TempLine);
		inf_ReadSeq >> Temp_One_Read.UnmatchedSeq;
		getline(inf_ReadSeq, TempLine);
		//inf_ReadSeq >> TempQC;
		//getline(inf_ReadSeq, TempLine);
		inf_ReadSeq >> Temp_One_Read.MatchedD;
		if (Temp_One_Read.MatchedD != '-' && Temp_One_Read.MatchedD != '+') {
			cout << Temp_One_Read.Name << "\n"
			<< Temp_One_Read.UnmatchedSeq << "\n"
			<< Temp_One_Read.MatchedD << " ...\n";
			cout << "+/-" << endl;
			return false;
		}
		//   >> TempInt 
		inf_ReadSeq >> Temp_One_Read.FragName
		>> Temp_One_Read.MatchedRelPos
		>> Temp_One_Read.MS
		>> Temp_One_Read.InsertSize
		>> Temp_One_Read.Tag;
		//Temp_One_Read.MS = 1;
		//Temp_One_Read.InsertSize = 300;
		getline(inf_ReadSeq, TempLine);

		
		if (Temp_One_Read.FragName == FragName) {
			NumReadInChr++;
			MAX_SNP_ERROR = (short)(Temp_One_Read.UnmatchedSeq.size() * Seq_Error_Rate + 1.0);

			TOTAL_SNP_ERROR_CHECKED = MAX_SNP_ERROR + ADDITIONAL_MISMATCH + 1;
			TOTAL_SNP_ERROR_CHECKED_Minus = MAX_SNP_ERROR + ADDITIONAL_MISMATCH;
			MinClose = short(log((double)(Temp_One_Read.InsertSize * 2))/log(4.0) + 0.8) + 3;// + MAX_SNP_ERROR;//atoi(argv[1]);
			//MinFar_I = MinClose + 1;//atoi(argv[2]);
			Temp_One_Read.IndelSize = 0;

			if (Temp_One_Read.MatchedD == '+')  {
				InChrPlus++;
				//Temp_One_Read.UnmatchedSeq = ReverseComplement(Temp_One_Read.UnmatchedSeq);
			}
			else InChrMinus++;
			if (Temp_One_Read.MatchedRelPos > CONS_Chr_Size) Temp_One_Read.MatchedRelPos = CONS_Chr_Size;
			if (Temp_One_Read.MatchedRelPos < 1) Temp_One_Read.MatchedRelPos = 0;
			//GetCloseEnd(CurrentChr, Temp_One_Read);
			Temp_One_Read.UP_Close.clear();
			BufferReads.push_back(Temp_One_Read);

			if (BufferReads.size() >= NumberOfReadsPerBuffer) {
			#pragma omp parallel default(shared)
				{
					#pragma omp for
					for (int BufferReadsIndex = 0; BufferReadsIndex < NumberOfReadsPerBuffer; BufferReadsIndex++) {

						for (short RangeIndex = 1; RangeIndex < MaxRangeIndex; RangeIndex++) {
							// cout << Temp_One_Read.Name << "cccccc"<<RangeIndex<<"\t"<<!Temp_One_Read.UP_Close.empty()<< "\n";
							if (!BufferReads[BufferReadsIndex].UP_Close.empty()) {
								//CountFarEnd++;
								//cout <<Temp_One_Read.MatchedRelPos << "zz\tnn" << Temp_One_Read.UP_Close[0].AbsLoc<<endl;
								continue;
								}

							if (BufferReads[BufferReadsIndex].UP_Close.empty() && All_EI_events.size())
							{GetCloseEnd(CurrentChr, BufferReads[BufferReadsIndex],DSizeArray[RangeIndex-1], DSizeArray[RangeIndex], ExonIslandMask);
							  if (BufferReads[BufferReadsIndex].UP_Close.empty())
							  {GetCloseEnd_FirstMismatch(CurrentChr, BufferReads[BufferReadsIndex],DSizeArray[RangeIndex-1], DSizeArray[RangeIndex], ExonIslandMask);}							
							}
						}
					}
				}

			for (int BufferReadsIndex = 0; BufferReadsIndex < NumberOfReadsPerBuffer; BufferReadsIndex++) {

				if (BufferReads[BufferReadsIndex].UP_Close.size()) {
					if (ReportLength < BufferReads[BufferReadsIndex].ReadLength) ReportLength = BufferReads[BufferReadsIndex].ReadLength;
					BufferReads[BufferReadsIndex].Used = false;
					BufferReads[BufferReadsIndex].OK = true;
					//cout << Temp_One_Read.MatchedD << "\t" << Temp_One_Read.UP_Close.size() << "\t";
					CleanUniquePoints(BufferReads[BufferReadsIndex].UP_Close);
					//cout << Temp_One_Read.UP_Close.size() << "\t" << Temp_One_Read.UP_Close[0].Direction << endl;
					if (BufferReads[BufferReadsIndex].UP_Close.size()) {
						Reads.push_back(BufferReads[BufferReadsIndex]);
						if (BufferReads[BufferReadsIndex].MatchedD == '+') GetPlus++;
						else GetMinus++;
					}
					//if (NumReadScanned % 1000 == 0)
					//cout << "NumReadScanned: " << NumReadScanned << "\n"
					//     << "NumReadInChr: " << NumReadInChr << "\n"
					//     << "NumReadStored: " << Reads.size() << "\n"
					//     << InChrPlus << "\t" << InChrMinus << "\t"
					//	  << GetPlus << "\t" << GetMinus << "\t" << GetPlus * 2.0 / NumReadInChr
					//     << "\t" << GetMinus * 2.0 / NumReadInChr
					//     << "\t" << Reads.size() * 1.0 / NumReadInChr << endl;

				if (NotInVector(BufferReads[BufferReadsIndex].Tag, VectorTag)) {
					VectorTag.push_back(BufferReads[BufferReadsIndex].Tag);
				}
				}
			}
			BufferReads.clear();
		}
	}
}


#pragma omp parallel default(shared)
	{
		#pragma omp for
		for (int BufferReadsIndex = 0; BufferReadsIndex < BufferReads.size(); BufferReadsIndex++) {

			for (short RangeIndex = 1; RangeIndex < MaxRangeIndex; RangeIndex++) {
				// cout << Temp_One_Read.Name << "cccccc"<<RangeIndex<<"\t"<<!Temp_One_Read.UP_Close.empty()<< "\n";
				if (!BufferReads[BufferReadsIndex].UP_Close.empty()) {
					//CountFarEnd++;
					//cout <<Temp_One_Read.MatchedRelPos << "zz\tnn" << Temp_One_Read.UP_Close[0].AbsLoc<<endl;
					continue;
				}

				if (BufferReads[BufferReadsIndex].UP_Close.empty() && All_EI_events.size())
				{GetCloseEnd(CurrentChr, BufferReads[BufferReadsIndex], DSizeArray[RangeIndex-1], DSizeArray[RangeIndex], ExonIslandMask);
				  if (BufferReads[BufferReadsIndex].UP_Close.empty())
				    {GetCloseEnd_FirstMismatch(CurrentChr, BufferReads[BufferReadsIndex], DSizeArray[RangeIndex-1], DSizeArray[RangeIndex], ExonIslandMask);				
				    }
				}	
			}
		}
	}

for (int BufferReadsIndex = 0; BufferReadsIndex < BufferReads.size(); BufferReadsIndex++) {

	if (BufferReads[BufferReadsIndex].UP_Close.size()) {
		if (ReportLength < BufferReads[BufferReadsIndex].ReadLength) ReportLength = BufferReads[BufferReadsIndex].ReadLength;
		BufferReads[BufferReadsIndex].Used = false;
		BufferReads[BufferReadsIndex].OK = true;
		//cout << Temp_One_Read.MatchedD << "\t" << Temp_One_Read.UP_Close.size() << "\t";
		CleanUniquePoints(BufferReads[BufferReadsIndex].UP_Close);
		//cout << Temp_One_Read.UP_Close.size() << "\t" << Temp_One_Read.UP_Close[0].Direction << endl;
		if (BufferReads[BufferReadsIndex].UP_Close.size()) {
			Reads.push_back(BufferReads[BufferReadsIndex]);
			if (BufferReads[BufferReadsIndex].MatchedD == '+') GetPlus++;
			else GetMinus++;
		}
		//if (NumReadScanned % 1000 == 0)
		//cout << "NumReadScanned: " << NumReadScanned << "\n"
		//     << "NumReadInChr: " << NumReadInChr << "\n"
		//     << "NumReadStored: " << Reads.size() << "\n"
		//     << InChrPlus << "\t" << InChrMinus << "\t"
		//	  << GetPlus << "\t" << GetMinus << "\t" << GetPlus * 2.0 / NumReadInChr
		//     << "\t" << GetMinus * 2.0 / NumReadInChr
		//     << "\t" << Reads.size() * 1.0 / NumReadInChr << endl;

	if (NotInVector(BufferReads[BufferReadsIndex].Tag, VectorTag)) {
		VectorTag.push_back(BufferReads[BufferReadsIndex].Tag);
	}
	}
}
BufferReads.clear();


	if (FirstChr) {
		cout << "\nThe last read Pindel scanned: \n";
		cout << Temp_One_Read.Name << "\n"
		<< Temp_One_Read.UnmatchedSeq << "\n"
		<< Temp_One_Read.MatchedD << "\t"
		<< TempFragName << "\t"
		<< Temp_One_Read.MatchedRelPos << "\t"
		<< Temp_One_Read.MS << "\t"
		<< Temp_One_Read.InsertSize << "\t"
		<< Temp_One_Read.Tag << "\n\n";
		FirstChr = false;
      //ReportLength = Temp_One_Read.UnmatchedSeq.size();
	} 
	cout << "NumReadScanned:\t" << NumReadScanned << endl;
	cout << "NumReadInChr:\t" << NumReadInChr << endl;
	cout << "NumReadStored:\t" << Reads.size() << endl;
	cout << "NumReadStored / NumReadInChr = " << Reads.size() * 100.0 / NumReadInChr << " %\n" 
	     << "InChrPlus \t" << InChrPlus << "\tGetPlus \t" << GetPlus << "\t" << GetPlus * 100.0 / InChrPlus 
	     << " %\n" << "InChrMinus\t" << InChrMinus  << "\tGetMinus\t" << GetMinus 
	     << "\t" << GetMinus * 100.0 / InChrMinus << " %" << endl;
	inf_ReadSeq.close();
	//0924 if (Reads.size() == 0) return false;
	//cout << LeftReads.size() << endl;
	cout << "sorting tags ... ";
	string Str4Exchange;
	for (short i = 0; i < VectorTag.size(); i++) { //0924 
		for (short j = 1; j < VectorTag.size(); j++) {
			if (VectorTag[i].size() > VectorTag[j].size()) {
				Str4Exchange = VectorTag[i];
				VectorTag[i] = VectorTag[j];
				VectorTag[j] = Str4Exchange; 
			}
			else if (VectorTag[i].size() == VectorTag[j].size()) {
				for (short k = 0; k < VectorTag[i].size(); k++) {
					if ((short)VectorTag[i][k] > (short)VectorTag[j][k]) {
       	         Str4Exchange = VectorTag[i];
						VectorTag[i] = VectorTag[j];
						VectorTag[j] = Str4Exchange;
						break;
					}
				}
			}
		}
	}
	cout << " finished!" << endl;
	return true;
}



vector <string> ReverseComplement(const vector <string> & InputPatterns) {
   vector <string> OutputPatterns;// = InputPatterns;
   unsigned int NumPattern = InputPatterns.size();
   OutputPatterns.resize(NumPattern);
   for (unsigned int i = 0; i < NumPattern; i++) {
      OutputPatterns[i] = ReverseComplement(InputPatterns[i]);    
   }    
   return OutputPatterns;
}


string Reverse(const string & InputPattern) {
   string OutputPattern = InputPattern;
   unsigned int LenPattern = InputPattern.size();
   for (unsigned int j = 0; j < LenPattern; j++)
      OutputPattern[j] = InputPattern[j];
   return OutputPattern;
}

string ReverseComplement(const string & InputPattern) {
   string OutputPattern = InputPattern;
   unsigned int LenPattern = InputPattern.size();
   for (unsigned int j = 0; j < LenPattern; j++)
      OutputPattern[j] = Convert2RC4N[(unsigned int)InputPattern[LenPattern - j - 1]];
   return OutputPattern;
}

//const short MAX_SNP_ERROR = 2;
//const short ADDITIONAL_MISMATCH = 2;
//const short TOTAL_SNP_ERROR_CHECKED = MAX_SNP_ERROR + ADDITIONAL_MISMATCH + 1;

void CheckLeft_Close(const string & TheInput, 
               const string & CurrentReadSeq,
               const vector <unsigned int> Left_PD[],
               const short & BP_Left_Start,
               const short & BP_Left_End,
               const short & CurrentLength,
               vector <UniquePoint> & LeftUP) {
	int Sum;
   if (CurrentLength >= BP_Left_Start && CurrentLength <= BP_Left_End) {
      // put it to LeftUP if unique
		for (short i = 0; i <= MAX_SNP_ERROR; i++) {
			if (Left_PD[i].size() == 1 && CurrentLength >= BP_Left_Start + i) {
				Sum = 0;
				if (ADDITIONAL_MISMATCH) 
		   		for (short j = 1; j <= ADDITIONAL_MISMATCH; j++) 
			   		Sum += Left_PD[i + j].size();

				if (Sum == 0 && i <= (short)(CurrentLength * Seq_Error_Rate + 1)) {
					UniquePoint TempOne;
					TempOne.LengthStr = CurrentLength;
					TempOne.AbsLoc = Left_PD[i][0]; 
					TempOne.Direction = FORWARD;
					TempOne.Strand = ANTISENSE;
					TempOne.Mismatches = i;
					LeftUP.push_back(TempOne);	
					break;
				}
			}
		}
   }
   if (CurrentLength < BP_Left_End) {
      vector <unsigned int> Left_PD_Output[TOTAL_SNP_ERROR_CHECKED];
      const char CurrentChar = CurrentReadSeq[CurrentLength];
      //const int SizeOfCurrent = Left_PD.size();
      unsigned int pos;
		for (int i = 0; i < TOTAL_SNP_ERROR_CHECKED_Minus; i++) {
			int SizeOfCurrent = Left_PD[i].size();
            if (CurrentChar == 'N') {
               for (int j = 0; j < SizeOfCurrent; j++) {
                  pos =  Left_PD[i][j] + 1;
				      if (Match2N[(short)TheInput[pos]] == 'N')
                     Left_PD_Output[i].push_back(pos);
               }         
            }
            else {
               for (int j = 0; j < SizeOfCurrent; j++) {
                  pos =  Left_PD[i][j] + 1;
                  if (TheInput[pos] == CurrentChar)
                     Left_PD_Output[i].push_back(pos);
						else Left_PD_Output[i + 1].push_back(pos); 
               }         
            }			
		}
		
		int SizeOfCurrent = Left_PD[TOTAL_SNP_ERROR_CHECKED_Minus].size();
		if (CurrentChar == 'N') {
			for (int j = 0; j < SizeOfCurrent; j++) {
				pos =  Left_PD[TOTAL_SNP_ERROR_CHECKED_Minus][j] + 1;
				if (Match2N[(short)TheInput[pos]] == 'N')
					Left_PD_Output[TOTAL_SNP_ERROR_CHECKED_Minus].push_back(pos);
			}         
		}
		else {
			for (int j = 0; j < SizeOfCurrent; j++) {
				pos =  Left_PD[TOTAL_SNP_ERROR_CHECKED_Minus][j] + 1;
				if (TheInput[pos] == CurrentChar)
					Left_PD_Output[TOTAL_SNP_ERROR_CHECKED_Minus].push_back(pos);
				//else Left_PD_Output[i + 1].push_back(pos); 
			}         
		}	
		Sum = 0;
		for (int i = 0; i <= MAX_SNP_ERROR; i++) {
			Sum += Left_PD_Output[i].size();
		}
      if (Sum) {
         const short CurrentLengthOutput = CurrentLength + 1;
         CheckLeft_Close(TheInput, CurrentReadSeq, Left_PD_Output,
                   BP_Left_Start, BP_Left_End,
                   CurrentLengthOutput, LeftUP);         
      }
      else return;
   }   
   else return;
}

void CheckRight_Close(const string & TheInput,
                const string & CurrentReadSeq,
                const vector <unsigned int> Right_PD[],
                const short & BP_Right_Start,
                const short & BP_Right_End,
                const short & CurrentLength,
                vector <UniquePoint> & RightUP) {
   short ReadLengthMinus = CurrentReadSeq.size() - 1;      
	int Sum;
   if (CurrentLength >= BP_Right_Start && CurrentLength <= BP_Right_End) {
	   for (short i = 0; i <= MAX_SNP_ERROR; i++) {
		   if (Right_PD[i].size() == 1 && CurrentLength >= BP_Right_Start + i) {
				Sum = 0;
				if (ADDITIONAL_MISMATCH) 
					for (short j = 1; j <= ADDITIONAL_MISMATCH; j++) 
						Sum += Right_PD[i + j].size();
					
				if (Sum == 0 && i <= (short)(CurrentLength * Seq_Error_Rate + 1)) {
					UniquePoint TempOne;
					TempOne.LengthStr = CurrentLength;
					TempOne.AbsLoc = Right_PD[i][0];   
					TempOne.Direction = BACKWARD;
					TempOne.Strand = SENSE;
					TempOne.Mismatches = i;
					RightUP.push_back(TempOne);	
					break;
				}
			}
		}
   }
	
   if (CurrentLength < BP_Right_End) {
      vector <unsigned int> Right_PD_Output[TOTAL_SNP_ERROR_CHECKED];
      const char CurrentChar = CurrentReadSeq[ReadLengthMinus - CurrentLength];
      unsigned int pos;
		
		for (int i = 0; i < TOTAL_SNP_ERROR_CHECKED_Minus; i++) {
			int SizeOfCurrent = Right_PD[i].size();
			if (CurrentChar == 'N') {
				for (int j = 0; j < SizeOfCurrent; j++) {
					pos =  Right_PD[i][j] - 1;
					if (Match2N[(short)TheInput[pos]] == 'N')
						Right_PD_Output[i].push_back(pos);
				}         
			}
			else {
				for (int j = 0; j < SizeOfCurrent; j++) {
					pos =  Right_PD[i][j] - 1;
					if (TheInput[pos] == CurrentChar)
						Right_PD_Output[i].push_back(pos);
					else Right_PD_Output[i + 1].push_back(pos); 
				}         
			}			
		}
		
		int SizeOfCurrent = Right_PD[TOTAL_SNP_ERROR_CHECKED_Minus].size();
		if (CurrentChar == 'N') {
			for (int j = 0; j < SizeOfCurrent; j++) {
				pos =  Right_PD[TOTAL_SNP_ERROR_CHECKED_Minus][j] - 1;
				if (Match2N[(short)TheInput[pos]] == 'N')
					Right_PD_Output[TOTAL_SNP_ERROR_CHECKED_Minus].push_back(pos);
			}         
		}
		else {
			for (int j = 0; j < SizeOfCurrent; j++) {
				pos =  Right_PD[TOTAL_SNP_ERROR_CHECKED_Minus][j] - 1;
				if (TheInput[pos] == CurrentChar)
					Right_PD_Output[TOTAL_SNP_ERROR_CHECKED_Minus].push_back(pos);
				//else Left_PD_Output[i + 1].push_back(pos); 
			}         
		}	
		
		Sum = 0;
		for (int i = 0; i <= MAX_SNP_ERROR; i++) {
			Sum += Right_PD_Output[i].size();
		}
      if (Sum) {
         short CurrentLength_output = CurrentLength + 1;
         CheckRight_Close(TheInput, CurrentReadSeq, Right_PD_Output,
                   BP_Right_Start, BP_Right_End,
                   CurrentLength_output, RightUP);
      }
      else return;
   }
   else return;
}

void CheckLeft_Far(const string & TheInput, 
							const string & CurrentReadSeq,
							const vector <unsigned int> Left_PD[],
							const short & BP_Left_Start,
							const short & BP_Left_End,
							const short & CurrentLength,
							vector <UniquePoint> & LeftUP) {
	int Sum;
   if (CurrentLength >= BP_Left_Start && CurrentLength <= BP_Left_End) {
      // put it to LeftUP if unique
		for (short i = 0; i <= MAX_SNP_ERROR; i++) {
			if (Left_PD[i].size() == 1 && CurrentLength >= BP_Left_Start + i) {
				Sum = 0;
				if (ADDITIONAL_MISMATCH) 
		   		for (short j = 1; j <= ADDITIONAL_MISMATCH; j++) 
			   		Sum += Left_PD[i + j].size();
				
				if (Sum == 0 && i <= (short)(CurrentLength * Seq_Error_Rate + 1)) {
					UniquePoint TempOne;
					TempOne.LengthStr = CurrentLength;
					TempOne.AbsLoc = Left_PD[i][0]; 
					TempOne.Direction = FORWARD;
					TempOne.Strand = SENSE;
					TempOne.Mismatches = i;
					LeftUP.push_back(TempOne);	
					break;
				}
			}
		}
   }
   if (CurrentLength < BP_Left_End) {
      vector <unsigned int> Left_PD_Output[TOTAL_SNP_ERROR_CHECKED];
      const char CurrentChar = CurrentReadSeq[CurrentLength];
      //const int SizeOfCurrent = Left_PD.size();
      unsigned int pos;
		for (int i = 0; i < TOTAL_SNP_ERROR_CHECKED_Minus; i++) {
			int SizeOfCurrent = Left_PD[i].size();
			if (CurrentChar == 'N') {
				for (int j = 0; j < SizeOfCurrent; j++) {
					pos =  Left_PD[i][j] + 1;
					if (Match2N[(short)TheInput[pos]] == 'N')
						Left_PD_Output[i].push_back(pos);
				}         
			}
			else {
				for (int j = 0; j < SizeOfCurrent; j++) {
					pos =  Left_PD[i][j] + 1;
					if (TheInput[pos] == CurrentChar)
						Left_PD_Output[i].push_back(pos);
					else Left_PD_Output[i + 1].push_back(pos); 
				}         
			}			
		}
		
		int SizeOfCurrent = Left_PD[TOTAL_SNP_ERROR_CHECKED_Minus].size();
		if (CurrentChar == 'N') {
			for (int j = 0; j < SizeOfCurrent; j++) {
				pos =  Left_PD[TOTAL_SNP_ERROR_CHECKED_Minus][j] + 1;
				if (Match2N[(short)TheInput[pos]] == 'N')
					Left_PD_Output[TOTAL_SNP_ERROR_CHECKED_Minus].push_back(pos);
			}         
		}
		else {
			for (int j = 0; j < SizeOfCurrent; j++) {
				pos =  Left_PD[TOTAL_SNP_ERROR_CHECKED_Minus][j] + 1;
				if (TheInput[pos] == CurrentChar)
					Left_PD_Output[TOTAL_SNP_ERROR_CHECKED_Minus].push_back(pos);
				//else Left_PD_Output[i + 1].push_back(pos); 
			}         
		}	
		Sum = 0;
		for (int i = 0; i <= MAX_SNP_ERROR; i++) {
			Sum += Left_PD_Output[i].size();
		}
      if (Sum) {
         const short CurrentLengthOutput = CurrentLength + 1;
         CheckLeft_Far(TheInput, CurrentReadSeq, Left_PD_Output,
                   BP_Left_Start, BP_Left_End,
                   CurrentLengthOutput, LeftUP);         
      }
      else return;
   }   
   else return;
}

void CheckRight_Far(const string & TheInput,
							 const string & CurrentReadSeq,
							 const vector <unsigned int> Right_PD[],
							 const short & BP_Right_Start,
							 const short & BP_Right_End,
							 const short & CurrentLength,
							 vector <UniquePoint> & RightUP) {
   short ReadLengthMinus = CurrentReadSeq.size() - 1;      
	int Sum;
   if (CurrentLength >= BP_Right_Start && CurrentLength <= BP_Right_End) {
	   for (short i = 0; i <= MAX_SNP_ERROR; i++) {
		   if (Right_PD[i].size() == 1 && CurrentLength >= BP_Right_Start + i) {
				Sum = 0;
				if (ADDITIONAL_MISMATCH) 
					for (short j = 1; j <= ADDITIONAL_MISMATCH; j++) 
						Sum += Right_PD[i + j].size();
				
				if (Sum == 0 && i <= (short)(CurrentLength * Seq_Error_Rate + 1)) {
					UniquePoint TempOne;
					TempOne.LengthStr = CurrentLength;
					TempOne.AbsLoc = Right_PD[i][0];   
					TempOne.Direction = BACKWARD;
					TempOne.Strand = ANTISENSE;
					TempOne.Mismatches = i;
					RightUP.push_back(TempOne);	
					break;
				}
			}
		}
   }
	
   if (CurrentLength < BP_Right_End) {
      vector <unsigned int> Right_PD_Output[TOTAL_SNP_ERROR_CHECKED];
      const char CurrentChar = CurrentReadSeq[ReadLengthMinus - CurrentLength];
      unsigned int pos;
		
		for (int i = 0; i < TOTAL_SNP_ERROR_CHECKED_Minus; i++) {
			int SizeOfCurrent = Right_PD[i].size();
			if (CurrentChar == 'N') {
				for (int j = 0; j < SizeOfCurrent; j++) {
					pos =  Right_PD[i][j] - 1;
					if (Match2N[(short)TheInput[pos]] == 'N')
						Right_PD_Output[i].push_back(pos);
				}         
			}
			else {
				for (int j = 0; j < SizeOfCurrent; j++) {
					pos =  Right_PD[i][j] - 1;
					if (TheInput[pos] == CurrentChar)
						Right_PD_Output[i].push_back(pos);
					else Right_PD_Output[i + 1].push_back(pos); 
				}         
			}			
		}
		
		int SizeOfCurrent = Right_PD[TOTAL_SNP_ERROR_CHECKED_Minus].size();
		if (CurrentChar == 'N') {
			for (int j = 0; j < SizeOfCurrent; j++) {
				pos =  Right_PD[TOTAL_SNP_ERROR_CHECKED_Minus][j] - 1;
				if (Match2N[(short)TheInput[pos]] == 'N')
					Right_PD_Output[TOTAL_SNP_ERROR_CHECKED_Minus].push_back(pos);
			}         
		}
		else {
			for (int j = 0; j < SizeOfCurrent; j++) {
				pos =  Right_PD[TOTAL_SNP_ERROR_CHECKED_Minus][j] - 1;
				if (TheInput[pos] == CurrentChar)
					Right_PD_Output[TOTAL_SNP_ERROR_CHECKED_Minus].push_back(pos);
				//else Left_PD_Output[i + 1].push_back(pos); 
			}         
		}	
		
		Sum = 0;
		for (int i = 0; i <= MAX_SNP_ERROR; i++) {
			Sum += Right_PD_Output[i].size();
		}
      if (Sum) {
         short CurrentLength_output = CurrentLength + 1;
         CheckRight_Far(TheInput, CurrentReadSeq, Right_PD_Output,
						  BP_Right_Start, BP_Right_End,
						  CurrentLength_output, RightUP);
      }
      else return;
   }
   else return;
}

short CompareTwoReads(const SPLIT_READ & First, const SPLIT_READ & Second) {
   //if (First.MatchedSeqID < Second.MatchedSeqID) return 0;
   //else if (First.MatchedSeqID > Second.MatchedSeqID) return 1;


if (First.BPLeft_Range > Second.BPLeft_Range) return 1;
else if (First.BPLeft_Range< Second.BPLeft_Range) return 0;
      else {
	    if (First.BPRight_Range > Second.BPRight_Range) return 1;
	    else if (First.BPRight_Range < Second.BPRight_Range) return 0;
		  else {
			if (First.IndelSize > Second.IndelSize) return 1; 
			else if (First.IndelSize < Second.IndelSize) return 0;
			      else {
				  if (First.Tag.size() < Second.Tag.size()) return 0;
				  else if (First.Tag.size() > Second.Tag.size()) return 1;
					else if (First.Tag.size() == Second.Tag.size()) {
					    for (unsigned posindex = 0; posindex < First.Tag.size(); posindex++) {
						  if ((short)First.Tag[posindex] < (short)Second.Tag[posindex]) return 0;
						  else if ((short)First.Tag[posindex] > (short)Second.Tag[posindex]) return 1; 
						  }
					}   
				}    
			} 
	    } 
	return 0;
}

short CompareTwoReads_copy(const SPLIT_READ & First, const SPLIT_READ & Second) {
   //if (First.MatchedSeqID < Second.MatchedSeqID) return 0;
   //else if (First.MatchedSeqID > Second.MatchedSeqID) return 1;
   //short FirstDISize = First.DI_str.size();
   //short SecondDISize = Second.DI_str.size();
   //short FirstSISize = First.InsertedStr.size();
   //short SecondSISize = Second.InsertedStr.size();

   if (First.BPLeft > Second.BPLeft) return 1;
   else if (First.BPLeft < Second.BPLeft) return 0;
   else {
      {
         if (First.IndelSize > Second.IndelSize) return 1; 
         else if (First.IndelSize < Second.IndelSize) return 0;
         else
         {
            if (First.Tag.size() < Second.Tag.size()) return 0;
            else if (First.Tag.size() > Second.Tag.size()) return 1;
            else if (First.Tag.size() == Second.Tag.size()) {
               for (unsigned posindex = 0; posindex < First.Tag.size(); posindex++) {
                  if ((short)First.Tag[posindex] < (short)Second.Tag[posindex]) return 0;
                  else if ((short)First.Tag[posindex] > (short)Second.Tag[posindex]) return 1; 
               }
               if (First.MatchedRelPos < Second.MatchedRelPos)  return 0;
               else if (First.MatchedRelPos > Second.MatchedRelPos) return 1;
               else {
		 return 0;
		 /*
                  if (FirstDISize > SecondDISize) return 1;
   		  else if (FirstDISize < SecondDISize) return 0;
   		  else if (FirstDISize != 0) {
                     for (int i = 0; i < FirstDISize; i++) 
                        if ((short)First.DI_str[i] > (short)Second.DI_str[i]) return 1;
                        else if ((short)First.DI_str[i] < (short)Second.DI_str[i]) return 0;
                  }
                  else {
                     if (FirstSISize > SecondSISize) return 1;
                     else if (FirstSISize < SecondSISize) return 0;
                     else if (FirstSISize != 0) {
                        for (int i = 0; i < FirstSISize; i++) 
                           if ((short)First.InsertedStr[i] > (short)Second.InsertedStr[i]) return 1;
                           else if ((short)First.InsertedStr[i] < (short)Second.InsertedStr[i]) return 0;
                     } 
                     else ; 
                  } */
               }
               //return 2;                     
            }   
         }    
      } 
   } 
	return 0;
}


/*short CompareTwoReads(const SPLIT_READ & First, const SPLIT_READ & Second) {
   //if (First.MatchedSeqID < Second.MatchedSeqID) return 0;
   //else if (First.MatchedSeqID > Second.MatchedSeqID) return 1;
   short FirstDISize = First.DI_str.size();
   short SecondDISize = Second.DI_str.size();
   short FirstSISize = First.InsertedStr.size();
   short SecondSISize = Second.InsertedStr.size();

   if (First.BPLeft > Second.BPLeft) return 1;
   else if (First.BPLeft < Second.BPLeft) return 0;
   else {
      {
         if (First.IndelSize > Second.IndelSize) return 1; 
         else if (First.IndelSize < Second.IndelSize) return 0;
         else
         {
            if (First.Tag.size() < Second.Tag.size()) return 0;
            else if (First.Tag.size() > Second.Tag.size()) return 1;
            else if (First.Tag.size() == Second.Tag.size()) {
               for (unsigned posindex = 0; posindex < First.Tag.size(); posindex++) {
                  if ((short)First.Tag[posindex] < (short)Second.Tag[posindex]) return 0;
                  else if ((short)First.Tag[posindex] > (short)Second.Tag[posindex]) return 1; 
               }
               if (First.MatchedRelPos < Second.MatchedRelPos)  return 0;
               else if (First.MatchedRelPos > Second.MatchedRelPos) return 1;
               else {
                  if (FirstDISize > SecondDISize) return 1;
   		  else if (FirstDISize < SecondDISize) return 0;
   		  else if (FirstDISize != 0) {
                     for (int i = 0; i < FirstDISize; i++) 
                        if ((short)First.DI_str[i] > (short)Second.DI_str[i]) return 1;
                        else if ((short)First.DI_str[i] < (short)Second.DI_str[i]) return 0;
                  }
                  else {
                     if (FirstSISize > SecondSISize) return 1;
                     else if (FirstSISize < SecondSISize) return 0;
                     else if (FirstSISize != 0) {
                        for (int i = 0; i < FirstSISize; i++) 
                           if ((short)First.InsertedStr[i] > (short)Second.InsertedStr[i]) return 1;
                           else if ((short)First.InsertedStr[i] < (short)Second.InsertedStr[i]) return 0;
                     } 
                     else return 2; 
                  } 
               }
               //return 2;                     
            }   
         }    
      } 
   } 
	return 0;
}
*/
string Cap2Low(const string & input) {
   string output = input;
   for (unsigned int i = 0; i < output.size(); i++) {
      output[i] = Cap2LowArray[(short)input[i]];   
   }
   return output;
}

bool CheckMismatches(const string & TheInput, 
                     const string & InputReadSeq, 
                     //const unsigned int & Start,
							const UniquePoint & UP
							) {
	//return true; 	short LengthStr;
	//unsigned int AbsLoc; 
	string CurrentReadSeq;
	if (UP.Strand == SENSE) CurrentReadSeq = InputReadSeq;
	else CurrentReadSeq = ReverseComplement(InputReadSeq);
	short CurrentReadLength = CurrentReadSeq.size();
	unsigned int Start = 0;
	
	string BP_On_Read, BP_On_Ref;
	if (UP.Direction == FORWARD) {
		Start = UP.AbsLoc - UP.LengthStr + 1; 
		BP_On_Read = CurrentReadSeq.substr(UP.LengthStr - Min_Perfect_Match_Around_BP, Min_Perfect_Match_Around_BP);
		BP_On_Ref = TheInput.substr(UP.AbsLoc - Min_Perfect_Match_Around_BP + 1, Min_Perfect_Match_Around_BP);
		if (BP_On_Read != BP_On_Ref) return false;
	}
	else if (UP.Direction == BACKWARD) {
		Start = UP.AbsLoc + UP.LengthStr - CurrentReadLength;
		BP_On_Read = CurrentReadSeq.substr(CurrentReadLength - UP.LengthStr, Min_Perfect_Match_Around_BP);
		BP_On_Ref = TheInput.substr(UP.AbsLoc, Min_Perfect_Match_Around_BP);
		if (BP_On_Read != BP_On_Ref) return false;
	}
	
	MAX_ALLOWED_MISMATCHES = (short)(CurrentReadSeq.size() * Seq_Error_Rate + 1); // 

   short NumMismatches = 0;                 // Match2N[(short)'A'] = 'N';    
   
   for (short i = 0; i < CurrentReadLength; i++) {
      if (CurrentReadSeq[i] == N_char) {
         if (Match2N[(short)TheInput[Start + i]] != N_char)  
            NumMismatches++;
      }
      else {
         if (TheInput[Start + i] != CurrentReadSeq[i])
            NumMismatches++;
      }   
   }   
   if (NumMismatches > MAX_ALLOWED_MISMATCHES) return true;
   else return false;                     
}

void OutputDeletions(const vector <SPLIT_READ> & Deletions,
                     const string & TheInput, 
                     const unsigned int & C_S,
                     const unsigned int & C_E,
		     const unsigned int & RealStart,
		     const unsigned int & RealEnd,
                     ofstream & DeletionOutf) {
   //short ReadLength = Deletions[C_S].ReadLength;
   //short ReadLengthMinus = ReadLength - 1;
   unsigned int NumberOfReads = C_E - C_S + 1;
   float LeftScore = 0;
   float RightScore = 0;
   unsigned int LeftS = 1;
   unsigned int RightS = 1;
   unsigned int MaxRightLen = 0;
   unsigned int MaxLeftLen= 0;
   unsigned int NumSupportPerTag[VectorTag.size()];
   for (short i = 0; i < VectorTag.size(); i++) NumSupportPerTag[i] = 0;
   for (unsigned int i = C_S; i <= C_E; i++) {
      for (short j = 0; j < VectorTag.size(); j++) {
	if (Deletions[i].Tag == VectorTag[j]) NumSupportPerTag[j]++;
      }
      if (Deletions[i].MatchedD == Plus) {
         LeftScore += Deletions[i].score;
         LeftS++;
      }
      if (Deletions[i].MatchedD == Minus) {
         RightScore += Deletions[i].score;
         RightS++;
      }
      //########
      if (MaxLeftLen<(Deletions[i].BP + 1))
      {
    	  MaxLeftLen=Deletions[i].BP + 1;
      }
      if (MaxRightLen<(Deletions[i].ReadLength-Deletions[i].BP-1 ))
      {
    	  MaxRightLen=Deletions[i].ReadLength-Deletions[i].BP-1;
      }
      //########

   }
   unsigned int EasyScore = LeftS * RightS;
   double PreciseScore = (LeftScore + RightScore) * (-1);
   short GapSize =0;
   if (Deletions[C_S].IndelSize < 14) GapSize = Deletions[C_S].IndelSize;
   else GapSize = 13 + (int)log10(Deletions[C_S].IndelSize-20)+10;
                        
   DeletionOutf << "####################################################################################################" << endl;
   DeletionOutf << NumberOfDeletionsInstances << "\tD " << Deletions[C_S].IndelSize// << " bases " 
                << "\tChrID " << Deletions[C_S].FragName 
                << "\tBP " << Deletions[C_S].BPLeft + 1 << "\t" << Deletions[C_S].BPRight + 1 
                << "\tBP_range " << RealStart + 1 << "\t" << RealEnd + 1  
                << "\tSupports " << NumberOfReads 
                << "\t+ " << LeftS - 1 
                << "\t- " << RightS - 1 
                << "\tS1 " << EasyScore << "\tS2 " << PreciseScore
                << "\tLL " << MaxLeftLen << "\tRL " << MaxRightLen ;

   int SUM_MS = 0;
   for (unsigned int i = C_S; i <= C_E; i++) SUM_MS += Deletions[i].MS;
   DeletionOutf << "\tSUM_MS " << SUM_MS;

   short NumberSupSamples = 0; 
   for (short i = 0; i < VectorTag.size(); ++i)
     if (NumSupportPerTag[i]) ++NumberSupSamples;
   DeletionOutf << "\tNumSupSamples " << NumberSupSamples;
   for (short i = 0; i < VectorTag.size(); i++)
     if (NumSupportPerTag[i])
        DeletionOutf << "\t" << VectorTag[i] << " " << NumSupportPerTag[i];
   DeletionOutf << endl;
    
   //DeletionOutf << TheInput.substr(Deletions[C_S].Left - ReportLength + Deletions[C_S].BP + 1, ReportLength * 2) << endl;// << endl;// ReportLength                 
   DeletionOutf << TheInput.substr(Deletions[C_S].Left - ReportLength + Deletions[C_S].BP + 1, ReportLength);// << endl;// ReportLength    
   if (Deletions[C_S].IndelSize >= 14) {
      DeletionOutf << Cap2Low(TheInput.substr(Deletions[C_S].Left + Deletions[C_S].BP + 1, 10))
                   << "<" << Deletions[C_S].IndelSize - 20 << ">"
                   << Cap2Low(TheInput.substr(Deletions[C_S].Right - Deletions[C_S].ReadLength + Deletions[C_S].BP - 8, 10));
   }   
   else DeletionOutf << Cap2Low(TheInput.substr(Deletions[C_S].Left + Deletions[C_S].BP + 1, GapSize));             
   DeletionOutf << TheInput.substr(Deletions[C_S].Left + Deletions[C_S].BP + 1 + Deletions[C_S].IndelSize, ReportLength - GapSize) << endl;// ReportLength
   short SpaceBeforeReadSeq;    
   for (unsigned int GoodIndex = C_S; GoodIndex <= C_E; GoodIndex++) { 
      SpaceBeforeReadSeq = ReportLength - Deletions[GoodIndex].BP - 1;
      
      for (int i = 0; i < SpaceBeforeReadSeq; i++) DeletionOutf << " ";
      short SpaceBeforeD = ReportLength + ReportLength - SpaceBeforeReadSeq - Deletions[GoodIndex].ReadLength;
      if (Deletions[GoodIndex].MatchedD == Minus) {
         DeletionOutf << Deletions[GoodIndex].UnmatchedSeq.substr(0, Deletions[GoodIndex].BP + 1);// << endl;
         for (int i = 0; i < GapSize; i++) DeletionOutf << " ";    
         DeletionOutf << Deletions[GoodIndex].UnmatchedSeq.substr(Deletions[GoodIndex].BP + 1, Deletions[GoodIndex].ReadLength - Deletions[GoodIndex].BP);// << endl;
      }
      else {
         DeletionOutf << ReverseComplement(Deletions[GoodIndex].UnmatchedSeq).substr(0, Deletions[GoodIndex].BP + 1);// << endl; 
         for (int i = 0; i < GapSize; i++) DeletionOutf << " ";  
         DeletionOutf << ReverseComplement(Deletions[GoodIndex].UnmatchedSeq).substr(Deletions[GoodIndex].BP + 1, Deletions[GoodIndex].ReadLength - Deletions[GoodIndex].BP);// << endl;
      } 
      for (int i = 0; i < SpaceBeforeD; i++) DeletionOutf << " ";
      DeletionOutf << "\t" << Deletions[GoodIndex].MatchedD << "\t" 
                   << Deletions[GoodIndex].MatchedRelPos 
		   << "\t" << Deletions[GoodIndex].MS
                   << "\t" << Deletions[GoodIndex].Tag 
		   << "\t" <<  Deletions[GoodIndex].Name << endl;
                   //<< "\t" << Deletions[C_S].BPLeft
                   //<< "\t" << Deletions[C_S].BPRight << endl; 
   }     
}


void SortOutputD(const uint64_t & NumBoxes, const string & CurrentChr, vector <SPLIT_READ> & Reads,vector <unsigned> Deletions[], ofstream & DeletionOutf) {
   cout << "Sorting and outputing Deletions ..." << endl;
   unsigned int DeletionsNum;
   short CompareResult;
   unsigned Temp4Exchange;
   unsigned int countiii=0;
	/*
   unsigned int C_S = 0;
   unsigned int C_E = 0;
   unsigned int C_BP_Left;// = GoodSIs[0].BPLeft;
   unsigned int C_BP_Right;// = GoodSIs[0].BPRight;
   unsigned int C_Indelsize;
	 */
   unsigned int GoodNum;
   vector <SPLIT_READ> GoodIndels;
   vector <Indel4output> IndelEvents;
   //cout <<"numboxes"<<NumBoxes<<endl;
   for (uint64_t Box_index = 0; Box_index < NumBoxes; Box_index++) {
      if (!Deletions[Box_index].empty()) {
         DeletionsNum = Deletions[Box_index].size();
	 countiii=countiii+DeletionsNum;
	 //cout << "DeletionsNum" << DeletionsNum<<endl;
         for (unsigned int First = 0; First < DeletionsNum - 1; First++) {
            if (Reads[Deletions[Box_index][First]].OK) {
               for (unsigned int Second = First + 1; Second < DeletionsNum; Second++) {
                  if (Reads[Deletions[Box_index][Second]].OK) {
		    //countiii++;
                     CompareResult = CompareTwoReads(Reads[Deletions[Box_index][First]],Reads[Deletions[Box_index][Second]]);
                     if (CompareResult == 1) {
  	                     Temp4Exchange = Deletions[Box_index][First];
  	                     Deletions[Box_index][First] = Deletions[Box_index][Second];
  	                     Deletions[Box_index][Second] = Temp4Exchange;
                     }
                     //else if (CompareResult == 2) {}; yanju
                  }
               }
            }
         }
         
         GoodIndels.clear();
	     IndelEvents.clear();
	     
         for (unsigned int First = 0; First < DeletionsNum; First++) {
            if (Reads[Deletions[Box_index][First]].OK) GoodIndels.push_back(Reads[Deletions[Box_index][First]]);
         }
         GoodNum = GoodIndels.size();         
   //    cout << GoodNum << endl;
         Indel4output OneIndelEvent; 
         OneIndelEvent.Start = 0;
	 OneIndelEvent.End = 0;
         OneIndelEvent.Support = OneIndelEvent.End - OneIndelEvent.Start + 1;
	 OneIndelEvent.BPLeft_Range =  GoodIndels[0].BPLeft_Range;
         OneIndelEvent.BPRight_Range =  GoodIndels[0].BPRight_Range;
	 OneIndelEvent.IndelSize =  GoodIndels[0].IndelSize;
	 OneIndelEvent.WhetherReport = true;
         for (unsigned int GoodIndex = 1; GoodIndex < GoodNum; GoodIndex++) {
	if (GoodIndels[GoodIndex].BPLeft_Range == OneIndelEvent.BPLeft_Range  && GoodIndels[GoodIndex].BPRight_Range == OneIndelEvent.BPRight_Range && GoodIndels[GoodIndex].IndelSize == OneIndelEvent.IndelSize)
               OneIndelEvent.End = GoodIndex;
	    else  {
                   //OneIndelEvent.RealStart = OneIndelEvent.BPLeft;
                   //OneIndelEvent.RealEnd = OneIndelEvent.BPRight;
                   OneIndelEvent.Support = OneIndelEvent.End - OneIndelEvent.Start + 1;
                   //GetRealStart4Deletion(CurrentChr, OneIndelEvent.RealStart, OneIndelEvent.RealEnd);
	           IndelEvents.push_back(OneIndelEvent);
                   OneIndelEvent.Start = GoodIndex;
		   OneIndelEvent.End = GoodIndex;
		   OneIndelEvent.BPLeft_Range =  GoodIndels[GoodIndex].BPLeft_Range;
		   OneIndelEvent.BPRight_Range =  GoodIndels[GoodIndex].BPRight_Range;
		   OneIndelEvent.IndelSize =  GoodIndels[GoodIndex].IndelSize;
 
            }
         }
	         
         //OneIndelEvent.RealStart = OneIndelEvent.BPLeft;
         //OneIndelEvent.RealEnd = OneIndelEvent.BPRight;
         OneIndelEvent.Support = OneIndelEvent.End - OneIndelEvent.Start + 1;
         //GetRealStart4Deletion(CurrentChr, OneIndelEvent.RealStart, OneIndelEvent.RealEnd);
         IndelEvents.push_back(OneIndelEvent);
//	     cout << "IndelEvent: " << IndelEvents.size() << endl;
	     //string IndelType;
	     unsigned int RealStart;
	     unsigned int RealEnd;
	     //bool WhetherDeletion = true;
	     string IndelStr;
	     unsigned int Max_Support;
	     unsigned int Max_Support_Index;

	    if (IndelEvents.size()) {
            for (unsigned EventIndex = 0; EventIndex < IndelEvents.size(); EventIndex++) {
               if (IndelEvents[EventIndex].WhetherReport) {
                 /* RealStart = IndelEvents[EventIndex].RealStart;
                  RealEnd = IndelEvents[EventIndex].RealEnd;
                  Max_Support = IndelEvents[EventIndex].Support;
                  Max_Support_Index = EventIndex;
                  for (unsigned EventIndex_left = 0; EventIndex_left < IndelEvents.size(); EventIndex_left++) {
                     if (IndelEvents[EventIndex_left].WhetherReport == false) continue;
                     else if (IndelEvents[EventIndex_left].RealStart != RealStart) continue;
                     else if (IndelEvents[EventIndex_left].RealEnd != RealEnd) continue;
                     else {
                        IndelEvents[EventIndex_left].WhetherReport = false;
                        if (IndelEvents[EventIndex_left].Support > Max_Support) {
                           Max_Support = IndelEvents[EventIndex_left].Support;
                           Max_Support_Index = EventIndex_left;
                        } 
                     }
                  }*/
                  // report max one
                  // yanju
                  //if (IndelEvents[Max_Support_Index].Support <=4  )
                  //{BalanceCutoff = 50000000;}
                  //else if(IndelEvents[Max_Support_Index].Support >4 )
                  //{BalanceCutoff = 50;}
                  //yanju
                  //if (IndelEvents[EventIndex].Support >= NumRead2ReportCutOff) {
		     //if (GoodIndels[IndelEvents[Max_Support_Index].Start].IndelSize < BalanceCutoff) 
			  {
		             OutputDeletions(GoodIndels, CurrentChr, 
		                             IndelEvents[EventIndex].Start, 
				             IndelEvents[EventIndex].End, 
				             IndelEvents[EventIndex].BPLeft_Range, IndelEvents[EventIndex].BPRight_Range, DeletionOutf);
		             NumberOfDeletionsInstances++;
	             }
		  //}
               }
            }
         }
      }   // if (!Deletions[Box_index].empty())
   } // for (uint64_t Box_index = 0; Box_index < NumBoxes; Box_index++)
   //cout << "Deletions: " << NumberOfDeletionsInstances << endl;
   cout << "Deletions: " << NumberOfDeletionsInstances << "\tdelenum: \t" <<countiii<<endl;
}



bool NotInVector(const string & OneTag, const vector <string> & VectorTag) {
  for (unsigned i = 0; i < VectorTag.size(); i++) {
     if (OneTag == VectorTag[i]) return false;
  }
  return true;
}
short FragementMismatchDistance (const string & TheInput, unsigned int & Start, unsigned int & End,const string & UnMatched, short & BP) {
   unsigned int Start_Pos = Start + SpacerBeforeAfter;
   unsigned int End_Pos = End + SpacerBeforeAfter - 1;
   int Mismatch_Left=0;
   int Mismatch_Right=0;
  for (unsigned int PosIndex=BP; PosIndex>=1; PosIndex--)
  {
    //cout<<"1"<<UnMatched[PosIndex] << TheInput[End_Pos-(BP-PosIndex)]<<endl;
    if (UnMatched[PosIndex] != TheInput[End_Pos-(BP-PosIndex)])
    {Mismatch_Left++;
    if (Mismatch_Left>1)
    break;
    }
  }
  for (unsigned int PosIndex=1; PosIndex<UnMatched.size()-BP; PosIndex++)
  {
    //cout<<"2"<<UnMatched[BP+PosIndex] << TheInput[Start_Pos+PosIndex]<<endl;
    if (UnMatched[BP+PosIndex] != TheInput[Start_Pos+PosIndex])
    {Mismatch_Right++;
    if(Mismatch_Right>1)
      break;
    }
  }
  if (Mismatch_Left>1 && Mismatch_Right>1 )
  {return 1;}
  else {return 0;}
}
void GetRealStart4Deletion(const string & TheInput, unsigned int & RealStart, unsigned int & RealEnd,const string & UnMatched, short & BP) {
   unsigned int PosIndex = RealStart + SpacerBeforeAfter;
   unsigned int Start = PosIndex + 1;
   unsigned int End = RealEnd + SpacerBeforeAfter - 1;
   unsigned int BPIndex = BP;
   unsigned int ReturnBP;
   //cout<<PosIndex<<"\t"<<End<<"\t"<<UnMatched<<endl;
   //cout<<"**"<<TheInput[PosIndex]<<TheInput[End]<<"\t"<<UnMatched[BPIndex]<<"\t"<<BPIndex<<endl;   
   //cout<<"**"<<TheInput[PosIndex]<<TheInput[End]<<"\t"<<UnMatched[BPIndex-1]<<"\t"<<BPIndex-1<<endl;
   //cout<<"**"<<TheInput[PosIndex]<<TheInput[End]<<"\t"<<UnMatched[BPIndex-2]<<"\t"<<BPIndex-2<<endl;
   while ((TheInput[PosIndex] == TheInput[End] || UnMatched[BPIndex]==TheInput[End]) && (BPIndex>0)) {

      --PosIndex;
      --End;
      --BPIndex;
  // cout<<PosIndex<<"*"<<End<<"*"<<TheInput[PosIndex]<<TheInput[End]<<"\t"<<UnMatched[BPIndex]<<"\t"<<BPIndex<<endl;   
    
 
   }
   //cout <<"%%"<<endl;
   RealStart = PosIndex - SpacerBeforeAfter;
   ReturnBP=BPIndex;
   
   PosIndex = RealEnd + SpacerBeforeAfter;
   BPIndex = BP+1;
   while ((TheInput[PosIndex] == TheInput[Start] || UnMatched[BPIndex]==TheInput[Start]) && (BPIndex< UnMatched.size())) {
      ++PosIndex;
      ++Start;
      ++BPIndex;
      //cout<<TheInput[PosIndex]<<TheInput[Start]<<"\t"<<UnMatched[BPIndex]<<"\t"<<BPIndex<<endl;
   }

   RealEnd = PosIndex - SpacerBeforeAfter;
   
   BP=ReturnBP;
}

void AdjustFarEnd(const string & TheInput, SPLIT_READ & Temp_One_Read) {
  unsigned int FarAbsLoc;
  unsigned int CloseAbsLoc;
  unsigned int FarLen;

	FarLen = Temp_One_Read.UP_Far[Temp_One_Read.UP_Far.size()-1].LengthStr;
	FarAbsLoc = Temp_One_Read.UP_Far[Temp_One_Read.UP_Far.size()-1].AbsLoc-1;
	CloseAbsLoc = Temp_One_Read.UP_Close[Temp_One_Read.UP_Close.size()-1].AbsLoc;
	if (CloseAbsLoc!=FarAbsLoc)
	{
	while (TheInput[FarAbsLoc] == TheInput[CloseAbsLoc]) {
	  //cout << TheInput[FarAbsLoc] <<"\t"<< TheInput[CloseAbsLoc]<<endl;
	  --FarAbsLoc;
	  --CloseAbsLoc;
	  ++FarLen;
	}
	if (FarLen > Temp_One_Read.UP_Far[Temp_One_Read.UP_Far.size()-1].LengthStr )
	{
	Temp_One_Read.UP_Far.push_back(Temp_One_Read.UP_Far[0]);
	Temp_One_Read.UP_Far[Temp_One_Read.UP_Far.size()-1].LengthStr=FarLen;
	Temp_One_Read.UP_Far[Temp_One_Read.UP_Far.size()-1].AbsLoc=FarAbsLoc+1;
	}
	}
  
 
}

void AdjustCloseEnd(const string & TheInput, SPLIT_READ & Temp_One_Read) {
  unsigned int FarAbsLoc;
  unsigned int CloseAbsLoc;
  unsigned int CloseLen;

	CloseLen = Temp_One_Read.UP_Close[Temp_One_Read.UP_Close.size()-1].LengthStr;
	FarAbsLoc = Temp_One_Read.UP_Far[Temp_One_Read.UP_Far.size()-1].AbsLoc;
	CloseAbsLoc = Temp_One_Read.UP_Close[Temp_One_Read.UP_Close.size()-1].AbsLoc-1;
	if (CloseAbsLoc!=FarAbsLoc)
	{
	while (TheInput[FarAbsLoc] == TheInput[CloseAbsLoc]) {
	  --FarAbsLoc;
	  --CloseAbsLoc;
	  ++CloseLen;
	}
	if (CloseLen > Temp_One_Read.UP_Far[Temp_One_Read.UP_Far.size()-1].LengthStr )
	{
	Temp_One_Read.UP_Close.push_back(Temp_One_Read.UP_Close[0]);
	Temp_One_Read.UP_Close[Temp_One_Read.UP_Close.size()-1].LengthStr=CloseLen;
	Temp_One_Read.UP_Close[Temp_One_Read.UP_Close.size()-1].AbsLoc=CloseAbsLoc+1;
	}
	}
  
 
}


void GetCloseEnd(const string & CurrentChr, SPLIT_READ & Temp_One_Read, const int & RangePrevious, const int & Range, const string & ExonIslandMask) {
	Temp_One_Read.ReadLength = Temp_One_Read.UnmatchedSeq.size();
	Temp_One_Read.ReadLengthMinus = Temp_One_Read.ReadLength - 1;
	char LeftChar, RightChar;
	string CurrentReadSeq;
	vector <unsigned int> PD[TOTAL_SNP_ERROR_CHECKED];
	vector <UniquePoint> UP;
	//char Direction;
	int Start, End;
	short BP_Start;// = MinClose;
	short BP_End;// = ReadLength - MinClose;
	
	for (int i = 0; i < TOTAL_SNP_ERROR_CHECKED; i++) {
		PD[i].clear();
	}
	UP.clear();
	Temp_One_Read.UP_Close.clear();
	MinClose = short(log((double)(Temp_One_Read.InsertSize * 2))/log(4.0) + 0.8) + 3;
	BP_Start = MinClose;
	BP_End = Temp_One_Read.ReadLength - MinClose;
	//Temp_One_Read.OK = true;
	if (Temp_One_Read.MatchedD == '+') {
		CurrentReadSeq = ReverseComplement(Temp_One_Read.UnmatchedSeq);
		Start = Temp_One_Read.MatchedRelPos + SpacerBeforeAfter - Temp_One_Read.ReadLength + RangePrevious;
		End = Start + Range - RangePrevious + Temp_One_Read.ReadLength;
		LeftChar = CurrentReadSeq[0];
		if (LeftChar != 'N') {
			for (int pos = Start; pos < End; pos++) {
				if (ExonIslandMask[pos] != X_char) {
					if (CurrentChr[pos] == LeftChar) {
						PD[0].push_back(pos);
					}
					//else PD[1].push_back(pos);
				}
			}
		}
		/*else { //Match2N[(short)'A'] = 'N';
			for (int pos = Start; pos < End; pos++) {
				if (ExonIslandMask[pos] != X_char) {
					if (Match2N[(short)CurrentChr[pos]] == 'N') {
						PD[0].push_back(pos);
					}

				}
				//else Left_PD[1].push_back(pos);
			}
		}*/
		CheckLeft_Close(CurrentChr, CurrentReadSeq, PD, BP_Start, BP_End, FirstBase, UP);
		//Direction = '-';
		for (unsigned LeftUP_index = 0; LeftUP_index < UP.size(); LeftUP_index++) {
			if (CheckMismatches(CurrentChr, Temp_One_Read.UnmatchedSeq, UP[LeftUP_index])) {
				Temp_One_Read.Used = false;
				Temp_One_Read.UP_Close.push_back(UP[LeftUP_index]);
			}
		}
		UP.clear();
	}
	else if (Temp_One_Read.MatchedD == '-') {
		CurrentReadSeq = Temp_One_Read.UnmatchedSeq;
		End = Temp_One_Read.MatchedRelPos + SpacerBeforeAfter + Temp_One_Read.ReadLength - RangePrevious;
		Start = End - Range + RangePrevious- Temp_One_Read.ReadLength;
		RightChar = CurrentReadSeq[CurrentReadSeq.size() - 1];
		if (RightChar != 'N') {
			for (int pos = Start; pos < End; pos++) {
				if (ExonIslandMask[pos] != X_char) {
					if (CurrentChr[pos] == RightChar) {
						PD[0].push_back(pos);
						}
					//else PD[1].push_back(pos);
					}
				}
			}
		/*else { //Match2N[(short)'A'] = 'N';
			for (int pos = Start; pos < End; pos++) {
				if (ExonIslandMask[pos] != X_char){
					if (Match2N[(short)CurrentChr[pos]] == 'N') {
						PD[0].push_back(pos);
					}
				}
				//else Left_PD[1].push_back(pos);
			}
		}*/
		CheckRight_Close(CurrentChr, CurrentReadSeq, PD, BP_Start, BP_End, FirstBase, UP);
		//Direction = '+';
		for (unsigned RightUP_index = 0; RightUP_index < UP.size(); RightUP_index++) {
			if (CheckMismatches(CurrentChr, Temp_One_Read.UnmatchedSeq, UP[RightUP_index])) {
				Temp_One_Read.Used = false;
				Temp_One_Read.UP_Close.push_back(UP[RightUP_index]);
			} 
		}
		UP.clear();
	}	
}

void GetCloseEnd_FirstMismatch(const string & CurrentChr, SPLIT_READ & Temp_One_Read, const int & RangePrevious, const int & Range, const string & ExonIslandMask) {
	Temp_One_Read.ReadLength = Temp_One_Read.UnmatchedSeq.size();
	Temp_One_Read.ReadLengthMinus = Temp_One_Read.ReadLength - 1;
	char LeftChar, RightChar;
	string CurrentReadSeq;
	vector <unsigned int> PD[TOTAL_SNP_ERROR_CHECKED];
	vector <UniquePoint> UP;
	//char Direction;
	int Start, End;
	short BP_Start;// = MinClose;
	short BP_End;// = ReadLength - MinClose;
	
	for (int i = 0; i < TOTAL_SNP_ERROR_CHECKED; i++) {
		PD[i].clear();
	}
	UP.clear();
	Temp_One_Read.UP_Close.clear();
	MinClose = short(log((double)(Temp_One_Read.InsertSize * 2))/log(4.0) + 0.8) + 3;
	BP_Start = MinClose;
	BP_End = Temp_One_Read.ReadLength - MinClose;
	//Temp_One_Read.OK = true;
	if (Temp_One_Read.MatchedD == '+') {
		CurrentReadSeq = ReverseComplement(Temp_One_Read.UnmatchedSeq);
		Start = Temp_One_Read.MatchedRelPos + SpacerBeforeAfter - Temp_One_Read.ReadLength + RangePrevious;
		End = Start + Range - RangePrevious + Temp_One_Read.ReadLength;
		LeftChar = CurrentReadSeq[0];
		if (LeftChar != 'N') {
			for (int pos = Start; pos < End; pos++) {
				if (ExonIslandMask[pos] != X_char) {
					if (CurrentChr[pos] == LeftChar) {
						//PD[0].push_back(pos);
					}
					else PD[1].push_back(pos);
				}
			}
		}
		else { //Match2N[(short)'A'] = 'N';
			for (int pos = Start; pos < End; pos++) {
				if (ExonIslandMask[pos] != X_char) {
					if (Match2N[(short)CurrentChr[pos]] == 'N') {
						PD[0].push_back(pos);
					}

				}
				//else Left_PD[1].push_back(pos);
			}
		}
		CheckLeft_Close(CurrentChr, CurrentReadSeq, PD, BP_Start, BP_End, FirstBase, UP);
		//Direction = '-';
		for (unsigned LeftUP_index = 0; LeftUP_index < UP.size(); LeftUP_index++) {
			if (CheckMismatches(CurrentChr, Temp_One_Read.UnmatchedSeq, UP[LeftUP_index])) {
				Temp_One_Read.Used = false;
				Temp_One_Read.UP_Close.push_back(UP[LeftUP_index]);
			}
		}
		UP.clear();
	}
	else if (Temp_One_Read.MatchedD == '-') {
		CurrentReadSeq = Temp_One_Read.UnmatchedSeq;
		End = Temp_One_Read.MatchedRelPos + SpacerBeforeAfter + Temp_One_Read.ReadLength - RangePrevious;
		Start = End - Range + RangePrevious- Temp_One_Read.ReadLength;
		RightChar = CurrentReadSeq[CurrentReadSeq.size() - 1];
		if (RightChar != 'N') {
			for (int pos = Start; pos < End; pos++) {
				if (ExonIslandMask[pos] != X_char) {
					if (CurrentChr[pos] == RightChar) {
						//PD[0].push_back(pos);
						}
					else PD[1].push_back(pos);
					}
				}
			}
		else { //Match2N[(short)'A'] = 'N';
			for (int pos = Start; pos < End; pos++) {
				if (ExonIslandMask[pos] != X_char){
					if (Match2N[(short)CurrentChr[pos]] == 'N') {
						PD[0].push_back(pos);
					}
				}
				//else Left_PD[1].push_back(pos);
			}
		}
		CheckRight_Close(CurrentChr, CurrentReadSeq, PD, BP_Start, BP_End, FirstBase, UP);
		//Direction = '+';
		for (unsigned RightUP_index = 0; RightUP_index < UP.size(); RightUP_index++) {
			if (CheckMismatches(CurrentChr, Temp_One_Read.UnmatchedSeq, UP[RightUP_index])) {
				Temp_One_Read.Used = false;
				Temp_One_Read.UP_Close.push_back(UP[RightUP_index]);
			} 
		}
		UP.clear();
	}	
}

void DIGetCloseEnd(const string & CurrentChr, SPLIT_READ & Temp_One_Read, const int & RangePrevious, const int & Range) {
	Temp_One_Read.ReadLength = Temp_One_Read.UnmatchedSeq.size();
	Temp_One_Read.ReadLengthMinus = Temp_One_Read.ReadLength - 1;
	char LeftChar, RightChar;
	string CurrentReadSeq;
	vector <unsigned int> PD[TOTAL_SNP_ERROR_CHECKED];
	vector <UniquePoint> UP;
	//char Direction;
	int Start, End;
	short BP_Start;// = MinClose;
	short BP_End;// = ReadLength - MinClose;

	for (int i = 0; i < TOTAL_SNP_ERROR_CHECKED; i++) {
		PD[i].clear();
	}
	UP.clear();
	Temp_One_Read.UP_Close.clear();
	MinClose = short(log((double)(Temp_One_Read.InsertSize * 2))/log(4.0) + 0.8) + 3;
	BP_Start = MinClose;
	BP_End = Temp_One_Read.ReadLength - MinClose;
	//Temp_One_Read.OK = true;
	if (Temp_One_Read.MatchedD == '+') {
		CurrentReadSeq = ReverseComplement(Temp_One_Read.UnmatchedSeq);
		Start = Temp_One_Read.MatchedRelPos + SpacerBeforeAfter + Temp_One_Read.ReadLength + RangePrevious;
		End = Start + Range - RangePrevious + Temp_One_Read.ReadLength;
		LeftChar = CurrentReadSeq[0];
		if (LeftChar != 'N') {
			for (int pos = Start; pos < End; pos++) {
				//if (ExonIslandMask[pos] == EI_char) {
					if (CurrentChr[pos] == LeftChar) {
						PD[0].push_back(pos);
					}
					else PD[1].push_back(pos);
				//}
			}
		}
		else { //Match2N[(short)'A'] = 'N';
			for (int pos = Start; pos < End; pos++) {
				//if (ExonIslandMask[pos] == EI_char) {
					if (Match2N[(short)CurrentChr[pos]] == 'N') {
						PD[0].push_back(pos);
					}

				//}
				//else Left_PD[1].push_back(pos);
			}
		}
		CheckLeft_Close(CurrentChr, CurrentReadSeq, PD, BP_Start, BP_End, FirstBase, UP);
		//Direction = '-';
		for (unsigned LeftUP_index = 0; LeftUP_index < UP.size(); LeftUP_index++) {
			if (CheckMismatches(CurrentChr, Temp_One_Read.UnmatchedSeq, UP[LeftUP_index])) {
				Temp_One_Read.Used = false;
				Temp_One_Read.UP_Close.push_back(UP[LeftUP_index]);
			}
		}
		UP.clear();
	}
	else if (Temp_One_Read.MatchedD == '-') {
		CurrentReadSeq = Temp_One_Read.UnmatchedSeq;
		End = Temp_One_Read.MatchedRelPos + SpacerBeforeAfter - RangePrevious;
		Start = End - Range + RangePrevious - Temp_One_Read.ReadLength;
		RightChar = CurrentReadSeq[CurrentReadSeq.size() - 1];
		if (RightChar != 'N') {
			for (int pos = Start; pos < End; pos++) {
				//if (ExonIslandMask[pos] == EI_char) {
					if (CurrentChr[pos] == RightChar) {
						PD[0].push_back(pos);
						}
					else PD[1].push_back(pos);
					//}
				}
			}
		else { //Match2N[(short)'A'] = 'N';
			for (int pos = Start; pos < End; pos++) {
				//if (ExonIslandMask[pos] == EI_char){
					if (Match2N[(short)CurrentChr[pos]] == 'N') {
						PD[0].push_back(pos);
					}
				//}
				//else Left_PD[1].push_back(pos);
			}
		}
		CheckRight_Close(CurrentChr, CurrentReadSeq, PD, BP_Start, BP_End, FirstBase, UP);
		//Direction = '+';
		for (unsigned RightUP_index = 0; RightUP_index < UP.size(); RightUP_index++) {
			if (CheckMismatches(CurrentChr, Temp_One_Read.UnmatchedSeq, UP[RightUP_index])) {
				Temp_One_Read.Used = false;
				Temp_One_Read.UP_Close.push_back(UP[RightUP_index]);
			}
		}
		UP.clear();
	}
}

void GetFarEnd_SingleStrand(const string & CurrentChr, SPLIT_READ & Temp_One_Read,  const int & RangePrevious, const int & Range, const string & ExonIslandMask) {
	Temp_One_Read.ReadLength = Temp_One_Read.UnmatchedSeq.size();
	Temp_One_Read.ReadLengthMinus = Temp_One_Read.ReadLength - 1;
	char LeftChar, RightChar;
	string CurrentReadSeq;
	vector <unsigned int> PD[TOTAL_SNP_ERROR_CHECKED];
	vector <UniquePoint> UP;
	//char Direction;
	int Start, End;
	short BP_Start;// = MinClose;
	short BP_End;// = ReadLength - MinClose;
	
	for (int i = 0; i < TOTAL_SNP_ERROR_CHECKED; i++) {
		PD[i].clear();
	}
	UP.clear();
	//Temp_One_Read.UP_Close.clear();
	MinClose = short(log((double)(Temp_One_Read.InsertSize * 2))/log(4.0) + 0.8) + 3;
	BP_Start = MinClose;
	BP_End = Temp_One_Read.ReadLength - MinClose;
	//Temp_One_Read.OK = true;
	if (Temp_One_Read.MatchedD == '-') {
		//CurrentReadSeq = ReverseComplement(Temp_One_Read.UnmatchedSeq);
		CurrentReadSeq = Temp_One_Read.UnmatchedSeq;

		End = Temp_One_Read.UP_Close[Temp_One_Read.UP_Close.size()-1].AbsLoc  -  mini_intron_size - RangePrevious + Temp_One_Read.ReadLength;
		Start = End - Range +  RangePrevious ;
		LeftChar = CurrentReadSeq[0];
		if (LeftChar != 'N') {
			for (int pos = Start; pos < End; pos++) {
				if (ExonIslandMask[pos] != X_char) {
					if (CurrentChr[pos] == LeftChar) {
						PD[0].push_back(pos);
					}
					//else PD[1].push_back(pos);
				}
			}
		}
		/*else { //Match2N[(short)'A'] = 'N';
			for (int pos = Start; pos < End; pos++) {
				if (ExonIslandMask[pos] != X_char) {
					if (Match2N[(short)CurrentChr[pos]] == 'N') {
						PD[0].push_back(pos);
					}
				}
				//else Left_PD[1].push_back(pos);
			}
		}*/
		CheckLeft_Far(CurrentChr, CurrentReadSeq, PD, BP_Start, BP_End, FirstBase, UP);
		//Direction = '-';
		for (unsigned LeftUP_index = 0; LeftUP_index < UP.size(); LeftUP_index++) {
			if (CheckMismatches(CurrentChr, Temp_One_Read.UnmatchedSeq, UP[LeftUP_index])) {
				Temp_One_Read.Used = false;
				Temp_One_Read.UP_Far.push_back(UP[LeftUP_index]);
			}
		}
		UP.clear();
	}
	else if (Temp_One_Read.MatchedD == '+') {
		CurrentReadSeq = ReverseComplement(Temp_One_Read.UnmatchedSeq);
		
		Start = Temp_One_Read.UP_Close[Temp_One_Read.UP_Close.size()-1].AbsLoc + mini_intron_size + RangePrevious;
		End = Start  + Range - RangePrevious + Temp_One_Read.ReadLength;	
		RightChar = CurrentReadSeq[CurrentReadSeq.size() - 1];
		if (RightChar != 'N') {
			for (int pos = Start; pos < End; pos++) {
				if (ExonIslandMask[pos] != X_char) {
					if (CurrentChr[pos] == RightChar) {
						PD[0].push_back(pos);
					}
					//else PD[1].push_back(pos);
				}
			}
		}
		/*else { //Match2N[(short)'A'] = 'N';
			for (int pos = Start; pos < End; pos++) {
				if (ExonIslandMask[pos] != X_char) {
					if (Match2N[(short)CurrentChr[pos]] == 'N') {
						PD[0].push_back(pos);
					}
				}
				//else Left_PD[1].push_back(pos);
			}
		}*/
	
		CheckRight_Far(CurrentChr, CurrentReadSeq, PD, BP_Start, BP_End, FirstBase, UP);
		//Direction = '+';
		for (unsigned RightUP_index = 0; RightUP_index < UP.size(); RightUP_index++) {
			if (CheckMismatches(CurrentChr, Temp_One_Read.UnmatchedSeq, UP[RightUP_index])) {
				Temp_One_Read.Used = false;
				Temp_One_Read.UP_Far.push_back(UP[RightUP_index]);
			} 
		}
		UP.clear();
	}		
}

void GetFarEnd_SingleStrand_FirstMismatch(const string & CurrentChr, SPLIT_READ & Temp_One_Read,  const int & RangePrevious, const int & Range, const string & ExonIslandMask) {
	Temp_One_Read.ReadLength = Temp_One_Read.UnmatchedSeq.size();
	Temp_One_Read.ReadLengthMinus = Temp_One_Read.ReadLength - 1;
	char LeftChar, RightChar;
	string CurrentReadSeq;
	vector <unsigned int> PD[TOTAL_SNP_ERROR_CHECKED];
	vector <UniquePoint> UP;
	//char Direction;
	int Start, End;
	short BP_Start;// = MinClose;
	short BP_End;// = ReadLength - MinClose;
	
	for (int i = 0; i < TOTAL_SNP_ERROR_CHECKED; i++) {
		PD[i].clear();
	}
	UP.clear();
	//Temp_One_Read.UP_Close.clear();
	MinClose = short(log((double)(Temp_One_Read.InsertSize * 2))/log(4.0) + 0.8) + 3;
	BP_Start = MinClose;
	BP_End = Temp_One_Read.ReadLength - MinClose;
	//Temp_One_Read.OK = true;
	if (Temp_One_Read.MatchedD == '-') {
		//CurrentReadSeq = ReverseComplement(Temp_One_Read.UnmatchedSeq);
		CurrentReadSeq = Temp_One_Read.UnmatchedSeq;

		End = Temp_One_Read.UP_Close[Temp_One_Read.UP_Close.size()-1].AbsLoc  -  mini_intron_size - RangePrevious + Temp_One_Read.ReadLength;
		Start = End - Range +  RangePrevious ;
		LeftChar = CurrentReadSeq[0];
		if (LeftChar != 'N') {
			for (int pos = Start; pos < End; pos++) {
				if (ExonIslandMask[pos] != X_char) {
					if (CurrentChr[pos] == LeftChar) {
						PD[0].push_back(pos);
					}
					else PD[1].push_back(pos);
				}
			}
		}
		else { //Match2N[(short)'A'] = 'N';
			for (int pos = Start; pos < End; pos++) {
				if (ExonIslandMask[pos] != X_char) {
					if (Match2N[(short)CurrentChr[pos]] == 'N') {
						PD[0].push_back(pos);
					}
				}
				//else Left_PD[1].push_back(pos);
			}
		}
		CheckLeft_Far(CurrentChr, CurrentReadSeq, PD, BP_Start, BP_End, FirstBase, UP);
		//Direction = '-';
		for (unsigned LeftUP_index = 0; LeftUP_index < UP.size(); LeftUP_index++) {
			if (CheckMismatches(CurrentChr, Temp_One_Read.UnmatchedSeq, UP[LeftUP_index])) {
				Temp_One_Read.Used = false;
				Temp_One_Read.UP_Far.push_back(UP[LeftUP_index]);
			}
		}
		UP.clear();
	}
	else if (Temp_One_Read.MatchedD == '+') {
		CurrentReadSeq = ReverseComplement(Temp_One_Read.UnmatchedSeq);
		
		Start = Temp_One_Read.UP_Close[Temp_One_Read.UP_Close.size()-1].AbsLoc + mini_intron_size + RangePrevious;
		End = Start  + Range - RangePrevious + Temp_One_Read.ReadLength;	
		RightChar = CurrentReadSeq[CurrentReadSeq.size() - 1];
		if (RightChar != 'N') {
			for (int pos = Start; pos < End; pos++) {
				if (ExonIslandMask[pos] != X_char) {
					if (CurrentChr[pos] == RightChar) {
						PD[0].push_back(pos);
					}
					else PD[1].push_back(pos);
				}
			}
		}
		else { //Match2N[(short)'A'] = 'N';
			for (int pos = Start; pos < End; pos++) {
				if (ExonIslandMask[pos] != X_char) {
					if (Match2N[(short)CurrentChr[pos]] == 'N') {
						PD[0].push_back(pos);
					}
				}
				//else Left_PD[1].push_back(pos);
			}
		}
	
		CheckRight_Far(CurrentChr, CurrentReadSeq, PD, BP_Start, BP_End, FirstBase, UP);
		//Direction = '+';
		for (unsigned RightUP_index = 0; RightUP_index < UP.size(); RightUP_index++) {
			if (CheckMismatches(CurrentChr, Temp_One_Read.UnmatchedSeq, UP[RightUP_index])) {
				Temp_One_Read.Used = false;
				Temp_One_Read.UP_Far.push_back(UP[RightUP_index]);
			} 
		}
		UP.clear();
	}		
}
void DIGetFarEnd_SingleStrand(const string & CurrentChr, SPLIT_READ & Temp_One_Read,  const int & RangePrevious, const int & Range) {
	Temp_One_Read.ReadLength = Temp_One_Read.UnmatchedSeq.size();
	Temp_One_Read.ReadLengthMinus = Temp_One_Read.ReadLength - 1;
	char LeftChar, RightChar;
	string CurrentReadSeq;
	vector <unsigned int> PD[TOTAL_SNP_ERROR_CHECKED];
	vector <UniquePoint> UP;
	//char Direction;
	int Start, End;
	short BP_Start;// = MinClose;
	short BP_End;// = ReadLength - MinClose;

	for (int i = 0; i < TOTAL_SNP_ERROR_CHECKED; i++) {
		PD[i].clear();
	}
	UP.clear();
	//Temp_One_Read.UP_Close.clear();
	MinClose = short(log((double)(Temp_One_Read.InsertSize * 2))/log(4.0) + 0.8) + 3;
	BP_Start = MinClose;
	BP_End = Temp_One_Read.ReadLength - MinClose;
	//Temp_One_Read.OK = true;
	if (Temp_One_Read.MatchedD == '-') {
		//CurrentReadSeq = ReverseComplement(Temp_One_Read.UnmatchedSeq);
		CurrentReadSeq = Temp_One_Read.UnmatchedSeq;

		End = Temp_One_Read.UP_Close[0].AbsLoc  -  mini_intron_size - RangePrevious;
		Start = End - Range +  RangePrevious - Temp_One_Read.ReadLength;
		
		LeftChar = CurrentReadSeq[0];
		if (LeftChar != 'N') {
			for (int pos = Start; pos < End; pos++) {
				//if (ExonIslandMask[pos] == EI_char) {
					if (CurrentChr[pos] == LeftChar) {
						PD[0].push_back(pos);
					}
					else PD[1].push_back(pos);
				//}
			}
		}
		else { //Match2N[(short)'A'] = 'N';
			for (int pos = Start; pos < End; pos++) {
				//if (ExonIslandMask[pos] == EI_char) {
					if (Match2N[(short)CurrentChr[pos]] == 'N') {
						PD[0].push_back(pos);
					}
				//}
				//else Left_PD[1].push_back(pos);
			}
		}
		CheckLeft_Far(CurrentChr, CurrentReadSeq, PD, BP_Start, BP_End, FirstBase, UP);
		//Direction = '-';
		for (unsigned LeftUP_index = 0; LeftUP_index < UP.size(); LeftUP_index++) {
			if (CheckMismatches(CurrentChr, Temp_One_Read.UnmatchedSeq, UP[LeftUP_index])) {
				Temp_One_Read.Used = false;
				Temp_One_Read.UP_Far.push_back(UP[LeftUP_index]);
			}
		}
		UP.clear();
	}
	else if (Temp_One_Read.MatchedD == '+') {
		CurrentReadSeq = ReverseComplement(Temp_One_Read.UnmatchedSeq);

		Start = Temp_One_Read.UP_Close[0].AbsLoc + mini_intron_size + RangePrevious;
		End = Start  + Range - RangePrevious + Temp_One_Read.ReadLength;
		
		RightChar = CurrentReadSeq[CurrentReadSeq.size() - 1];
		if (RightChar != 'N') {
			for (int pos = Start; pos < End; pos++) {
				//if (ExonIslandMask[pos] == EI_char) {
					if (CurrentChr[pos] == RightChar) {
						PD[0].push_back(pos);
					}
					else PD[1].push_back(pos);
				//}
			}
		}
		else { //Match2N[(short)'A'] = 'N';
			for (int pos = Start; pos < End; pos++) {
				//if (ExonIslandMask[pos] == EI_char) {
					if (Match2N[(short)CurrentChr[pos]] == 'N') {
						PD[0].push_back(pos);
					}
				//}
				//else Left_PD[1].push_back(pos);
			}
		}
		CheckRight_Far(CurrentChr, CurrentReadSeq, PD, BP_Start, BP_End, FirstBase, UP);
		//Direction = '+';
		for (unsigned RightUP_index = 0; RightUP_index < UP.size(); RightUP_index++) {
			if (CheckMismatches(CurrentChr, Temp_One_Read.UnmatchedSeq, UP[RightUP_index])) {
				Temp_One_Read.Used = false;
				Temp_One_Read.UP_Far.push_back(UP[RightUP_index]);
			}
		}
		UP.clear();
	}
}
void GetMiddle_Mask(const string & CurrentChr, SPLIT_READ & Temp_One_Read, const int & RangePrevious, const int & Range, const int & Middle_Length, const int & RangeIndex,const string & ExonIslandMask) {
	Temp_One_Read.ReadLength = Temp_One_Read.UnmatchedSeq.size();
	Temp_One_Read.ReadLengthMinus = Temp_One_Read.ReadLength - 1;
	char LeftChar, RightChar;
	string CurrentReadSeq;
	vector <unsigned int> PD[TOTAL_SNP_ERROR_CHECKED];
	vector <UniquePoint> UP;
	//char Direction;
	int Start, End;
	short BP_Start;// = MinClose;
	short BP_End;// = ReadLength - MinClose;
	
	for (int i = 0; i < TOTAL_SNP_ERROR_CHECKED; i++) {
		PD[i].clear();
	}
	UP.clear();
	
	MinClose = short(log((double)(Temp_One_Read.InsertSize * 2))/log(4.0) + 0.8) + 3;
	BP_Start = MinClose;
	BP_End = Temp_One_Read.ReadLength - MinClose;
	//DI_Length = Temp_One_Read.ReadLength-Temp_One_Read.UP_Close[Temp_One_Read.UP_Close.size()-1].LengthStr-Temp_One_Read.UP_Far_Backup[RangeIndex][Temp_One_Read.UP_Far_Backup[RangeIndex].size()-1].LengthStr;
	//Temp_One_Read.OK = true;
	//cout<<Temp_One_Read.Name<<"*\t"<<Temp_One_Read.UP_Close[Temp_One_Read.UP_Close.size()-1].LengthStr<<"\t"<<Temp_One_Read.UP_Far_Backup[RangeIndex][Temp_One_Read.UP_Far_Backup[RangeIndex].size()-1].LengthStr<<"\t"<<Middle_Length<<endl;
	if (Temp_One_Read.MatchedD == '+') {
		CurrentReadSeq = ReverseComplement(Temp_One_Read.UnmatchedSeq).substr(Temp_One_Read.UP_Close[Temp_One_Read.UP_Close.size()-1].LengthStr,Middle_Length);
		Start = Temp_One_Read.UP_Close[Temp_One_Read.UP_Close.size()-1].AbsLoc + mini_intron_size + RangePrevious;
		End = Start  + Range - RangePrevious + Temp_One_Read.ReadLength;
		LeftChar = CurrentReadSeq[0];
		if (LeftChar != 'N') {
			for (int pos = Start; pos < End; pos++) {
				if (ExonIslandMask[pos] == X_char) {
					if (CurrentChr[pos] == LeftChar) {
						PD[0].push_back(pos);
					}
					//else PD[1].push_back(pos);
				}
			}
		}
		/*else { //Match2N[(short)'A'] = 'N';
			for (int pos = Start; pos < End; pos++) {
				if (ExonIslandMask[pos] == X_char) {
					if (Match2N[(short)CurrentChr[pos]] == 'N') {
						PD[0].push_back(pos);
					}

				}
				//else Left_PD[1].push_back(pos);
			}
		}*/
		CheckLeft_Close(CurrentChr, CurrentReadSeq, PD, BP_Start, BP_End, FirstBase, UP);
		//Direction = '-';
		//cout <<"\n"<<CurrentReadSeq<<"\n"<<Temp_One_Read.UnmatchedSeq<<endl;
		for (unsigned LeftUP_index = 0; LeftUP_index < UP.size(); LeftUP_index++) {
		  
			if ( UP[LeftUP_index].LengthStr== Middle_Length ) {
				//cout<<UP[LeftUP_index].LengthStr<<"\t"<< Middle_Length<<endl;
				Temp_One_Read.Used = false;
				Temp_One_Read.UP_Far=Temp_One_Read.UP_Far_Backup[RangeIndex];
				for (unsigned int i = 0; i < MaxRangeIndex; i++) Temp_One_Read.UP_Far_Backup[i].clear();
				Temp_One_Read.UP_Far_Backup[0].push_back(UP[LeftUP_index]);
				Temp_One_Read.JointFlag =1;
				//cout<<Temp_One_Read.JointFlag <<endl;
			}
		}
		UP.clear();
	}
	else if (Temp_One_Read.MatchedD == '-') {
		CurrentReadSeq = Temp_One_Read.UnmatchedSeq.substr(Temp_One_Read.UP_Far_Backup[RangeIndex][Temp_One_Read.UP_Far_Backup[RangeIndex].size()-1].LengthStr,Middle_Length);
		//End = Temp_One_Read.MatchedRelPos + SpacerBeforeAfter - RangePrevious;
		//Start = End - Range + RangePrevious - Temp_One_Read.ReadLength;
		RightChar = CurrentReadSeq[CurrentReadSeq.size() - 1];
		End = Temp_One_Read.UP_Close[Temp_One_Read.UP_Close.size()-1].AbsLoc  -  mini_intron_size - RangePrevious + Middle_Length;
		Start = End - Range +  RangePrevious;
		if (RightChar != 'N') {
			for (int pos = Start; pos < End; pos++) {
				//if (ExonIslandMask[pos] == EI_char) {
					if (CurrentChr[pos] == RightChar) {
						PD[0].push_back(pos);
						}
					//else PD[1].push_back(pos);
					//}
				}
			}
		/*else { //Match2N[(short)'A'] = 'N';
			for (int pos = Start; pos < End; pos++) {
				//if (ExonIslandMask[pos] == EI_char){
					if (Match2N[(short)CurrentChr[pos]] == 'N') {
						PD[0].push_back(pos);
					}
				//}
				//else Left_PD[1].push_back(pos);
			}
		}*/
		CheckRight_Close(CurrentChr, CurrentReadSeq, PD, BP_Start, BP_End, FirstBase, UP);
		//Direction = '+';
		for (unsigned RightUP_index = 0; RightUP_index < UP.size(); RightUP_index++) {
			//if (CheckMismatches(CurrentChr, Temp_One_Read.UnmatchedSeq, UP[RightUP_index]) && UP[RightUP_index].LengthStr== Middle_Length) {
			if ( UP[RightUP_index].LengthStr== Middle_Length) {
				Temp_One_Read.Used = false;
				Temp_One_Read.UP_Far=Temp_One_Read.UP_Far_Backup[RangeIndex];
				for (unsigned int i = 0; i < MaxRangeIndex; i++) Temp_One_Read.UP_Far_Backup[i].clear(); 
				Temp_One_Read.UP_Far_Backup[0].push_back(UP[RightUP_index]);
				Temp_One_Read.JointFlag =1;
			}
		}
		UP.clear();
	}
}



void GetMiddle(const string & CurrentChr, SPLIT_READ & Temp_One_Read, const int & RangePrevious, const int & Range, const int & Middle_Length, const int & RangeIndex) {
	Temp_One_Read.ReadLength = Temp_One_Read.UnmatchedSeq.size();
	Temp_One_Read.ReadLengthMinus = Temp_One_Read.ReadLength - 1;
	char LeftChar, RightChar;
	string CurrentReadSeq;
	vector <unsigned int> PD[TOTAL_SNP_ERROR_CHECKED];
	vector <UniquePoint> UP;
	//char Direction;
	int Start, End;
	short BP_Start;// = MinClose;
	short BP_End;// = ReadLength - MinClose;
	
	for (int i = 0; i < TOTAL_SNP_ERROR_CHECKED; i++) {
		PD[i].clear();
	}
	UP.clear();
	
	MinClose = short(log((double)(Temp_One_Read.InsertSize * 2))/log(4.0) + 0.8) + 3;
	BP_Start = MinClose;
	BP_End = Temp_One_Read.ReadLength - MinClose;
	//DI_Length = Temp_One_Read.ReadLength-Temp_One_Read.UP_Close[Temp_One_Read.UP_Close.size()-1].LengthStr-Temp_One_Read.UP_Far_Backup[RangeIndex][Temp_One_Read.UP_Far_Backup[RangeIndex].size()-1].LengthStr;
	//Temp_One_Read.OK = true;
	//cout<<Temp_One_Read.Name<<"*\t"<<Temp_One_Read.UP_Close[Temp_One_Read.UP_Close.size()-1].LengthStr<<"\t"<<Temp_One_Read.UP_Far_Backup[RangeIndex][Temp_One_Read.UP_Far_Backup[RangeIndex].size()-1].LengthStr<<"\t"<<Middle_Length<<endl;
	if (Temp_One_Read.MatchedD == '+') {
		CurrentReadSeq = ReverseComplement(Temp_One_Read.UnmatchedSeq).substr(Temp_One_Read.UP_Close[Temp_One_Read.UP_Close.size()-1].LengthStr,Middle_Length);
		Start = Temp_One_Read.UP_Close[Temp_One_Read.UP_Close.size()-1].AbsLoc + mini_intron_size + RangePrevious;
		End = Start  + Range - RangePrevious + Temp_One_Read.ReadLength;
		LeftChar = CurrentReadSeq[0];
		if (LeftChar != 'N') {
			for (int pos = Start; pos < End; pos++) {
				//if (ExonIslandMask[pos] == EI_char) {
					if (CurrentChr[pos] == LeftChar) {
						PD[0].push_back(pos);
					}
					//else PD[1].push_back(pos);
				//}
			}
		}
		/*else { //Match2N[(short)'A'] = 'N';
			for (int pos = Start; pos < End; pos++) {
				//if (ExonIslandMask[pos] == EI_char) {
					if (Match2N[(short)CurrentChr[pos]] == 'N') {
						PD[0].push_back(pos);
					}

				//}
				//else Left_PD[1].push_back(pos);
			}
		}*/
		CheckLeft_Close(CurrentChr, CurrentReadSeq, PD, BP_Start, BP_End, FirstBase, UP);
		//Direction = '-';
		//cout <<"\n"<<CurrentReadSeq<<"\n"<<Temp_One_Read.UnmatchedSeq<<endl;
		for (unsigned LeftUP_index = 0; LeftUP_index < UP.size(); LeftUP_index++) {
		  
			if ( UP[LeftUP_index].LengthStr== Middle_Length ) {
				//cout<<UP[LeftUP_index].LengthStr<<"\t"<< Middle_Length<<endl;
				Temp_One_Read.Used = false;
				Temp_One_Read.UP_Far=Temp_One_Read.UP_Far_Backup[RangeIndex];
				for (unsigned int i = 0; i < MaxRangeIndex; i++) Temp_One_Read.UP_Far_Backup[i].clear();
				Temp_One_Read.UP_Far_Backup[0].push_back(UP[LeftUP_index]);
				Temp_One_Read.JointFlag =1;
				//cout<<Temp_One_Read.JointFlag <<endl;
			}
		}
		UP.clear();
	}
	else if (Temp_One_Read.MatchedD == '-') {
		CurrentReadSeq = Temp_One_Read.UnmatchedSeq.substr(Temp_One_Read.UP_Far_Backup[RangeIndex][Temp_One_Read.UP_Far_Backup[RangeIndex].size()-1].LengthStr,Middle_Length);
		//End = Temp_One_Read.MatchedRelPos + SpacerBeforeAfter - RangePrevious;
		//Start = End - Range + RangePrevious - Temp_One_Read.ReadLength;
		RightChar = CurrentReadSeq[CurrentReadSeq.size() - 1];
		End = Temp_One_Read.UP_Close[Temp_One_Read.UP_Close.size()-1].AbsLoc  -  mini_intron_size - RangePrevious + Middle_Length;
		Start = End - Range +  RangePrevious;
		if (RightChar != 'N') {
			for (int pos = Start; pos < End; pos++) {
				//if (ExonIslandMask[pos] == EI_char) {
					if (CurrentChr[pos] == RightChar) {
						PD[0].push_back(pos);
						}
					//else PD[1].push_back(pos);
					//}
				}
			}
		/*else { //Match2N[(short)'A'] = 'N';
			for (int pos = Start; pos < End; pos++) {
				//if (ExonIslandMask[pos] == EI_char){
					if (Match2N[(short)CurrentChr[pos]] == 'N') {
						PD[0].push_back(pos);
					}
				//}
				//else Left_PD[1].push_back(pos);
			}
		}*/
		CheckRight_Close(CurrentChr, CurrentReadSeq, PD, BP_Start, BP_End, FirstBase, UP);
		//Direction = '+';
		for (unsigned RightUP_index = 0; RightUP_index < UP.size(); RightUP_index++) {
			//if (CheckMismatches(CurrentChr, Temp_One_Read.UnmatchedSeq, UP[RightUP_index]) && UP[RightUP_index].LengthStr== Middle_Length) {
			if ( UP[RightUP_index].LengthStr== Middle_Length) {
				Temp_One_Read.Used = false;
				Temp_One_Read.UP_Far=Temp_One_Read.UP_Far_Backup[RangeIndex];
				for (unsigned int i = 0; i < MaxRangeIndex; i++) Temp_One_Read.UP_Far_Backup[i].clear(); 
				Temp_One_Read.UP_Far_Backup[0].push_back(UP[RightUP_index]);
				Temp_One_Read.JointFlag =1;
			}
		}
		UP.clear();
	}
}


void CheckBoth(const string & TheInput, 
               const string & CurrentReadSeq,
               const vector <unsigned int> PD_Plus[],
					const vector <unsigned int> PD_Minus[],
               const short & BP_Start,
               const short & BP_End,
               const short & CurrentLength,
               vector <UniquePoint> & UP) {
	int Sum;
   if (CurrentLength >= BP_Start && CurrentLength <= BP_End) {
      // put it to LeftUP if unique
		for (short i = 0; i <= MAX_SNP_ERROR; i++) {
			if (PD_Plus[i].size() + PD_Minus[i].size() == 1 && CurrentLength >= BP_Start + i) {
				Sum = 0;
				if (ADDITIONAL_MISMATCH) 
		   		for (short j = 1; j <= ADDITIONAL_MISMATCH; j++) 
			   		Sum += PD_Plus[i + j].size() + PD_Minus[i + j].size();
				
				if (Sum == 0 && i <= (short)(Seq_Error_Rate * CurrentLength + 1)) {
					UniquePoint TempOne;
					TempOne.LengthStr = CurrentLength;
					if (PD_Plus[i].size() == 1) {
						TempOne.Direction = FORWARD;
						TempOne.Strand = SENSE;
						TempOne.AbsLoc = PD_Plus[i][0];
					}
					else if (PD_Minus[i].size() == 1) {
						TempOne.Direction = BACKWARD;
						TempOne.Strand = ANTISENSE;
						TempOne.AbsLoc = PD_Minus[i][0];						
					}
					TempOne.Mismatches = i;
					UP.push_back(TempOne);	
					break;
				}
			}
		}
   }
   if (CurrentLength < BP_End) {
      vector <unsigned int> PD_Plus_Output[TOTAL_SNP_ERROR_CHECKED];
		vector <unsigned int> PD_Minus_Output[TOTAL_SNP_ERROR_CHECKED];
      const char CurrentChar = CurrentReadSeq[CurrentLength];
		const char CurrentCharRC = Convert2RC4N[(short)CurrentChar];
      //const int SizeOfCurrent = Left_PD.size();
      unsigned int pos;
		int SizeOfCurrent;
		for (int i = 0; i < TOTAL_SNP_ERROR_CHECKED_Minus; i++) {
			SizeOfCurrent = PD_Plus[i].size();
			if (CurrentChar == 'N') {
				for (int j = 0; j < SizeOfCurrent; j++) {
					pos =  PD_Plus[i][j] + 1;
					if (Match2N[(short)TheInput[pos]] == 'N')
						PD_Plus_Output[i].push_back(pos);
					else PD_Plus_Output[i + 1].push_back(pos);
				}         
			}
			else {
				for (int j = 0; j < SizeOfCurrent; j++) {
					pos =  PD_Plus[i][j] + 1;
					if (TheInput[pos] == CurrentChar)
						PD_Plus_Output[i].push_back(pos);
					else PD_Plus_Output[i + 1].push_back(pos); 
				}         
			}		
			SizeOfCurrent = PD_Minus[i].size();
			if (CurrentCharRC == 'N') {
				for (int j = 0; j < SizeOfCurrent; j++) {
					pos =  PD_Minus[i][j] - 1;
					if (Match2N[(short)TheInput[pos]] == 'N')
						PD_Minus_Output[i].push_back(pos);
					else PD_Minus_Output[i + 1].push_back(pos);
				}         
			}
			else {
				for (int j = 0; j < SizeOfCurrent; j++) {
					pos =  PD_Minus[i][j] - 1;
					if (TheInput[pos] == CurrentCharRC)
						PD_Minus_Output[i].push_back(pos);
					else PD_Minus_Output[i + 1].push_back(pos); 
				}         
			}
		}
		
		SizeOfCurrent = PD_Plus[TOTAL_SNP_ERROR_CHECKED_Minus].size();
		if (CurrentChar == 'N') {
			for (int j = 0; j < SizeOfCurrent; j++) {
				pos =  PD_Plus[TOTAL_SNP_ERROR_CHECKED_Minus][j] + 1;
				if (Match2N[(short)TheInput[pos]] == 'N')
					PD_Plus_Output[TOTAL_SNP_ERROR_CHECKED_Minus].push_back(pos);
			}         
		}
		else {
			for (int j = 0; j < SizeOfCurrent; j++) {
				pos =  PD_Plus[TOTAL_SNP_ERROR_CHECKED_Minus][j] + 1;
				if (TheInput[pos] == CurrentChar)
					PD_Plus_Output[TOTAL_SNP_ERROR_CHECKED_Minus].push_back(pos);
			}         
		}		
		SizeOfCurrent = PD_Minus[TOTAL_SNP_ERROR_CHECKED_Minus].size();
		if (CurrentCharRC == 'N') {
			for (int j = 0; j < SizeOfCurrent; j++) {
				pos =  PD_Minus[TOTAL_SNP_ERROR_CHECKED_Minus][j] - 1;
				if (Match2N[(short)TheInput[pos]] == 'N')
					PD_Minus_Output[TOTAL_SNP_ERROR_CHECKED_Minus].push_back(pos);
			}         
		}
		else {
			for (int j = 0; j < SizeOfCurrent; j++) {
				pos =  PD_Minus[TOTAL_SNP_ERROR_CHECKED_Minus][j] - 1;
				if (TheInput[pos] == CurrentCharRC)
					PD_Minus_Output[TOTAL_SNP_ERROR_CHECKED_Minus].push_back(pos);
			}         
		}
		

		Sum = 0;
		for (int i = 0; i <= MAX_SNP_ERROR; i++) {
			Sum += PD_Plus_Output[i].size() + PD_Minus_Output[i].size();
		}
      if (Sum) {
         const short CurrentLengthOutput = CurrentLength + 1;
         CheckBoth(TheInput, CurrentReadSeq, PD_Plus_Output, PD_Minus_Output,
                   BP_Start, BP_End,
                   CurrentLengthOutput, UP);         
      }
      else return;
   }   
   else return;
}


void CleanUniquePoints (vector <UniquePoint> & Input_UP) {
	vector <UniquePoint> TempUP; //vector <UniquePoint> UP_Close; UP_Far
	UniquePoint LastUP = Input_UP[Input_UP.size() - 1];
	//TempUP.push_back(LastUP);
	char LastDirection = LastUP.Direction;
	char LastStrand = LastUP.Strand;
	unsigned int Terminal;
	
	if (LastDirection == FORWARD) {
		Terminal = LastUP.AbsLoc - LastUP.LengthStr;
		for (unsigned i = 0; i < Input_UP.size(); i++) {
			if (Input_UP[i].Direction == LastDirection && Input_UP[i].Strand == LastStrand) {
				if (Terminal == Input_UP[i].AbsLoc - Input_UP[i].LengthStr) 
					TempUP.push_back(Input_UP[i]);
			}
		}
	}
	else if (LastDirection == BACKWARD) {
		Terminal = LastUP.AbsLoc + LastUP.LengthStr;
		for (unsigned i = 0; i < Input_UP.size(); i++) {
			if (Input_UP[i].Direction == LastDirection && Input_UP[i].Strand == LastStrand) {
				if (Terminal == Input_UP[i].AbsLoc + Input_UP[i].LengthStr) 
					TempUP.push_back(Input_UP[i]);
			}
		}			
	}
   Input_UP.clear();
	Input_UP = TempUP;
}
