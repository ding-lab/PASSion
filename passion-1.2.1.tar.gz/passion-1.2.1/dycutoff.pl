#!/usr/bin/perl
use strict;

#print "Userage: perl exon_island.pl chr read_len insert_len fold\n";
#print "Userage: perl exon_island.pl 17 50 200 fold\n";


my ($insert_size,$chr,$outputp,$cutoff_ratio,$divide_flag) = @ARGV;
#print "$outputp/exonisland.$chr.out","\n";
my %hash_exon_coverage;
#print "$outputp/exonisland.$chr.out","\n";
open (EXONISLAND, "$outputp/exonisland.$chr.out") or die "Could not open EXONISLAND file!\n";
while (my $line = <EXONISLAND>)
{
	chomp $line;
	my @array = split ("\t", $line);
	for (my $i=$array[1];$i<=$array[2];$i++)
			{
				$hash_exon_coverage{$array[0]}{$i}= $array[3];

			}

}
	




my %hash_junction_start;
my %hash_junction_end;
my %hash_junction;
open (DENFILE, "$outputp/deletions.$chr.denoised.txt") or die "Could not open denoised file $!\n";
open (FINAL,">>$outputp/tmp/deletions.$chr.final")  or die "Could not open final deletion file $!\n";

if  ($divide_flag eq "F")
{ open (ALLBED,">>$outputp/Junctions.bed")  or die "Could not open ALL BED file $!\n";}
else
{
open (GTAG,">>$outputp/Junctions.GTAG.bed")  or die "Could not open GTAG file $!\n";
open (ATAC,">>$outputp/Junctions.ATAC.bed")  or die "Could not open ATAC file $!\n";
open (GCAG,">>$outputp/Junctions.GCAG.bed")  or die "Could not open GCAG file $!\n";
open (OTHER,">>$outputp/Junctions.Other.bed")  or die "Could not open Other file $!\n";
}
my $line_count=0;
my $junction_count=0;
my $min_cov;
my $max_cov;
my $final_coverage;
my $final_cutoff_support;
while (my $line=<DENFILE>)
{
	chomp $line;
	if ($line_count>0)
	{
		my @array=split /\t/, $line;
		my ($start,$end,$len)=($array[14],$array[15],$array[2]);
		$hash_junction_start{$start}++;
		$hash_junction_end{$end}++;
		$hash_junction{$start}{$end}=$line;
	}
	else
	{}
	$line_count++;
}


#print  "track name=junctions description=\"PAS junctions\"\n";

foreach my $key1 (keys (%hash_junction))
{
   foreach my $key2 (keys %{$hash_junction{$key1}})
   {
   	my $junction_flag="F";
	my @array=sort {$a<=>$b} ($hash_exon_coverage{$chr}{$key1}/$hash_junction_start{$key1},$hash_exon_coverage{$chr}{$key2}/$hash_junction_end{$key2});
   	$min_cov=$array[0];
	$max_cov=$array[-1];
   	if (!($max_cov==0 && $min_cov==0))
   	{

	@array=sort {$a<=>$b}(1,$max_cov);
   	$final_coverage=$array[-1];
	$final_cutoff_support= ceiling($final_coverage*$cutoff_ratio);
   	my @array_line=split("\t",$hash_junction{$key1}{$key2});
   	my $split_support=$array_line[8];
   	if ($split_support>=$final_cutoff_support )
   	{
   		$junction_flag="T";
   		print2BED($hash_junction{$key1}{$key2},$junction_count);
   		$junction_count++;
   		#print FINAL $hash_junction{$key1}{$key2},"\t",$min_cov,"?1\t",$max_cov,"?2\t","\n";
   		#print $hash_junction{$key1}{$key2},"\t",$final_coverage,"\t",$hash_exon_coverage{$chr}{$key1},"??\t",$hash_junction_start{$key1},"\t",$hash_exon_coverage{$chr}{$key2},"\t",$hash_junction_end{$key2},"\t$junction_flag","\t",$final_coverage,"\t",ceiling($final_coverage*0.05),"\n";  	
 
   	}
	print FINAL $hash_junction{$key1}{$key2},"\t",$hash_exon_coverage{$chr}{$key1}/$hash_junction_start{$key1},"\t",$hash_exon_coverage{$chr}{$key2}/$hash_junction_end{$key2},"\n";
		
	}  	
   	}
}

sub ceiling {
	(my $x)=@_;
	if (int($x)==$x)
	{return $x;}
	else {return int($x)+1;}
}

sub print2BED{
	my ($record,$i)=@_;
	my @array = split ("\t", $record);
	my $chr=$array[3];
	my $support=$array[8];
	my $thick_start=$array[14];
	my $thick_end=$array[15];
	my $ll=$array[11];
	my $rl=$array[12];
	my $chr_start_range=$array[6];
	my $chr_end_range=$array[7];
	my $chr_start=$thick_start-$ll;
	my $chr_end=$thick_end+$rl-1;
	my $block_start=0;
	my $block_end=$thick_end-$chr_start-1;
	my $direction;
	my $junctionid="JUNC_".$i;
	if ($array[13] =~ /GCAG/ || $array[13] =~ /ATAC/ ||$array[13] =~ /GTAG/)
	{
		$direction="+";
	}
	elsif ($array[13] =~ /CTGC/ ||$array[13] =~/GTAT/||$array[13] =~ /CTAC/)
	{
		$direction="-";
	}
	else {$direction=".";}
	
if  ($divide_flag eq "F")	#print join("\t",$chr,$chr_start,$chr_end,$junctionid,$support,$direction,$thick_start,$thick_end,"255,0,0","2","$ll,$rl","$block_start,$block_end"),"\n";
{print ALLBED join("\t",$chr,$chr_start,$chr_end,$junctionid,$support,$direction,$chr_start_range,$chr_end_range,"255,0,0","2","$ll,$rl","$block_start,$block_end"),"\n";}
else {
	if ($array[13] =~ /GTAG/ || $array[13] =~ /CTAC/ )
	{
	  print GTAG join("\t",$chr,$chr_start,$chr_end,$junctionid,$support,$direction,$chr_start_range,$chr_end_range,"255,0,0","2","$ll,$rl","$block_start,$block_end"),"\n";
	}
	elsif ($array[13] =~ /ATAC/ || $array[13] =~ /GTAT/ )
	{	 
	  print ATAC join("\t",$chr,$chr_start,$chr_end,$junctionid,$support,$direction,$chr_start_range,$chr_end_range,"255,0,0","2","$ll,$rl","$block_start,$block_end"),"\n";
	}
	elsif ($array[13] =~ /GCAG/ || $array[13] =~ /CTGC/ )
	{
	  print GCAG join("\t",$chr,$chr_start,$chr_end,$junctionid,$support,$direction,$chr_start_range,$chr_end_range,"255,0,0","2","$ll,$rl","$block_start,$block_end"),"\n";
	}
	else
	{
	  print OTHER join("\t",$chr,$chr_start,$chr_end,$junctionid,$support,$direction,$chr_start_range,$chr_end_range,"255,0,0","2","$ll,$rl","$block_start,$block_end"),"\n";	
	}

}	
	
}
