#!/usr/bin/perl
use strict;

my ($reffile, $outputp, $support_cutoff,$chr)=@ARGV;
my $ref_name;
my $ref_seq;
my @array_marker=("GCAG","CTGC","ATAC","GTAT","GTAG","CTAC");
#my @array_marker=("GCAG","ATAC","GTAG","CTGC","GTAT","CTAC");
#my @array_marker=("GCAG","GTAG");
my $flag=0;
open (REFFILE, "$reffile") or die "Could not open ref file $!\n";
while (my $line=<REFFILE>)
{
	chomp $line;
	if ($line =~ /^>/)	
	{$flag=0;
	# $ref_seq="";
	}
        if ($flag==1) {$ref_seq=$ref_seq.$line;}
	if ($line eq ">$chr")
	{
		$ref_name=$line;
		$flag=1;
		$ref_seq="";
		#print "ref is $line\n";
	}

}
#print "ref is $ref_name\n";
open (DELFILE, "$outputp/deletions.$chr.txt") or die "Could not open del file $!\n";
my $line_count=0;
my %hash_junction;
while (my $line=<DELFILE>)
{
	if ($line =~ /^#/)
	{
		$line_count=0;
	}
	if ($line_count==1)
	{
		my @array=split /\t/,$line;
		my $id=$array[0];
		
		$array[1]=~ s/D //;
		my $del_length=$array[1];
		
		###min intron size 20
		if ($del_length>=20)
		{
		$array[2]=~ s/ChrID //;
		my $ref_name=$array[2];
		
		$array[3]=~ s/BP //;
		my $bp_start=$array[3];
		my $bp_end	=$array[4];
		
		$array[5]=~ s/BP_range //;
		my $range_start=$array[5];
		my $range_end=$array[6];
		
		$array[7]=~ s/Supports //;
		my $support=$array[7];
		my $support_plus=$array[8];
		   $support_plus=~ s/\s+//;
		my $support_minus=$array[9];
		   $support_minus=~ s/\s+//;
		   
		my $LL=$array[12];
		   $LL=~ s/LL //;
		my $RL=$array[13];
		   $RL=~ s/RL //;
			
		
		#printf "%d\t%d\t%s\t%d\t%d\t%d\t%d\t%d\t%+d\t%+d\n",$id,$del_length,$ref_name,$bp_start,$bp_end,$range_start,$range_end,$support,$support_plus,$support_minus;
		my $record= join ("\t",$id,$del_length,$ref_name,$bp_start,$bp_end,$range_start,$range_end,$support,$support_plus,$support_minus,$LL,$RL);
		if ($support>=$support_cutoff)
		{
		$hash_junction{$del_length}{$ref_name}{$id}=	{start  => $range_start,
                                                 		end  	=> $range_end,
                                                 		bp_start=>$bp_start,
                                                 		bp_end	=>$bp_end,
                                                 		support => $support,
                                                 		dellen  => $del_length,
                                          		 		 record => $record,
                                        				};
		}
		}
	}
	$line_count++;
}

foreach my $key1 (keys %hash_junction)
{
	foreach my $key2 (keys %{$hash_junction{$key1}})
	{
		$hash_junction{$key1}{$key2}=denoise($hash_junction{$key1}{$key2});
		foreach my $key3 (keys %{$hash_junction{$key1}{$key2}})
		{
			$hash_junction{$key1}{$key2}{$key3}=markerdetect($hash_junction{$key1}{$key2}{$key3});
		}
	}
}
#print header
printf "\tID\tLenth\tRef\tBP_S\tBP_E\tRange_S\tRange_E\tSupport\tSup+\tSup-\tLL\tRL\tMarker\tStart\tEnd\n";
my $junction_count=0;
foreach my $key1 (keys %hash_junction)
{
	foreach my $key2 (keys %{$hash_junction{$key1}})
	{
		foreach my $key3 (keys %{$hash_junction{$key1}{$key2}})
		{	print $junction_count,"\t",$hash_junction{$key1}{$key2}{$key3}{"record"},"\n";
			$junction_count++;
		}
	}
}
#bedconvert ()

sub markerdetect{
	my ($hash_ref)=@_;
	my %hash=%$hash_ref;
	my $junction_seq;
	my $len=$hash{"dellen"}-4;
	my $start;
	my $end;
	my $flag="no";
	$junction_seq=substr($ref_seq,$hash{"start"},$hash{"end"}-$hash{"start"}-1);
	
	for (my $m=0;$m<@array_marker;$m++)
	{
		my $marker=$array_marker[$m];	
		my $marker_p1=substr($marker,0,2);
		my $marker_p2=substr($marker,2,2);
		#5oct, for (my $i=0;$i<$hash{"end"}-$hash{"start"}-$hash{"dellen"}+2;$i++)
		for (my $i=0;$i<$hash{"end"}-$hash{"start"}-$hash{"dellen"};$i++)
			{
				if ( (substr($junction_seq,$i,2) eq $marker_p1) && (substr($junction_seq,$i+$hash{"dellen"}-2,2) eq $marker_p2))
					{
						$flag=$marker;
						$start=$hash{"start"}+$i;
						$end=$hash{"start"}+$i+$hash{"dellen"}+1;
					}
			}
	}
	if ($flag eq "no")
	{
		$start=$hash{"bp_start"};
		$end=$hash{"bp_end"};
	}
	#######
	$hash{"record"}=join ("\t",$hash{"record"},$flag,$start,$end);
	return \%hash;
	
}


sub denoise {
	my ($hash_ref)=@_;
	my %hash=%$hash_ref;
	my $box_index=0;
	my $box_in_count=0;
	my $key_count=0;
	my @array;
	my $pre_start;
	my $pre_id;
	my %hash_new;
	foreach my $key (sort {$hash{$a}{"start"} <=> $hash{$b}{"start"}} keys %hash)
	{
		#print $hash{$key}{"start"},"\n";

		if ($key_count==0)
		{	
			$array[$box_index]=$key;
		}	
		if ($key_count>0)
		{
			
			my $distance=$hash{$key}{"start"}-$pre_start;
			if ($distance>10)
			{
				$box_index++;
				$array[$box_index]=$key;
			}
			else
			{
				
				if ($hash{$key}{"support"}>$hash{$array[$box_index]}{"support"} )
				{
					$array[$box_index]=$key;
				}
				elsif ($hash{$key}{"support"} == $hash{$array[$box_index]}{"support"} )
					{
						
						if ($hash{$key}{"start"}<$hash{$array[$box_index]}{"start"})
						{
							$hash{$array[$box_index]}{"start"}=$hash{$key}{"start"}
						}
						if ($hash{$key}{"end"}>$hash{$array[$box_index]}{"end"})
						{
							$hash{$array[$box_index]}{"end"}=$hash{$key}{"end"}
						}
					
					
				}
			}
		}
		$pre_id=$key;
		$pre_start=$hash{$key}{"start"};
		$key_count++;
	}
	
	for (my $i;$i<@array;$i++)
	{
		#print $hash{$array[$i]}{"record"},"\n";
		$hash_new{$array[$i]}=$hash{$array[$i]};
	}
	return \%hash_new;
}

