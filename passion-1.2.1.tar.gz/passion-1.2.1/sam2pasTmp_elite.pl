#!/usr/bin/perl -w


use strict;
use warnings;
use Getopt::Long;
use IO::File;

my $distance_cutoff=5;
#Set usage message
my $usage="Usage: perl sam2pas.pl -input_sam sam_file -output output_path -insertsize 200 -windowsize 5000000\nPlease try again.\n\n\n";

#Declare all variables needed by GetOpt
my ($inputs, $outputp,$insertsize,$windowsize);

#Get command-line parameters with GetOptions, and check that all needed are there, otherwise 
#die with usage message
die $usage unless 
	&GetOptions(	'input_sam:s' => \$inputs,
					'outputp:s' => \$outputp,
					'insertsize:s' => \$insertsize,
					'windowsize:s' => \$windowsize,
				)
	&& $inputs && $outputp && $insertsize && $windowsize;
	
	print "input sam:",$inputs,"\n";
		
	print "output path:",$outputp,"\n";
		
	print "insert size:",$insertsize,"\n";

	print "window size:",$windowsize,"\n";
	
	
open (SAMFILE, "$inputs") or die "Could not open input SAM file!\n";


my $both_mapped_2_same_strand=0;
my $both_full_mapped=0;
my $one_M_mapped_count=0;
my $oneend_mapped_count=0;
my $none_mapped_count=0;
my $not_paired_count=0;
my $not_valid_count=0;
my $line_count=0;
my %as_fh;
my %as_fh_tmp;
#my $windowsize=5000000;


while (my $line = <SAMFILE>) {

	if ($line=~/^@/)
	{
		#print $line;
	}
	else
	{
		my $line_mate = <SAMFILE>;
		my @array = split ("\t", $line);
		my @array_mate= split ("\t",$line_mate);
		if($array[0] ne $array_mate[0])
		{
			die "Sort sam file by name first\n";
		}
		
		my $flag = $array[1];
		my $cigar = $array[5];	
		if (!toomuchN($array[9]) && !toomuchN($array_mate[9])) ###if one read in a pair has more than 50% N, dont use this pair
		{

		if (($array[2] eq  $array_mate[2] && $array[2] ne "*") || (($array[2] eq  "*" || $array_mate[2] eq  "*") && ($array[2] ne $array_mate[2] )))
		{
			if ($array[2] ne "*")
			{
				######open file if not exist########
				if (! -e "$outputp/aln.$array[2].asinput")
				{open ($as_fh{$array[2]}, ">$outputp/aln.$array[2].asinput") or die "Could not open output path!\n";}
				####################################
			}
			else
			{
				######open file if not exist########
				if (! -e "$outputp/aln.$array_mate[2].asinput")
				{open ($as_fh{$array_mate[2]}, ">$outputp/aln.$array_mate[2].asinput") or die "Could not open output path!\n";}
				####################################
					
			}

			$line_count +=2;
		if (!($flag & 0x0100) && !($flag & 0x0200) && !($flag & 0x0400)) #### reads are primary & quality checks passed & not duplicate
		{
			if   ($flag & 0x0001) #### paired end reads
			{
				if ( !($flag & 0x0004) && !($flag & 0x0008) ) #### self mapped and mate mapped
				{
					if (!($flag & 0x0010) && !($flag & 0x0020) || ($flag & 0x0010) && ($flag & 0x0020) ) ####remove both mapped to forward or both mapped to reversed strand
					{ $both_mapped_2_same_strand += 2;}
					else
					{
						if (!EditDistanceLarge($array[5]) && !EditDistanceLarge($array_mate[5]) )
						{ $both_full_mapped += 2;}
						else{
							if ($flag & 0x0040) ## first reads
							{
								#$hash_both{$array[0]}{1} = $line;
								#$hash_both{$array[0]}{2} = $line_mate;
								both_mapped2pas($line,$line_mate,$as_fh{$array[2]});
								$one_M_mapped_count += 2;
								#print $line;
							}
							elsif ($flag & 0x0080)## second reads
							{
								#$hash_both{$array[0]}{2} = $line;
								#$hash_both{$array[0]}{1} = $line_mate;
								both_mapped2pas($line_mate,$line,$as_fh{$array[2]});
								$one_M_mapped_count += 2;
							}
							}
					}
				}
				elsif (!($flag & 0x0004) || !($flag & 0x0008)) #### one mapped
				{
					if ($flag & 0x0040) ## first reads
					{
						#$hash_one{$array[0]}{1} = $line;
						#$hash_one{$array[0]}{2} = $line_mate;
						if($array[2] ne "*")
						{one_mapped2pas($line,$line_mate,$as_fh{$array[2]});}
						else
						{one_mapped2pas($line,$line_mate,$as_fh{$array_mate[2]});}
						$oneend_mapped_count += 2;
					}
					elsif ($flag & 0x0080)## second reads
					{
						#$hash_one{$array[0]}{2} = $line;
						#$hash_one{$array[0]}{1} = $line_mate;
						if($array[2] ne "*")
						{one_mapped2pas($line_mate,$line,$as_fh{$array[2]});}
						else
						{one_mapped2pas($line_mate,$line,$as_fh{$array_mate[2]});}
						$oneend_mapped_count += 2;
					}
					
				}
				else 
				{
					#if ($flag & 0x0040) ## first reads
					#{
					#	$hash_none{$array[0]}{1} = $line;
					#}
					#elsif ($flag & 0x0080)## second reads
					#{
					#	$hash_none{$array[0]}{2} = $line;
					#}
					$none_mapped_count+=2;
				}
				
			}
			else ####not paired reads
			{
				$not_paired_count+=2;
			}
			
		}
		else ####not valid  reads
		{
				$not_valid_count+=2;
		}
		}
		}
	}
}

print "both_mapped_2_same_strand:\t",$both_mapped_2_same_strand,"\n";
print "both_full_mapped or both mapped with Editdistance< ",$distance_cutoff,":\t",$both_full_mapped,"\n";
print "one_M_mapped_count:\t",$one_M_mapped_count,"\n";
print "oneend_mapped_count:\t",$oneend_mapped_count,"\n";
#print "none_mapped_count:\t",$none_mapped_count,"\n";
print "not_paired_count:\t",$not_paired_count,"\n";
print "not_valid_count:\t",$not_valid_count,"\n";
#print "totol in reference $ref:\t",$line_count,"\n";
###############################sub both_mapped2pas#################
sub both_mapped2pas
{
	my ($read1,$read2,$AS_INPUTFILE)=@_;
	my @array_read1 = split ("\t",$read1);
	my @array_read2 = split ("\t",$read2);

	if (!EditDistanceLarge($array_read1[5]) || !EditDistanceLarge($array_read2[5]) )
		{
			if ( !EditDistanceLarge($array_read1[5]) ) ##read1 all_M mapped--anchor
			{
				if (!($array_read1[1] & 0x0010)) ##read1 is in a forward strand
				{print  $AS_INPUTFILE pas_format(\@array_read1,\@array_read2,1,"+","+");}
				else {print  $AS_INPUTFILE pas_format(\@array_read1,\@array_read2,1,"-","-"); }
			}
			else ##read2 all_M mapped--anchor
			{
				if (!($array_read2[1] & 0x0010)) #read2 is in a forward strand
				{print  $AS_INPUTFILE pas_format(\@array_read2,\@array_read1,2,"+","-");}
				else {print  $AS_INPUTFILE pas_format(\@array_read2,\@array_read1,2,"-","+");}

			}
		}
	else
		{
			#anchor is read1
			if (!($array_read1[1] & 0x0010)) ##read1 is in a forward strand
			{print  $AS_INPUTFILE pas_format(\@array_read1,\@array_read2,1,"+","+");}
			else {print  $AS_INPUTFILE pas_format(\@array_read1,\@array_read2,1,"-","-"); }
			
			#anchor is read2	
			if (!($array_read2[1] & 0x0010)) #read2 is in a forward strand
			{print  $AS_INPUTFILE pas_format(\@array_read2,\@array_read1,2,"+","-");}
			else {print  $AS_INPUTFILE pas_format(\@array_read2,\@array_read1,2,"-","+");}
			
		}

}
###############################EditDistanceLarge########################
sub EditDistanceLarge {
my ($flag)=@_;
my $distance=0;

if ($flag !~ /[IDNSHP]/)
  { return 0;}
else{
  if (my @array=($flag=~/([0-9]+)S/g))
    {
      for (my $i=0;$i<@array;$i++)
      {
	    $distance=$distance+$array[$i];
      }
    }
  if (my @array=($flag=~/([0-9]+)I/g))
    {
      for (my $i=0;$i<@array;$i++)
      {
	    $distance=$distance+$array[$i];
      }
    }
  if (my @array=($flag=~/([0-9]+)D/g))
    {
      for (my $i=0;$i<@array;$i++)
      {
	    $distance=$distance+$array[$i];
      }
    }
  if (my @array=($flag=~/([0-9]+)N/g))
    {
      for (my $i=0;$i<@array;$i++)
      {
	    $distance=$distance+$array[$i];
      }
    }
  if (my @array=($flag=~/([0-9]+)H/g))
    {
      for (my $i=0;$i<@array;$i++)
      {
	    $distance=$distance+$array[$i];
      }
    }
  if (my @array=($flag=~/([0-9]+)P/g))
    {
      for (my $i=0;$i<@array;$i++)
      {
	    $distance=$distance+$array[$i];
      }
    }



  #print $distance,"??\n";
}
if ($distance>=$distance_cutoff)
{
  return 1;
}
else { return 0;}
}
################################sub one mapped2pas################
sub one_mapped2pas
{
	my ($read1,$read2,$AS_INPUTFILE)=@_;
	my @array_read1 = split ("\t",$read1);
	my @array_read2 = split ("\t",$read2);
	if (!($array_read1[1] & 0x0004)) ##read1 is mapped, read1--anchor
	{
		if (!($array_read1[1] & 0x0010)) ##read1 is in a forward strand
		{print  $AS_INPUTFILE pas_format(\@array_read1,\@array_read2,1,"+","+");}
		else {print  $AS_INPUTFILE pas_format(\@array_read1,\@array_read2,1,"-","-"); }
	}
	else ##read2 is mapped, read2--anchor
	{
		if (!($array_read2[1] & 0x0010)) #read2 is in a forward strand
		{print  $AS_INPUTFILE pas_format(\@array_read2,\@array_read1,2,"+","-");}
		else {print  $AS_INPUTFILE pas_format(\@array_read2,\@array_read1,2,"-","+");}	
	}
}

sub pas_format{
	my ($anchor_read_ref,$float_read_ref,$anchor_index,$direction,$junction_strand)=@_;
	my @anchor_read=@$anchor_read_ref;
	my @float_read=@$float_read_ref;
	my $seq;
	if ($float_read[1] & 0x0010) ##float read is reversed
	{
		$seq = revcomp($float_read[9]);
	}
	else
	{
		$seq = $float_read[9];		
	}
	my $pindel_record = "@".$anchor_read[0]."_".$anchor_index."\n".$seq."\n".$direction."\t".$anchor_read[2]."\t".$anchor_read[3]."\t".$anchor_read[4]."\t".$insertsize."\t".$junction_strand."\n";
	my $binindex= int($anchor_read[3]/$windowsize);
	my $tempfilename= "$outputp/aln.".$anchor_read[2].".asinput.bin".$binindex.".tmp";
	if (! -e $tempfilename)
	{open ($as_fh_tmp{$anchor_read[2]}{$binindex}, ">$tempfilename" ) or die "Could not open output path!\n";}

	print2temp($as_fh_tmp{$anchor_read[2]}{$binindex},$pindel_record);
	 	
return $pindel_record;
}

sub print2temp {
my ($ASTMP_INPUTFILE,$record)=@_;
print $ASTMP_INPUTFILE $record;


}
sub revcomp {
	my ($seq) = @_;
	my $revcom=reverse($seq);
	   $revcom =~ tr /ACGTacgt/TGCAtgca/;
	return $revcom;
}
sub toomuchN{
my ($seq)=@_;
my @match = $seq =~ /N/g;
#print "###\n",@match/length($seq),"####\n";
if (@match/length($seq)>=0.5)
{
  return 1;
}
else {return 0;}

}

