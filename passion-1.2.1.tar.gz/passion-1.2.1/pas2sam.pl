#!/usr/bin/perl -w

=head1 NAME

pas2sam.pl

=head1 DESCRIPTION


=head1 SYNOPSIS

Usage: 	pas2sam.pl   -outputp output_path -ref chr17


Args:			-outputp	output path
				-ref 		reference
		
=cut
use strict;
use warnings;
use Getopt::Long;
use IO::File;


#Set usage message
my $usage="Usage: perl pas2sam.pl  -outputp output_path -ref chr17\nPlease try again.\n\n\n";

#Declare all variables needed by GetOpt
my ($outputp,$ref);

#Get command-line parameters with GetOptions, and check that all needed are there, otherwise 
#die with usage message
die $usage unless 
	&GetOptions(
					'outputp:s' => \$outputp,
					'ref:s'     => \$ref,
				)
	&& $outputp && $ref;
	
			
	#print "output path:",$outputp,"\n";	
	#print "referece:",$ref,"\n";	

	
open (SAMFILE, "$outputp/final.sam") or die "Could not open input SAM file!\n";
open (PAS_SAM_FILE, ">$outputp/pas.aln.sam") or die "Could not open output path!\n";




my $hash_junction_ref		= 	Junction2hash("$outputp/tmp/deletions.$ref.final");
my $hash_junction_read_ref	= 	JunctionRead2hash("$outputp/deletions.$ref.txt",$hash_junction_ref);
my %hash_junction_read		=	%$hash_junction_read_ref;
#foreach my $key1 ( keys %hash_junction_read)
#{
#		print $key1,"\t",$hash_junction_read{$key1}{"left_pos"},"\t",$hash_junction_read{$key1}{"right_pos"},"\n";
#}

while (my $line = <SAMFILE>) {

	if ($line=~/^@/)
	{
		#print $line;
	}
	else
	{
		chomp $line;
		my @array = split ("\t", $line);
		my $read_ID=$array[0];
		if (($array[1] & 0x0040) && !($array[1] & 0x0008)) ##read1 is  first and mate mapped
		{$read_ID=$array[0]."_2";} #therefore read2 is the unmmaped
		if (($array[1] & 0x0080) && !($array[1] & 0x0008))#second and mate mapped
		{$read_ID=$array[0]."_1";}
		
		if ($hash_junction_read{$read_ID}) 
		{
			update_sam($line,$hash_junction_read{$read_ID});		
		}
		elsif ($hash_junction_read{$read_ID."_Close"} || $hash_junction_read{$read_ID."_Far"}) #DI
		{

				if ($hash_junction_read{$read_ID."_Close"} && $hash_junction_read{$read_ID."_Far"} )
				{
					#print $line,"\tin\n";
					update_sam_DI($line,$hash_junction_read{$read_ID."_Close"},$hash_junction_read{$read_ID."_Far"});
				}
				elsif ($hash_junction_read{$read_ID."_Close"} )
				{

					update_sam($line,$hash_junction_read{$read_ID."_Close"});
				}

				#update line DI Far
				elsif ($hash_junction_read{$read_ID."_Far"})
				{
					update_sam($line, $hash_junction_read{$read_ID."_Far"});
				}
				
				
		}
			else {
				print  PAS_SAM_FILE $line,"\n";
				}
	}
	
}
sub update_sam{
				#$array[1] #flag
				#$array[3] #pos
				#$array[4] #mapq
				#$array[5] #cigar
				#$array[8] #distance
	my ($sam_record,$hash_ref)=@_;
	my %hash= %$hash_ref;
	my @array = split("\t",$sam_record);
	my $seq=$array[9];
	my $quality = $array[10];
	my $name=$array[0];
	$array[4]=50;
	if ($array[1] & 0x0004) #read unmapped
	{
		$array[1] += 0x0004;
	}

		#######first#######
		$array[0]=$name.".1";
		$array[3]=$hash{"left_pos"};
		$array[5]=$hash{"left_len"}."M";
		$array[9]=substr($seq,0,$hash{"left_len"});
		$array[10]=substr($quality,0,$hash{"left_len"});
		print PAS_SAM_FILE join("\t",@array)."\n";		
		#######second######
		$array[0]=$name.".2";
		$array[3]=$hash{"bp_end"};
		$array[5]=$hash{"right_len"}."M";
		$array[9]=substr($seq,$hash{"left_len"},$hash{"right_len"});
		$array[10]=substr($quality,$hash{"left_len"},$hash{"right_len"});
		print PAS_SAM_FILE join("\t",@array)."\n";	

}

sub update_sam_DI{
				#$array[1] #flag
				#$array[3] #pos
				#$array[4] #mapq
				#$array[5] #cigar
				#$array[8] #distance
	my ($sam_record,$hash_close_ref,$hash_far_ref)=@_;
	my %hash_close= %$hash_close_ref;
	my %hash_far= %$hash_far_ref;
	my @array = split("\t",$sam_record);
	my $seq=$array[9];
	my $quality = $array[10];
	my $name=$array[0];
	if ($array[1] & 0x0004) #read unmapped
	{
		$array[1] += 0x0004;
	}
	$array[4]=50;
	if ($hash_close{"pas_direction"} eq "+")
	{
		###first###close
		$array[0]=$name.".1";
		$array[3]=$hash_close{"left_pos"};
		$array[5]=$hash_close{"left_len"}."M";
		$array[9]=substr($seq,0,$hash_close{"left_len"});
		$array[10]=substr($quality,0,$hash_close{"left_len"});
		print PAS_SAM_FILE join("\t",@array)."\n";
		
		###second###middle
		$array[0]=$name.".2";
		$array[3]=$hash_close{"bp_end"};
		my $middle =$hash_far{"bp_start"}-$hash_close{"bp_end"} +1;
		$array[5]=$middle."M";
		$array[9]=substr($seq,$hash_close{"left_len"},$middle);
		$array[10]=substr($quality,$hash_close{"left_len"},$middle);
		print PAS_SAM_FILE join("\t",@array)."\n";
		
		###third###far
		$array[0]=$name.".3";
		$array[3]=$hash_far{"bp_end"};
		$array[5]=$hash_far{"right_len"}."M";
		$array[9]=substr($seq,$hash_close{"left_len"}+$middle,$hash_far{"right_len"});
		$array[10]=substr($quality,$hash_close{"left_len"}+$middle,$hash_far{"right_len"});
		print PAS_SAM_FILE join("\t",@array)."\n";
	}
	else
	{
		###first###far
		$array[0]=$name.".1";
		$array[3]=$hash_far{"left_pos"};
		$array[5]=$hash_far{"left_len"}."M";
		$array[9]=substr($seq,0,$hash_far{"left_len"});
		$array[10]=substr($quality,0,$hash_far{"left_len"});
		print PAS_SAM_FILE join("\t",@array)."\n";
		
		###second###middle
		$array[0]=$name.".2";
		$array[3]=$hash_far{"bp_end"};
		my $middle = $hash_close{"bp_start"}-$hash_far{"bp_end"}+1;
		$array[5]=$middle."M";
		$array[9]=substr($seq,$hash_far{"left_len"},$middle);
		$array[10]=substr($quality,$hash_far{"left_len"},$middle);
		print PAS_SAM_FILE join("\t",@array)."\n";
		
		###third###far
		$array[0]=$name.".3";
		$array[3]=$hash_close{"bp_end"};
		$array[5]=$hash_close{"right_len"}."M";
		$array[9]=substr($seq,$hash_far{"left_len"}+$middle,$hash_close{"right_len"});
		$array[10]=substr($quality,$hash_far{"left_len"}+$middle,$hash_close{"right_len"});
		print PAS_SAM_FILE join("\t",@array)."\n";
		

	}

}




sub Junction2hash {
	my ($j_final)=@_;
	my %hash;
	my $junction_count=0;
	open (FINALFILE, "$j_final") or die "Could not open input final JUNCTION file!\n";
	while (my $line = <FINALFILE>) {
		chomp $line;
		if ($line !~ /Start/)
		{
			my @array = split ("\t", $line);
			if ($array[15]-$array[14]-1== $array[2])
			{
				my $offset = $array[14]-$array[4];
				$hash{$array[1]} = {len  	=> $array[2],
                           			start 	=> $array[14],
                           			end 	=> $array[15],
                           			offset	=> $offset,
									};	
			}
			else
			{
				$hash{$array[1]} = {len  	=> $array[2],
                           			start 	=> $array[4],
                           			end 	=> $array[5],
                           			offset 	=> 0,
									};
			}
		$junction_count++;
		}
	}
	#print "Junction:\t",$junction_count,"\n";
	return \%hash;
}


sub JunctionRead2hash {
	my ($j_original,$hash_junction_ref)=@_;
	my %hash=%$hash_junction_ref;
	my %hash_read;
	my $junction_ID;
	my $true_junction_flag;
	open (ORIGINALFILE, "$j_original") or die "Could not open input Original JUNCTION file!\n";
	while (my $line = <ORIGINALFILE>) {
		chomp $line;
		if ($line =~ /#####/)
		{
			#initialization
			$junction_ID="";
			$true_junction_flag=0;
		}
		elsif ($line =~ /BP/)
		{
			#get junction information
			my @array = split ("\t", $line);
			$junction_ID=$array[0];
			if ($hash{$junction_ID})
			{
				$true_junction_flag =1;
			}
			else
			{
				$true_junction_flag =0;
			}
			
		}
		elsif ($line =~ /@/ && $true_junction_flag ==1)
		{
			#get reads in hash
			my @array = split (/\s+/, $line);
			my $left_len = length($array[1])+$hash{$junction_ID}{"offset"};
			my $right_len = length($array[2])-$hash{$junction_ID}{"offset"};
			my $leftmost_pos = $hash{$junction_ID}{"start"}-$left_len+1;
			my $rightmost_pos = $hash{$junction_ID}{"end"}+$right_len-1;
			my $read_name = $array[7];
			$read_name =~ s/@//;
			$hash_read{$read_name} = { 				deletion	=>  $hash{$junction_ID}{"len"},
													left_pos 	=>	$leftmost_pos,
													right_pos	=>	$rightmost_pos,
													left_len	=>	$left_len,
													right_len	=>	$right_len,
													bp_start 	=>	$hash{$junction_ID}{"start"},
													bp_end 		=>	$hash{$junction_ID}{"end"},
													pas_direction=>	$array[3],
												}							
			}
		}
		return \%hash_read;
}
