#!/usr/bin/perl
use strict;

#print "Userage: perl exon_island.pl read_len insert_len fold\n";
#print "Userage: perl exon_island.pl 50 200 fold\n";


my ($insert_len,$outputp) = @ARGV;
my $start_chr;
my $start_pos;
my $end_chr;
my $end_pos;
my $exon_start;
my $exon_end;
my $exon_coverage;
my $exon_nucleotide;
my $line_count = 1;
my $exon_island_count = 0;
my $exon_island_len = 0;
my %ei_fh;
my $filename;
#my $distance_cutoff = 4*$read_len;
my $distance_cutoff = 2*$insert_len;
#print "data_more/$read_len.$insert_len.chr$chr.trans.fa.result.as/exonisland2.read1.$fold.fq.read2.$fold.fq.out";
open (PILEUPFILE, "$outputp/pileup.orignal") or die "Could not open PILEUP file!\n";
while (my $line = <PILEUPFILE>)
{
	chmod $line;
	my @array = split ("\t", $line);
	my $current_chr = $array[0];
	my $current_pos = $array[1];
	my $current_cov = $array[3]; 
	
	if ($line_count == 1) ####first line; then initiation
	{
		$start_chr = $current_chr;
		$start_pos = $current_pos;
		$end_chr   = $current_chr;
		$end_pos   = $current_pos;
		$exon_coverage =$current_cov;
		$exon_nucleotide = 1;
	}
	else
	{
		if (($end_chr eq $current_chr) &&  ($current_pos-$end_pos <= $distance_cutoff))
		{
			$end_chr   = $current_chr;
			$end_pos   = $current_pos;
			$exon_coverage = $exon_coverage+$current_cov;
			$exon_nucleotide=$exon_nucleotide+1;
			
		}
		else #discontinous, print current exon island and initiation
		{
			$exon_start= $start_pos-$insert_len;
			$exon_end  = $end_pos+$insert_len;
			if ($exon_start<=0)
			{
				$exon_start=1;
			}
			# if exon_end > chr length, it is not matter
			######open file if not exist########
			$filename="$outputp/exonisland.".$start_chr.".out";
			if (! -e "$filename")
			{open ($ei_fh{$end_chr}, ">$filename") or die "Could not open output path!\n";}
			####################################
			printfh ($ei_fh{$end_chr},$end_chr."\t".$exon_start."\t".$exon_end."\t".$exon_coverage/$exon_nucleotide."\n"); #print the last exon.
	
			$exon_island_len += $end_pos-$start_pos+1 + 2*$insert_len;
			$exon_island_count ++;
			$start_chr = $current_chr;
			$start_pos = $current_pos;
			$end_chr   = $current_chr;
			$end_pos   = $current_pos;
			$exon_coverage =$current_cov;
			$exon_nucleotide = 1;
		}
	}
	$line_count++;
}

$exon_start= $start_pos-$insert_len;
$exon_end  = $end_pos+$insert_len;
if ($exon_start<0)
	{
		$exon_start=1;
	}
	
# if exon_end > chr length, it is not matter
######open file if not exist########
$filename="$outputp/exonisland.".$start_chr.".out";
if (! -e "$filename")
{open ($ei_fh{$end_chr}, ">$filename") or die "Could not open output path!\n";}
####################################
printfh ($ei_fh{$end_chr},$end_chr."\t".$exon_start."\t".$exon_end."\t".$exon_coverage/$exon_nucleotide."\n"); #print the last exon.
		
$exon_island_len += $end_pos-$start_pos+1 + 2*$insert_len;
$exon_island_count++;
print "Total number of exon islands: $exon_island_count\nTotal length of exon islands: $exon_island_len\n";

sub printfh {
	my ($filehandle,$context)=@_;
	print $filehandle $context;
}