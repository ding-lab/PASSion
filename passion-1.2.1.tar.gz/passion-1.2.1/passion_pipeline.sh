#############input###############
#1:ref
#2:refindex
#3:read1
#4:read2
#5:insertsize
#6:threads
#7:outputfolder

#8:minintron
#9:maxintronindex
#10:windowsize
#11:cutoff
#12:sequence_error_rate
#13:max_SNP

#14:exonisland_file
#15:divide_bed

ref=$1
refindex=$2
read1=$3
read2=$4
insertsize=$5
threads=$6
outputfolder=$7

minintron=$8
maxintronindex=${9}
windowsize=${10}
cutoff=${11}
sequence_error_rate=${12}
max_SNP=${13}

exonisland_file=${14}
divide_bed=${15}
alignment_file=${16}
#################################

if [ -d $outputfolder ];
then rm -r $outputfolder
fi
mkdir  $outputfolder
mkdir $outputfolder/tmp

#################################
#-----------1.SMALT-------------#
#################################
#download: http://www.sanger.ac.uk/resources/software/smalt/
#reference needs to be indexed: smalt_x86_64 index -k 13 -s 6 refindex NCBI37.fasta
if [ -f $alignment_file ]
then cp $alignment_file $outputfolder/orignal.sam
else 
echo "smalt map -i 500000 -f samsoft -n $threads -o $outputfolder/orignal.sam $refindex $read1 $read2"
smalt map -i 500000 -f samsoft -n $threads  -o $outputfolder/orignal.sam $refindex $read1 $read2
fi
#samtools faidx $ref
samtools view -bt $ref.fai $outputfolder/orignal.sam  >$outputfolder/orignal.bam 
samtools sort $outputfolder/orignal.bam  $outputfolder/orignal.sorted
samtools index  $outputfolder/orignal.sorted.bam 
samtools mpileup -f $ref $outputfolder/orignal.sorted.bam >$outputfolder/pileup.orignal

cp $outputfolder/orignal.sam $outputfolder/final.sam 

#################################
#------------2.SAM2PAS----------#
#################################
#output file $outputp/aln.$ref.asinput
sam2pasTmp_elite.pl -input_sam $outputfolder/orignal.sam -outputp $outputfolder -insertsize $insertsize  -windowsize $windowsize



#################################
#---------3.ExonIslands---------#
#################################q
if [ -f $exonisland_file ]
then userdefined_exonisland_GFF.pl  $insertsize $outputfolder  $exonisland_file
else exonisland.pl $insertsize $outputfolder
fi

#####################LOOP###########################################LOOP######################
if [ "$divide_bed" != "F" ]
then 
echo ""track name=junctions description= \"PASSion junctions\" "" >$outputfolder/Junctions.GTAG.bed
echo ""track name=junctions description= \"PASSion junctions\" "" >$outputfolder/Junctions.ATAC.bed
echo ""track name=junctions description= \"PASSion junctions\" "" >$outputfolder/Junctions.GCAG.bed
echo ""track name=junctions description= \"PASSion junctions\" "" >$outputfolder/Junctions.Other.bed
else echo ""track name=junctions description= \"PASSion junctions\" "" >$outputfolder/Junctions.bed
fi
#####################LOOP###########################################LOOP######################
detailname=""
for refname in `grep ">" $ref| sed "s/>//" | sed -e :a -e '$!N;s/\n/\t/;ta' ` ; 
do  echo "$outputfolder/aln.$refname.asinput"

#################################
#-------------4.PAS-------------#
#################################

if [ -f  $outputfolder/aln.$refname.asinput ] && [ -f  $outputfolder/exonisland.$refname.out ] ;
then PASSION $ref aln.$refname.asinput $outputfolder/exonisland.$refname.out $outputfolder  $refname $threads $max_SNP $sequence_error_rate  $maxintronindex $minintron  $windowsize


 
#################################
#-----------5.Denoise-----------#
#################################
denoise.pl $ref $outputfolder 1  $refname >$outputfolder/deletions.$refname.denoised.txt



#################################
#-------6.Dynamic Cutoff--------#
#################################
dycutoff.pl $insertsize $refname $outputfolder $cutoff $divide_bed


#################################
#----------7.PAS2SAM--------#
#################################
pas2sam.pl  -output $outputfolder -ref $refname 
cp $outputfolder/pas.aln.sam $outputfolder/final.sam
delname=$outputfolder/deletions.$refname.txt

detailname=$detailname" "$delname;

else echo "Alternative splicing at $refname does not exists"



fi
done
#####################LOOP###########################################LOOP######################
#####################LOOP###########################################LOOP######################
#echo $detailname
if [  "$detailname" != "" ];
then cat $detailname >$outputfolder/Junctions.detail
fi
for i in $outputfolder/tmp/*
do
cat $i >> $outputfolder/tmp/Junctions.final
done

rm $outputfolder/tmp/deletions.*

rm $outputfolder/aln*asinput
rm $outputfolder/deletions.*
rm $outputfolder/exonisland.*.out
rm $outputfolder/*.sorted.*
rm $outputfolder/pileup.*
rm $outputfolder/*.bam
rm $outputfolder/pas.aln.sam
#samtools view -bt $ref.fai $outputfolder/pas.aln.sam  >$outputfolder/final.bam 
#samtools sort $outputfolder/final.bam  $outputfolder/final.sorted
#samtools index  $outputfolder/final.sorted.bam 
#samtools pileup -f $ref $outputfolder/final.sorted.bam >$outputfolder/pileup.final


#################################
#----------8.SNP Calling--------#
#################################
#samtools pileup -vcf $ref $outputfolder/final.sorted.bam  | tee $outputfolder/SNP.raw | samtools.pl varFilter > $outputfolder/SNP.final 

