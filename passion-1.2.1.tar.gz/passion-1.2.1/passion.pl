#!/usr/bin/perl -w

#ref, -R
#refindex, -I
#read1, -r
#read2, -f
#insertsize, -s


#thread, -T=1
#outputfolder, -o=PASSion_Output
#minintron, -m=20
#maxintronindex, -M=8, size=4096000
#windowsize, -W=5000000
#cutoff, c=0.1
#sequence error rate, -e=0.05
#max_SNP, -S=2

#help -h
#version -v=1.0



use strict;
use warnings;
no warnings 'printf'; 
use Getopt::Long;
use Getopt::Long qw(:config no_ignore_case);


my $space=" " x 32;
my $space_minus=" " x 31;
my %description;
$description{ref}="the reference sequence";
$description{refindex}="the reference index using SMALT";
$description{read1}="read1";
$description{read2}="read2";
$description{insert_size}="insert size";

$description{thread}="number of thread [default 1]";
$description{output_folder}="output folder [default ./passion_output]";
$description{min_intron}="minimum intron size [default 20]";
$description{max_intron_index}="maximum intron index [default 7]\n".$space."[1]=100; [2]=400; [3]=1600; [4]=6400; [5]=25600; [6]=102400; [7]=409600;\n".$space."[8]=1638400; [9]=6553600; [10]=26214400; [11]=104857600; [12]=419430400;";
$description{window_size}="window size [default 5000000]";
$description{cutoff}="cutoff=(number of support reads)/(coverage of higher expressed flanking exon) [default 0.1]";
$description{sequence_error}="sequence error rate [default 0.05]";
$description{max_SNP}="max number of SNP allowed [default 2]";
$description{help}="help";
$description{version}="version";

$description{exonisland_file}="user defined exon islands file in GFF or GTF format (the 1st, 4th, and 5th fields \n".$space_minus." are the coordinates in the genome instead of relative location in a gene) [default F]";
$description{alignment_file}="existed alignment file, if not exist, SMALT will be used to generate SAM file [default F]";
$description{divide2files}="divide bed file according to split sites [default F]";


my %abbreviation;
$abbreviation{ref}="-R/--ref";
$abbreviation{refindex}="-I/--refindex";
$abbreviation{read1}="-r/--read1";
$abbreviation{read2}="-f/--read2";
$abbreviation{insert_size}="-s/--insert_size";

$abbreviation{thread}="-T/--thread";
$abbreviation{output_folder}="-o/--output_folder";
$abbreviation{min_intron}="-m/--min_tron";
$abbreviation{max_intron_index}="-M/--max_intron_index";
$abbreviation{window_size}="-w/--window_size";
$abbreviation{cutoff}="-c/--cutoff";
$abbreviation{sequence_error}="-e/--sequence_error";
$abbreviation{max_SNP}="-S/--max_SNP";
$abbreviation{help}="-h/--help";
$abbreviation{version}="-v/--version";

$abbreviation{exonisland_file}="-x/--exonisland_file";
$abbreviation{alignment_file}="-a/--alignment_file";
$abbreviation{divide2files}="-d/--divide2files";


# declare the perl command line flags/options we want to allow
my %options=();
GetOptions(#mandatory from here
	    "R|ref=s"    	=> \$options{ref},
	    "I|refindex=s" 	=> \$options{refindex},
	    "r|read1=s"	 	=> \$options{read1},
	    "f|read2=s" 	=> \$options{read2},
	    "s|insert_size=i" 	=> \$options{insert_size},
	    #optional from here
	    "T|thread:i" 		=> \$options{thread},
	    "o|output_folder:s" 	=> \$options{output_folder},
	    "m|min_intron:i" 		=> \$options{min_intron},
	    "M|max_intron_index:i" 	=> \$options{max_intron_index},
	    "w|window_size:i" 		=> \$options{window_size},
	    "c|cutoff:f" 		=> \$options{cutoff},
	    "e|sequence_error:f" 	=> \$options{sequence_error},
	    "S|max_SNP:i" 		=> \$options{max_SNP},
	    "h|help" 			=> \$options{help},
	    "v|version:s" 		=> \$options{version},
	    #added 3
	    "x|exonisland_file:s" 	=> \$options{exonisland_file},
	    "a|alignment_file:s" 	=> \$options{alignment_file},
	    "d|divide2files:s" 		=> \$options{divide2files},);



if ( ! defined $options{thread}) {$options{thread}=1;}
if ( ! defined $options{min_intron}) {$options{min_intron}=20;}
if ( ! defined $options{max_intron_index}) {$options{max_intron_index}=7;}
if ( ! defined $options{window_size}) {$options{window_size}=5000000;}
if ( ! defined $options{cutoff}) {$options{cutoff}=0.1;}
if ( ! defined $options{sequence_error}) {$options{sequence_error}=0.05;}
if ( ! defined $options{max_SNP}) {$options{max_SNP}=2;}
if ( ! defined $options{output_folder}) {$options{output_folder}="./passion_output";}
if ( defined $options{version}) {$options{version}="PASSion verion 1.2.1 (25-Jun-2012)";}


if ( ! defined $options{exonisland_file}) {$options{exonisland_file}="F";}
if ( ! defined $options{alignment_file}) {$options{alignment_file}="F";}
if ( ! defined $options{divide2files}) {$options{divide2files}="F";}

#print $options{thread},"\n";
#GetOptions( "s|output_folder:s" => \$options{output_folder});
# test for the existence of the options on the command line.
# in a normal program you'd do more than just print these.

if ( $options{help}) {
printhelp(\%abbreviation,\%description);
exit;
}

if ($options{version}) {
    print $options{version},"\n"; 
exit;
}
my $missed_mandatory_count=0;
foreach my $key (sort keys %options)
{
  if (! defined $options{$key} && $key ne "help" && $key ne "version") {
    $missed_mandatory_count++;
    if ($missed_mandatory_count==1 )
      {print "ERROR: The following mandatory parameters are missing!\n";}
    printf "    %-20s\t%-60s\n",$abbreviation{$key},$description{$key}; 
  }
}
if ($missed_mandatory_count>0)
{exit;}



system( "echo \" passion_pipeline.sh $options{ref} $options{refindex} $options{read1} $options{read2}  $options{insert_size} $options{thread} $options{output_folder} $options{min_intron} $options{max_intron_index} $options{window_size} $options{cutoff} $options{sequence_error} $options{max_SNP}  $options{exonisland_file} $options{divide2files} $options{alignment_file}\" " );

system( "passion_pipeline.sh $options{ref} $options{refindex} $options{read1} $options{read2}  $options{insert_size} $options{thread} $options{output_folder} $options{min_intron} $options{max_intron_index} $options{window_size} $options{cutoff} $options{sequence_error} $options{max_SNP} $options{exonisland_file} $options{divide2files} $options{alignment_file}" );













sub printhelp {
my ($abbreviation_ref,$description_ref)=@_;
my %descrition=%$description_ref;
my %abbreviation=%$abbreviation_ref;
print "Arguments:\n";
foreach my $key (sort keys %description)
{
if ($descrition{$key} !~ /\[default/ && $descrition{$key} !~ /help/ && $descrition{$key} !~ /version/)
{printf "    %-20s\t%-60s\n",$abbreviation{$key},$descrition{$key};}
}
print "Options:\n";
foreach my $key (sort keys %description)
{
if ($descrition{$key} =~ /\[default/ )
{printf "    %-20s\t%-60s\n",$abbreviation{$key},$descrition{$key};}
}
printf "    %-20s\t%-60s\n",$abbreviation{help},$descrition{help};
printf "    %-20s\t%-60s\n",$abbreviation{version},$descrition{version};
}
