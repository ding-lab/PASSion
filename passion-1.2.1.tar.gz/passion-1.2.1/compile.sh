g++ ./code/PASSION1215.cpp -o PASSION -O3 -fopenmp
