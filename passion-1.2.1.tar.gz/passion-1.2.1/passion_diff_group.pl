#!/usr/bin/perl -w


use strict;
use warnings;
use Getopt::Long;
use IO::File;
my @array_color;
my @array_tag;
my %hash_junction;
my %bed_fh;
#Set usage message
my $usage="Usage: perl comparison -c cutoff -f file -o outputf.\n";

#Declare all variables needed by GetOpt
my ($cutoff, $file,$outputf,$divide,$help,$normalize,$version)=();

my %abbreviation;
$abbreviation{cutoff}="-c/--cutoff";
$abbreviation{file}="-f/--configurefile";
$abbreviation{outputf}="-o/--outputfolder";
$abbreviation{divide2files}="-d/--dividebysite";
$abbreviation{help}="-h/--help";
$abbreviation{normalize}="-n/--normalize";
$abbreviation{version}="-v/--version";

my %description;
$description{cutoff}="cutoff=(number of support reads)/(coverage of higher expressed flanking exon) [default 0.1]";
$description{file}="configuration file format: passion_output tag group [read coverage](if necessary) (seprarate by \\t)";
$description{outputf}="output folder [default ./passion_diff_output]";
$description{divide2files}="divide bed file according to split sites [default F]";
$description{help}="help";
$description{normalize}="Normalization according to read coverage [default F]";
$description{version}="version";

GetOptions(
	    "c|cutoff:f"    	=> \$cutoff,
	    "f|configurefile=s" => \$file,
	    "o|outputfolder:s" 	=> \$outputf,
	    "d|dividebysite:s" 	=> \$divide,
	    "h|help" 		=> \$help,
	    "n|normalize:s" 	=> \$normalize,
	    "v|version" 	=> \$version,);


if ( ! defined $cutoff) {$cutoff=0.1;}
if ( ! defined $outputf) {$outputf="./passion_diff_output";}
if ( ! defined $divide) {$divide="F";}
if ( ! defined $normalize) {$normalize="F";}
if ( defined $version) {$version="PASSion differential splicing verion 1.2.1 (25-Jun-2012)";}

if ( $help) {
printhelp(\%abbreviation,\%description);
exit;
}

if ($version) {
    print $version,"\n"; 
exit;
}
if ( ! defined $file ) {die  "Please input the configure file where the samples and tags (group and read coverage) can be find!\n";}

if (-d "$outputf")
{system('rm','-r',"$outputf");}
mkdir "$outputf", 0777;
mkdir "$outputf/tmp", 0777;

system( "sort -k 4,4 -nr $file >$file.sort");
open (CONFIGURE, "$file.sort") or die "Could not open configure file.\n";

my %hash_group;
my %fh;
my $line_c=1;
my $read_base;
while (my $line=<CONFIGURE>)
{
  chomp $line;

  if ($line)
    {my ($inputf,$tag,$group,$read_count)=split("\t",$line);
    if ($normalize ne "F")
    {
      if ($read_count)
      {}
      else {print "ERROR: Reads coverage of each sample should be provided if read normalization is needed.\n";exit;}
    	
    if ($group)
      {
      if ($line_c==1)
      {$read_base=$read_count;}
      $hash_group{$group}=$line;
      #print $read_count,"\n";
      if (! -d "$outputf/tmp/$group")
	{
	  mkdir "$outputf/tmp/$group", 0777;
	}
      if (! -e "$outputf/tmp/$group.configure.txt")
	{open ($fh{$group}, ">$outputf/tmp/$group.configure.txt") or die "Could not open output path!\n";}
	print2temp ($fh{$group},join("\t",$inputf,$tag,$group,$read_base/$read_count)."\n");
      }
    else {
      print "No group information!\n";
      exit;
    }
  }
  else {

    if ($group)
      {
      $hash_group{$group}=$line;
      #print $hash_group{$group},"\n";
      if (! -d "$outputf/tmp/$group")
	{
	  mkdir "$outputf/tmp/$group", 0777;
	}
      if (! -e "$outputf/tmp/$group.configure.txt")
	{open ($fh{$group}, ">$outputf/tmp/$group.configure.txt") or die "Could not open output path!\n";}
	print2temp ($fh{$group},join("\t",$inputf,$tag,$group)."\n");
      }
    else {
      print "No group information!\n";
      exit;
    }


   }

  }
  $line_c++;
}
close(CONFIGURE);
print ("\n");

open (MIX_FINAL,">$outputf/Junctions_mix.final") or die "Could not open Junction mix final file!\n";
if ($divide eq "F")
{ 
open (MIX_BED,">$outputf/Junctions_mix.bed") or die "Could not open Junction mix final bed!\n";
}
else
{
open (GTAG_BED,">$outputf/Junctions_GTAG.bed") or die "Could not open Junction mix final bed!\n";
open (ATAC_BED,">$outputf/Junctions_ATAC.bed") or die "Could not open Junction mix final bed!\n";
open (GCAG_BED,">$outputf/Junctions_GCAG.bed") or die "Could not open Junction mix final bed!\n";
open (OTHER_BED,">$outputf/Junctions_OTHER.bed") or die "Could not open Junction mix final bed!\n";
}

###############group color#############################
#tag=group

my @key_group=keys(%hash_group);
for(my $index=1;$index<=@key_group;$index++)
  {
  $array_tag[$index]=$key_group[$index-1];
  my $mod=$index % 254;
  my $div=int($index/254);
  $array_color[$index]="0,".$div.",".$mod;
  #print $array_tag[$index],"\t",$array_color[$index],"\n";
}

#index starting from 1
my $index=1;
$array_color[0]="0,0,0";
if (@array_color<5)
{
if ($divide eq "F")
{ print  MIX_BED "track name=junctions description=\"PASSion mix junctions ";
 if ($array_color[1]){  $array_color[1]="255,0,0"; print MIX_BED $array_tag[1],":", $array_color[1];}
 if ($array_color[2]){  $array_color[2]="0,255,0"; print MIX_BED "; ",$array_tag[2],":", $array_color[2];}
 if ($array_color[3]){  $array_color[3]="0,0,255"; print MIX_BED "; ",$array_tag[3],":", $array_color[3];}
print MIX_BED "; Common in ALL:",$array_color[0],"\" itemRgb=\"On\" \n"; }
else
{
print  GTAG_BED "track name=junctions description=\"PASSion mix junctions ";
 if ($array_color[1]){  $array_color[1]="255,0,0"; print GTAG_BED $array_tag[1],":", $array_color[1];}
 if ($array_color[2]){  $array_color[2]="0,255,0"; print GTAG_BED "; ",$array_tag[2],":", $array_color[2];}
 if ($array_color[3]){  $array_color[3]="0,0,255"; print GTAG_BED "; ",$array_tag[3],":", $array_color[3];}
print GTAG_BED "; Common in ALL:",$array_color[0],"\" itemRgb=\"On\" \n";

print  ATAC_BED "track name=junctions description=\"PASSion mix junctions ";
 if ($array_color[1]){  $array_color[1]="255,0,0"; print ATAC_BED $array_tag[1],":", $array_color[1];}
 if ($array_color[2]){  $array_color[2]="0,255,0"; print ATAC_BED "; ",$array_tag[2],":", $array_color[2];}
 if ($array_color[3]){  $array_color[3]="0,0,255"; print ATAC_BED "; ",$array_tag[3],":", $array_color[3];}
print ATAC_BED "; Common in ALL:",$array_color[0],"\" itemRgb=\"On\" \n";

print  GCAG_BED "track name=junctions description=\"PASSion mix junctions ";
 if ($array_color[1]){  $array_color[1]="255,0,0"; print GCAG_BED $array_tag[1],":", $array_color[1];}
 if ($array_color[2]){  $array_color[2]="0,255,0"; print GCAG_BED "; ",$array_tag[2],":", $array_color[2];}
 if ($array_color[3]){  $array_color[3]="0,0,255"; print GCAG_BED "; ",$array_tag[3],":", $array_color[3];}
print GCAG_BED "; Common in ALL:",$array_color[0],"\" itemRgb=\"On\" \n";

print  OTHER_BED "track name=junctions description=\"PASSion mix junctions ";
 if ($array_color[1]){  $array_color[1]="255,0,0"; print OTHER_BED $array_tag[1],":", $array_color[1];}
 if ($array_color[2]){  $array_color[2]="0,255,0"; print OTHER_BED "; ",$array_tag[2],":", $array_color[2];}
 if ($array_color[3]){  $array_color[3]="0,0,255"; print OTHER_BED "; ",$array_tag[3],":", $array_color[3];}
print OTHER_BED "; Common in ALL:",$array_color[0],"\" itemRgb=\"On\" \n";


}


}
else {
if ($divide eq "F")
{ 
 print  MIX_BED "track name=junctions description=\"PASSion mix junctions. Common in ALL:",$array_color[0],"\" itemRgb=\"On\" \n";
}
else {
 print  GTAG_BED "track name=junctions description=\"PASSion mix junctions. Common in ALL:",$array_color[0],"\" itemRgb=\"On\" \n";
 print  ATAC_BED "track name=junctions description=\"PASSion mix junctions. Common in ALL:",$array_color[0],"\" itemRgb=\"On\" \n";
 print  GCAG_BED "track name=junctions description=\"PASSion mix junctions. Common in ALL:",$array_color[0],"\" itemRgb=\"On\" \n";
 print  OTHER_BED "track name=junctions description=\"PASSion mix junctions. Common in ALL:",$array_color[0],"\"itemRgb=\"On\" \n";
}
}
###############group color#############################






##################normalize###########################


##################normalize###########################





foreach my $key (keys %hash_group)
{

  #system( "echo \"passion_diff.pl -c $cutoff -f $outputf/tmp/$key.configure.txt -o $outputf/tmp/$key/ -d $divide \" " );
  print("\nDiscovering splice junctions in Group $key \n");
  print("Results of Group $key are storied at $outputf/tmp/$key/ \n");
  system( "passion_diff_2.pl -c $cutoff -f $outputf/tmp/$key.configure.txt -o $outputf/tmp/$key/ -d $divide" );
}

print ("\nCombine the results from the groups ... ...\n");
print ("Results of the combinde group are storied at $outputf/\n");
joingroups();
output2bed();

sub print2temp {
my ($INPUTFILE,$record)=@_;
print $INPUTFILE $record;

}



sub joingroups{
foreach my $key (keys %hash_group)
  {
    readfinal($key,$outputf);
  }
    print "Combining ... ...\n";
}
print "Done!\n\n";
###################################################
sub readfinal{
my ($group,$outputf)=@_;
my $file= "$outputf/tmp/$group/Junctions_mix.final";
my $index;
for ( $index=1;$index<@array_tag;$index++)
{
  if ($array_tag[$index] eq $group)
  {last;}
}
my $color=$array_color[$index];
print $array_tag[$index],"\t", $color,"\n";

open (FINAL,"$file") or die "Could not open file from $file\n";
my $line_count=1;
while (my $line=<FINAL>){
  chomp $line;
  if ($line_count>0)
  {
    my ($id,$ref,$bp_s,$bp_e,$range_s,$range_e,$support,$sup_plus,$sup_minus,$ll,$rl,$marker,$start,$end,$start_cov,$end_cov,$tag_count,$tag_support)=split("\t",$line);
    $sup_plus =~ s/\+//;
    $sup_minus =~ s/\-//;
    my @tag_support=split(";",$tag_support);
    my $total_support=0;
    for (my $i=0;$i<@tag_support;$i++)
    {
      my @array=split(":",$tag_support[$i]);
      $total_support=$total_support+$array[1];
    }
    

    if ($hash_junction{$ref}{$start}{$end}) #junction exists
    {

      $hash_junction{$ref}{$start}{$end} = {support 	=> $hash_junction{$ref}{$start}{$end}{"support"} +$total_support,
					    #sup_plus	=> $hash_junction{$ref}{$start}{$end}{"sup_plus"}+$sup_plus,
					    #sup_minus 	=> $hash_junction{$ref}{$start}{$end}{"sup_minus"}+$sup_minus,
					    ll		=> max($hash_junction{$ref}{$start}{$end}{"ll"}, $ll),
					    rl		=> max($hash_junction{$ref}{$start}{$end}{"rl"}, $rl),
					    #start_cov 	=> $hash_junction{$ref}{$start}{$end}{"start_cov"}+$start_cov,
					    #end_cov 	=> $hash_junction{$ref}{$start}{$end}{"end_cov"}+$end_cov,
					    group_count 	=> $hash_junction{$ref}{$start}{$end}{"group_count"}+1,
					    details 	=> $hash_junction{$ref}{$start}{$end}{"details"}.$group.":".$support.";",
					    #length	=> $length,
					    ref		=> $ref,
					    bp_s	=> $bp_s,
					    bp_e	=> $bp_e,
					    range_s	=> $range_s,
					    range_e	=> $range_e,
					    marker	=> $marker,
					    start	=> $start,
					    end		=> $end,
					    color 	=> $array_color[0],
					    tag_details => $hash_junction{$ref}{$start}{$end}{"tag_details"}.$group."-".$tag_support,
					    };
    }
    else {

      $hash_junction{$ref}{$start}{$end} = {support 	=> $total_support,
					    #sup_plus	=> $sup_plus,
					    #sup_minus 	=> $sup_minus,
					    ll		=> $ll,
					    rl		=> $rl,
					    #start_cov 	=> $start_cov,
					    #end_cov 	=> $end_cov,
					    group_count => 1,
					    details 	=> $group.":".$support.";",
					    #length	=> $length,
					    ref		=> $ref,
					    bp_s	=> $bp_s,
					    bp_e	=> $bp_e,
					    range_s	=> $range_s,
					    range_e	=> $range_e,
					    marker	=> $marker,
					    start	=> $start,
					    end		=> $end,
					    color	=> $color,
					    tag_details => $group."-".$tag_support,
					    };

      }
  }
  $line_count++;

}



}



sub output2bed {
my $count=0;

foreach my $key1 (keys %hash_junction)
{
	foreach my $key2 (keys %{$hash_junction{$key1}})
	{
		foreach my $key3 (keys %{$hash_junction{$key1}{$key2}})
		{

		    #my $final_coverage=max($hash_junction{$key1}{$key2}{$key3}{"start_cov"},$hash_junction{$key1}{$key2}{$key3}{"end_cov"});
		    #my $final_cutoff_support= ceiling($final_coverage*$cutoff);
		    #if ($hash_junction{$key1}{$key2}{$key3}{"support"}>=$final_cutoff_support)
		    #{
			  print MIX_FINAL #$hash_junction{$key1}{$key2}{$key3}{"length"},"\t",
		          $hash_junction{$key1}{$key2}{$key3}{"ref"},"\t",
		          $hash_junction{$key1}{$key2}{$key3}{"bp_s"},"\t",
		          $hash_junction{$key1}{$key2}{$key3}{"bp_e"},"\t",
		          $hash_junction{$key1}{$key2}{$key3}{"range_s"},"\t",
		          $hash_junction{$key1}{$key2}{$key3}{"range_e"},"\t",
		          $hash_junction{$key1}{$key2}{$key3}{"support"},"\t",
		          #$hash_junction{$key1}{$key2}{$key3}{"sup_plus"},"\t",
		          #$hash_junction{$key1}{$key2}{$key3}{"sup_minus"},"\t",
		          $hash_junction{$key1}{$key2}{$key3}{"ll"},"\t",
		          $hash_junction{$key1}{$key2}{$key3}{"rl"},"\t",
		          $hash_junction{$key1}{$key2}{$key3}{"marker"},"\t",
		          $hash_junction{$key1}{$key2}{$key3}{"start"},"\t",
		          $hash_junction{$key1}{$key2}{$key3}{"end"},"\t",
		          #$hash_junction{$key1}{$key2}{$key3}{"start_cov"},"\t",
		          #$hash_junction{$key1}{$key2}{$key3}{"end_cov"},"\t",
		          $hash_junction{$key1}{$key2}{$key3}{"group_count"},"\t",
		          $hash_junction{$key1}{$key2}{$key3}{"tag_details"},"\t",
		          $hash_junction{$key1}{$key2}{$key3}{"details"},"\n";

		    my $direction;
		    if ($hash_junction{$key1}{$key2}{$key3}{"marker"} =~ /GCAG/ || $hash_junction{$key1}{$key2}{$key3}{"marker"} =~ /ATAC/ ||$hash_junction{$key1}{$key2}{$key3}{"marker"} =~ /GTAG/)
		    {
		      $direction="+";
		    }
		    elsif ($hash_junction{$key1}{$key2}{$key3}{"marker"} =~ /CTGC/ ||$hash_junction{$key1}{$key2}{$key3}{"marker"} =~/GTAT/||$hash_junction{$key1}{$key2}{$key3}{"marker"} =~ /CTAC/)
		    {
		      $direction="-";
		    }
		    else {$direction=".";}
		    
		  #print join("\t",$chr,$chr_start,$chr_end,$junctionid,$support,$direction,$chr_start_range,$chr_end_range,"255,0,0","2","$ll,$rl","$block_start,$block_end"),"\n";
		    my $blockend=$hash_junction{$key1}{$key2}{$key3}{"end"}-($hash_junction{$key1}{$key2}{$key3}{"start"}-$hash_junction{$key1}{$key2}{$key3}{"ll"})-1;
		    if ($divide eq "F")
		    { 
		    print MIX_BED     join("\t",$hash_junction{$key1}{$key2}{$key3}{"ref"},
				      $hash_junction{$key1}{$key2}{$key3}{"start"}-$hash_junction{$key1}{$key2}{$key3}{"ll"},
				      $hash_junction{$key1}{$key2}{$key3}{"end"}+$hash_junction{$key1}{$key2}{$key3}{"rl"}-1,
				      "JUNC_".$count,
				      $hash_junction{$key1}{$key2}{$key3}{"support"},
				      $direction,
				      $hash_junction{$key1}{$key2}{$key3}{"range_s"},
				      $hash_junction{$key1}{$key2}{$key3}{"range_e"},
				      $hash_junction{$key1}{$key2}{$key3}{"color"},
				      "2",
				      $hash_junction{$key1}{$key2}{$key3}{"ll"}.",".$hash_junction{$key1}{$key2}{$key3}{"rl"},
				      "0,".$blockend),"\n";
		  }
		  else {
			if ($hash_junction{$key1}{$key2}{$key3}{"marker"} =~ /GTAG/ || $hash_junction{$key1}{$key2}{$key3}{"marker"} =~ /CTAC/)
			{print GTAG_BED    join("\t",$hash_junction{$key1}{$key2}{$key3}{"ref"},
				      $hash_junction{$key1}{$key2}{$key3}{"start"}-$hash_junction{$key1}{$key2}{$key3}{"ll"},
				      $hash_junction{$key1}{$key2}{$key3}{"end"}+$hash_junction{$key1}{$key2}{$key3}{"rl"}-1,
				      "JUNC_".$count,
				      $hash_junction{$key1}{$key2}{$key3}{"support"},
				      $direction,
				      $hash_junction{$key1}{$key2}{$key3}{"range_s"},
				      $hash_junction{$key1}{$key2}{$key3}{"range_e"},
				      $hash_junction{$key1}{$key2}{$key3}{"color"},
				      "2",
				      $hash_junction{$key1}{$key2}{$key3}{"ll"}.",".$hash_junction{$key1}{$key2}{$key3}{"rl"},
				      "0,".$blockend),"\n";
			}
			elsif ($hash_junction{$key1}{$key2}{$key3}{"marker"} =~ /ATAC/ || $hash_junction{$key1}{$key2}{$key3}{"marker"} =~ /GTAT/)
			{print ATAC_BED    join("\t",$hash_junction{$key1}{$key2}{$key3}{"ref"},
				      $hash_junction{$key1}{$key2}{$key3}{"start"}-$hash_junction{$key1}{$key2}{$key3}{"ll"},
				      $hash_junction{$key1}{$key2}{$key3}{"end"}+$hash_junction{$key1}{$key2}{$key3}{"rl"}-1,
				      "JUNC_".$count,
				      $hash_junction{$key1}{$key2}{$key3}{"support"},
				      $direction,
				      $hash_junction{$key1}{$key2}{$key3}{"range_s"},
				      $hash_junction{$key1}{$key2}{$key3}{"range_e"},
				      $hash_junction{$key1}{$key2}{$key3}{"color"},
				      "2",
				      $hash_junction{$key1}{$key2}{$key3}{"ll"}.",".$hash_junction{$key1}{$key2}{$key3}{"rl"},
				      "0,".$blockend),"\n";
			}
			elsif ($hash_junction{$key1}{$key2}{$key3}{"marker"} =~ /GCAG/ || $hash_junction{$key1}{$key2}{$key3}{"marker"}=~ /CTGC/)
			{print GCAG_BED    join("\t",$hash_junction{$key1}{$key2}{$key3}{"ref"},
				      $hash_junction{$key1}{$key2}{$key3}{"start"}-$hash_junction{$key1}{$key2}{$key3}{"ll"},
				      $hash_junction{$key1}{$key2}{$key3}{"end"}+$hash_junction{$key1}{$key2}{$key3}{"rl"}-1,
				      "JUNC_".$count,
				      $hash_junction{$key1}{$key2}{$key3}{"support"},
				      $direction,
				      $hash_junction{$key1}{$key2}{$key3}{"range_s"},
				      $hash_junction{$key1}{$key2}{$key3}{"range_e"},
				      $hash_junction{$key1}{$key2}{$key3}{"color"},
				      "2",
				      $hash_junction{$key1}{$key2}{$key3}{"ll"}.",".$hash_junction{$key1}{$key2}{$key3}{"rl"},
				      "0,".$blockend),"\n";
			}
			else
			{print GCAG_BED    join("\t",$hash_junction{$key1}{$key2}{$key3}{"ref"},
				      $hash_junction{$key1}{$key2}{$key3}{"start"}-$hash_junction{$key1}{$key2}{$key3}{"ll"},
				      $hash_junction{$key1}{$key2}{$key3}{"end"}+$hash_junction{$key1}{$key2}{$key3}{"rl"}-1,
				      "JUNC_".$count,
				      $hash_junction{$key1}{$key2}{$key3}{"support"},
				      $direction,
				      $hash_junction{$key1}{$key2}{$key3}{"range_s"},
				      $hash_junction{$key1}{$key2}{$key3}{"range_e"},
				      $hash_junction{$key1}{$key2}{$key3}{"color"},
				      "2",
				      $hash_junction{$key1}{$key2}{$key3}{"ll"}.",".$hash_junction{$key1}{$key2}{$key3}{"rl"},
				      "0,".$blockend),"\n";
			}
		  }
		  
		  $count++;
		  #}
		#else {print $key1,"\t",$key2,"\t",$key3,"\t",$hash_junction{$key1}{$key2}{$key3}{"support"},"\t",$final_cutoff_support,"\n";}
		}
	}
}
}

sub max{
my ($a,$b)=@_;
if ($a>=$b)
{return $a;}
else
{return $b;}
}


sub ceiling {
	(my $x)=@_;
	if (int($x)==$x)
	{return $x;}
	else {return int($x)+1;}
}

sub printhelp {
my ($abbreviation_ref,$description_ref)=@_;
my %descrition=%$description_ref;
my %abbreviation=%$abbreviation_ref;
print "Arguments:\n";
foreach my $key (sort keys %description)
{
if ($descrition{$key} !~ /\[default/ && $descrition{$key} !~ /help/ && $descrition{$key} !~ /version/)
{printf "    %-20s\t%-60s\n",$abbreviation{$key},$descrition{$key};}
}
print "Options:\n";
foreach my $key (sort keys %description)
{
if ($descrition{$key} =~ /\[default/ )
{printf "    %-20s\t%-60s\n",$abbreviation{$key},$descrition{$key};}
}
printf "    %-20s\t%-60s\n",$abbreviation{help},$descrition{help};
printf "    %-20s\t%-60s\n",$abbreviation{version},$descrition{version};
}

